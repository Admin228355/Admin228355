<?php
/* Красивый адрес /legal/offer/. Сама страница — в app/offer.php. */
require __DIR__ . '/../../app/offer.php';
