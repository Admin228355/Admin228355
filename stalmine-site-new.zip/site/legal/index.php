<?php
/* Красивый адрес /legal/. Сама страница — в app/legal.php. */
require __DIR__ . '/../app/legal.php';
