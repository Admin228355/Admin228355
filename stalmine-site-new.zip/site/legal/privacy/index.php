<?php
/* Красивый адрес /legal/privacy/. Сама страница — в app/privacy.php. */
require __DIR__ . '/../../app/privacy.php';
