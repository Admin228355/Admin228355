<?php
/* Красивый адрес /news/. Сама страница — в app/news.php. */
require __DIR__ . '/../app/news.php';
