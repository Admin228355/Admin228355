<?php
/* Красивый адрес /logout/. Сама страница — в app/logout.php. */
require __DIR__ . '/../app/logout.php';
