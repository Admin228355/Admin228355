<?php
/* Красивый адрес /login/. Сама страница — в app/login.php. */
require __DIR__ . '/../app/login.php';
