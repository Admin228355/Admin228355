<?php
/* Красивый адрес /wiki/. Сама страница — в app/wiki.php. */
require __DIR__ . '/../app/wiki.php';
