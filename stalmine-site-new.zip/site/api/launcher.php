<?php
/* ============================================================================
 *  launcher.php — то, о чём лаунчер STALMINE спрашивает сайт.
 *
 *  ЗАЧЕМ ОТДЕЛЬНО ОТ bridge.php. Мост — для игрового сервера: он отвечает
 *  строками с «|», потому что Skript не умеет разбирать JSON. Лаунчер, наоборот,
 *  написан на JavaScript, и ему JSON родной. Смешивать два формата в одном
 *  файле — значит на каждой правке думать, какой ответ куда пойдёт.
 *
 *  АККАУНТ ОДИН НА ВСЁ. Лаунчер не заводит своих учёток: он пользуется той же
 *  таблицей `users`, что и сайт, и тем же `password_hash`. Человек
 *  регистрируется где угодно — в лаунчере или на сайте — и входит и там, и там.
 *
 *  ПАРОЛЬ НЕ ХРАНИТСЯ И НЕ ПИШЕТСЯ В ЖУРНАЛ. Только хеш, как в inc/auth.php.
 *
 *  ЧТО ТАКОЕ «ИГРОВОЙ ПРОПУСК» (do=session). Перед запуском игры лаунчер
 *  просит пропуск: сайт записывает «ник N с адреса A может зайти ближайшие
 *  N минут». При входе в игру сервер спрашивает мост, есть ли такой пропуск,
 *  и только тогда пускает. Отсюда следует главное: зайти на сервер мимо
 *  лаунчера нельзя, и чужим ником — тоже, пароль спрашивается ДО игры.
 * ========================================================================= */

declare(strict_types=1);

require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/auth.php';
require_once __DIR__ . '/../inc/site.php';   /* setting() — адрес и версия из настроек сайта */

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

/* Ответ всегда JSON и всегда с полем ok — лаунчеру не нужно гадать по коду. */
function out(array $data, int $code = 200): never {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function fail(string $why, int $code = 400): never {
    out(['ok' => false, 'error' => $why], $code);
}

/* Тело приходит JSON-ом, но GET ?do=hello тоже должен работать: по нему
 * удобно проверять живость сайта из браузера. */
$raw = file_get_contents('php://input') ?: '';
$body = $raw !== '' ? json_decode($raw, true) : null;
if (!is_array($body)) { $body = []; }
$in = static fn(string $k, string $d = ''): string
    => trim((string)($body[$k] ?? $_REQUEST[$k] ?? $d));

$do = $in('do');

/* ---------------------------------------------------------------------------
 *  Пропуска и ключи
 * ------------------------------------------------------------------------ */


/* ---------------------------------------------------------------------------
 *  ЗАПРОСЫ С ОДНОЙ ПОВТОРНОЙ ПОПЫТКОЙ
 *
 *  ЗАЧЕМ. База лежит НЕ на том же хостинге, что сайт: сайт на reg.ru, база —
 *  у игрового хостинга. Связь между ними иногда обрывается прямо посреди
 *  запроса, и PDO отвечает «MySQL server has gone away» — причём чаще всего
 *  на следующем `prepare()` ПОСЛЕ записи, а не на самой записи. Замерено
 *  21.09.2026: чтения проходят за 70 мс, а первый запрос после INSERT висит
 *  19 секунд и падает.
 *
 *  Одна повторная попытка с новым соединением закрывает это полностью.
 *  Повтор безопасен: у `users` уникальный логин, у пропусков — уникальный
 *  отпечаток ключа, а лишняя строка в `login_tries` ничего не ломает.
 * ------------------------------------------------------------------------ */
$DB = $pdo;
function dbConnect(): PDO {
    global $CFG;
    return new PDO(
        sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
                $CFG['db_host'], $CFG['db_port'], $CFG['db_name']),
        $CFG['db_user'], $CFG['db_pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
         PDO::ATTR_EMULATE_PREPARES => false]
    );
}
/** Выполнить запрос. Курсор закрывать ОБЯЗАТЕЛЬНО — см. ниже по файлу. */
function q(string $sql, array $args = []): PDOStatement {
    global $DB;
    try {
        $st = $DB->prepare($sql);
        $st->execute($args);
        return $st;
    } catch (PDOException $e) {
        if (!str_contains($e->getMessage(), 'gone away') && $e->getCode() !== 'HY000') {
            throw $e;
        }
        $DB = dbConnect();
        $st = $DB->prepare($sql);
        $st->execute($args);
        return $st;
    }
}
/** Одно значение из запроса, с закрытием курсора. */
function q1(string $sql, array $args = []) {
    $st = q($sql, $args);
    $v = $st->fetchColumn();
    $st->closeCursor();
    return $v;
}
/** Одна строка, с закрытием курсора. */
function qrow(string $sql, array $args = []): ?array {
    $st = q($sql, $args);
    $r = $st->fetch();
    $st->closeCursor();
    return $r === false ? null : $r;
}
/** Все строки. */
function qall(string $sql, array $args = []): array {
    $st = q($sql, $args);
    $r = $st->fetchAll();
    $st->closeCursor();
    return $r;
}

const LAUNCHER_TOKEN_DAYS = 30;   // сколько лаунчер помнит вход
const GAME_PASS_MINUTES   = 15;   // сколько живёт разрешение зайти в игру

/** Ключ отдаётся ОДИН раз, в базе лежит только его отпечаток. */
function issueToken(int $userId, string $nick): array {
    $token = bin2hex(random_bytes(32));
    q('INSERT INTO launcher_sessions (user_id, token_hash, nick, ip, created_at, expires_at)
       VALUES (?, ?, ?, ?, NOW(), NOW() + INTERVAL ? DAY)',
      [$userId, hash('sha256', $token), $nick, ipBin(), LAUNCHER_TOKEN_DAYS])->closeCursor();
    return ['token' => $token, 'expires_days' => LAUNCHER_TOKEN_DAYS];
}

/** Кто пришёл. Возвращает строку сессии вместе с пользователем или null. */
function bearer(string $token): ?array {
    if (!preg_match('/^[a-f0-9]{64}$/', $token)) { return null; }
    return qrow(
        'SELECT s.id AS sid, s.nick AS snick, u.*
           FROM launcher_sessions s JOIN users u ON u.id = s.user_id
          WHERE s.token_hash = ? AND s.expires_at > NOW() LIMIT 1',
        [hash('sha256', $token)]
    );
}

/* ---------------------------------------------------------------------------
 *  do=hello — всё, что лаунчеру нужно знать до входа
 *
 *  Адрес сервера отдаётся ОТСЮДА, а не зашит в .exe: у хостинга адрес — это
 *  узел и порт, и при переезде менять его придётся в одном месте, а не у
 *  каждого игрока.
 * ------------------------------------------------------------------------ */
if ($do === 'hello' || $do === '') {
    $news = [];
    try {
        foreach (qall('SELECT title, created_at FROM news
                        WHERE published = 1 ORDER BY created_at DESC LIMIT 4') as $n) {
            $news[] = ['title' => (string)$n['title'], 'at' => (string)$n['created_at']];
        }
    } catch (Throwable $e) {
        /* Новостей может не быть — лаунчер и без них рабочий. */
    }

    out([
        'ok'         => true,
        'serverName' => 'STALMINE — Кыштымский Пробой',
        /* Адрес и версию берём из настроек сайта — тех же, что показывает
         * страница: одно место правды, иначе лаунчер и сайт разойдутся. */
        'serverHost' => setting($DB, 'game_host', (string)($CFG['mc_host'] ?? '65.21.9.198')),
        'serverPort' => (int)setting($DB, 'game_port', (string)($CFG['mc_port'] ?? 25919)),
        'mcVersion'  => setting($DB, 'mc_version', '26.1.2'),
        'packUrl'    => 'https://stalmine.ru/pack/stalmine.zip',
        'siteUrl'    => 'https://stalmine.ru',
        'news'       => $news,
    ]);
}

/* ---------------------------------------------------------------------------
 *  do=register — завести аккаунт прямо из лаунчера
 *
 *  Логин и ник — ОДНО И ТО ЖЕ слово. На сайте они разведены (логин длиннее и
 *  допускает точку), но человеку, пришедшему играть, два разных имени объяснить
 *  невозможно: он вводит позывной и ждёт, что под ним и будет играть.
 * ------------------------------------------------------------------------ */
if ($do === 'register') {
    $nick  = $in('nick');
    $pass  = (string)($body['pass'] ?? '');
    $email = $in('email');

    if (!validNick($nick)) {
        fail('Позывной: от 3 до 16 знаков, латиница, цифры и «_».');
    }
    if (mb_strlen($pass) < PASS_MIN) {
        fail('Пароль короче ' . PASS_MIN . ' знаков.');
    }
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        fail('Почта выглядит неправильно.');
    }

    /* ВЫБОРКИ ЗАКРЫВАЕМ ЯВНО, ЧЕРЕЗ closeCursor().
     *
     * Сайт работает с настоящими подготовленными запросами
     * (EMULATE_PREPARES = false). У такого запроса результат остаётся
     * открытым, пока его не дочитали до конца, а `fetch()` при пустом ответе
     * его НЕ закрывает. Следующая запись в другую таблицу после этого уходит
     * в никуда: соединение отвечает «MySQL server has gone away» — причём не
     * на виноватой строке, а на той, до которой дошло.
     *
     * Это стоило половины вечера: в консоли тот же самый запрос проходил за
     * 70 мс, а через веб-сервер падал. Разница была ровно в незакрытой
     * выборке перед ним. */
    $taken = (int)q1('SELECT COUNT(*) FROM users WHERE login = ? OR mc_nick = ? LIMIT 1', [$nick, $nick]);
    if ($taken > 0) {
        fail('Этот позывной уже занят.');
    }

    /* Тот же предел, что на сайте: пять аккаунтов с адреса в сутки. */
    $fromIp = (int)q1('SELECT COUNT(*) FROM users
                        WHERE reg_ip = ? AND created_at > (NOW() - INTERVAL 1 DAY)', [ipBin()]);
    if ($fromIp >= 5) {
        fail('С вашего адреса сегодня уже завели несколько аккаунтов. Попробуйте завтра.');
    }

    try {
        q('INSERT INTO users (login, email, pass_hash, mc_nick, reg_ip, created_at)
           VALUES (?, ?, ?, ?, ?, NOW())',
          [$nick, ($email !== '' ? $email : null),
           password_hash($pass, PASSWORD_DEFAULT), $nick, ipBin()])->closeCursor();
    } catch (PDOException $e) {
        error_log('launcher register: ' . $e->getMessage());
        fail('Этот позывной уже занят.');
    }

    $id = (int)$DB->lastInsertId();
    out(['ok' => true, 'nick' => $nick, 'role' => 'player'] + issueToken($id, $nick));
}

/* ---------------------------------------------------------------------------
 *  do=login — вход тем же логином и паролем, что и на сайте
 * ------------------------------------------------------------------------ */
if ($do === 'login') {
    $login = $in('login');
    $pass  = (string)($body['pass'] ?? '');
    $ip    = ipBin();

    /* Тот же предел попыток, что у сайта, и та же таблица: перебирать пароли
     * через лаунчер, обойдя ограничение страницы входа, не выйдет. */
    $tries = (int)q1('SELECT COUNT(*) FROM login_tries
                       WHERE ok = 0 AND at > (NOW() - INTERVAL 15 MINUTE)
                         AND (login = ? OR ip = ?)', [$login, $ip]);
    if ($tries >= 10) {
        fail('Слишком много попыток. Подождите пятнадцать минут.', 429);
    }

    /* Войти можно и по логину сайта, и по игровому нику — человек не обязан
     * помнить, какой из них он вводил при регистрации. */
    $u  = qrow('SELECT * FROM users WHERE login = ? OR mc_nick = ? LIMIT 1', [$login, $login]);
    $ok = $u !== null && password_verify($pass, (string)$u['pass_hash']);

    q('INSERT INTO login_tries (login, ip, ok) VALUES (?, ?, ?)',
      [$login, $ip, $ok ? 1 : 0])->closeCursor();

    if (!$ok) {
        fail('Неверный позывной или пароль.', 401);
    }
    if (password_needs_rehash((string)$u['pass_hash'], PASSWORD_DEFAULT)) {
        q('UPDATE users SET pass_hash = ? WHERE id = ?',
          [password_hash($pass, PASSWORD_DEFAULT), $u['id']])->closeCursor();
    }
    q('UPDATE users SET last_login = NOW(), last_ip = ? WHERE id = ?',
      [$ip, $u['id']])->closeCursor();

    $nick = (string)($u['mc_nick'] ?? '');
    out([
        'ok'   => true,
        'nick' => $nick,
        'role' => (string)($u['role'] ?? 'player'),
        'needsNick' => $nick === '',
    ] + issueToken((int)$u['id'], $nick));
}

/* ---------------------------------------------------------------------------
 *  do=bind — привязать позывной, если аккаунт заведён на сайте без него
 * ------------------------------------------------------------------------ */
if ($do === 'bind') {
    $me = bearer($in('token'));
    if (!$me) { fail('Нужно войти заново.', 401); }
    if ((string)($me['mc_nick'] ?? '') !== '') {
        fail('Позывной уже привязан и меняется только через поддержку.');
    }
    $nick = $in('nick');
    if (!validNick($nick)) {
        fail('Позывной: от 3 до 16 знаков, латиница, цифры и «_».');
    }
    $busy = (int)q1('SELECT COUNT(*) FROM users WHERE mc_nick = ? AND id <> ? LIMIT 1',
                    [$nick, $me['id']]);
    if ($busy > 0) { fail('Этот позывной уже занят.'); }

    q('UPDATE users SET mc_nick = ? WHERE id = ?', [$nick, $me['id']])->closeCursor();
    q('UPDATE launcher_sessions SET nick = ? WHERE user_id = ?', [$nick, $me['id']])->closeCursor();
    out(['ok' => true, 'nick' => $nick]);
}

/* ---------------------------------------------------------------------------
 *  do=session — игровой пропуск перед самым запуском игры
 * ------------------------------------------------------------------------ */
if ($do === 'session') {
    $me = bearer($in('token'));
    if (!$me) { fail('Нужно войти заново.', 401); }
    $nick = (string)($me['mc_nick'] ?? '');
    if ($nick === '') { fail('Сначала привяжите позывной.', 409); }

    /* Пропуск привязан к адресу: украденный ключ с чужого адреса в игру не
     * пустит. Старые пропуска этого игрока гасим — действующий всегда один. */
    q('UPDATE launcher_sessions SET game_until = NULL WHERE nick = ?', [$nick])->closeCursor();
    q('UPDATE launcher_sessions SET ip = ?, game_until = NOW() + INTERVAL ? MINUTE WHERE id = ?',
      [ipBin(), GAME_PASS_MINUTES, $me['sid']])->closeCursor();

    out(['ok' => true, 'nick' => $nick, 'minutes' => GAME_PASS_MINUTES]);
}

/* ---------------------------------------------------------------------------
 *  do=check — СПРАШИВАЕТ ИГРОВОЙ СЕРВЕР, а не человек
 *
 *  Ответ простым текстом и с ключом моста в заголовке — ровно как у
 *  bridge.php, чтобы на стороне Skript не появилось второго способа читать
 *  ответы. «OK» значит «пускать», «NO» — «гнать к лаунчеру».
 * ------------------------------------------------------------------------ */
if ($do === 'check') {
    $key = (string)($_SERVER['HTTP_X_BRIDGE_KEY'] ?? '');
    $need = (string)($CFG['bridge_key'] ?? '');
    if ($need === '' || strlen($need) < 16 || !hash_equals($need, $key)) {
        header('Content-Type: text/plain; charset=utf-8');
        http_response_code(403);
        exit('NO|ключ');
    }
    header('Content-Type: text/plain; charset=utf-8');

    $nick = $in('nick');
    $ip   = $in('ip');
    if (!validNick($nick)) { exit('NO|ник'); }

    $row = qrow('SELECT ip FROM launcher_sessions
                  WHERE nick = ? AND game_until IS NOT NULL AND game_until > NOW()
                  ORDER BY game_until DESC LIMIT 1', [$nick]);
    if ($row === null) { exit('NO|нет пропуска'); }

    /* Адрес сверяем, только если сервер его прислал и он разобрался: за NAT
     * у лаунчера и игры адрес один, но у мобильного интернета бывает иначе,
     * и запирать человека из-за этого нельзя — достаточно, что пропуск свежий
     * и выдан после ввода пароля. */
    if ($ip !== '' && $row['ip'] !== null) {
        $bin = @inet_pton($ip);
        if ($bin !== false && $bin !== $row['ip']) { exit('OK|другой адрес'); }
    }
    exit('OK|');
}

fail('Неизвестный запрос.', 404);
