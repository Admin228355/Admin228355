<?php
/* Красивый адрес /bugs/. Сама страница — в app/bugs.php. */
require __DIR__ . '/../app/bugs.php';
