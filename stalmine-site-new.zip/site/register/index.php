<?php
/* Красивый адрес /register/. Сама страница — в app/register.php. */
require __DIR__ . '/../app/register.php';
