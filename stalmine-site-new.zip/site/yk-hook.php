<?php
/* ============================================================================
 *  yk-hook.php — уведомление об оплате от ЮKassa.
 *
 *  ЭТОТ АДРЕС ВЫЗЫВАЕТ НЕ ЧЕЛОВЕК, А ПЛАТЁЖНЫЙ СЕРВИС. Отсюда всё
 *  остальное: ни страницы, ни сообщений, только коды ответа.
 *
 *  ПОЧЕМУ МЫ НЕ ВЕРИМ ТЕЛУ ЗАПРОСА. Прислать сюда «платёж прошёл» может
 *  кто угодно — адрес открытый, подписи у ЮKassa в уведомлении нет.
 *  Поэтому из письма берём ТОЛЬКО номер платежа, а состояние и сумму
 *  спрашиваем у ЮKassa сами, своим ключом. Подделать это нельзя: чужой
 *  номер вернёт чужой платёж, которого нет в нашей базе.
 *
 *  ПОЧЕМУ ОТВЕЧАЕМ 200 ДАЖЕ НА ЧУЖОЕ. ЮKassa повторяет уведомление, пока
 *  не получит 200, — сутками. Ответить ошибкой на то, что нам не нужно,
 *  значит обречь их слать это вечно.
 * ========================================================================= */

require_once __DIR__ . '/inc/boot.php';
require_once __DIR__ . '/inc/yookassa.php';

header('Content-Type: text/plain; charset=utf-8');

$raw = file_get_contents('php://input');
$in  = json_decode((string)$raw, true);
$id  = $in['object']['id'] ?? '';

if (!is_string($id) || $id === '') {
    http_response_code(200);
    error_log('yk-hook: письмо без номера платежа');
    exit('ok');
}

/*  Спрашиваем правду у источника. Ответ ЮKassa — единственное, чему здесь
 *  можно верить. */
$ch = curl_init('https://api.yookassa.ru/v3/payments/' . rawurlencode($id));
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_USERPWD        => $CFG['yk_shop_id'] . ':' . $CFG['yk_secret'],
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    CURLOPT_TIMEOUT        => 20,
]);
$body = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

/*  ДВА РАЗНЫХ «НЕ ПОЛУЧИЛОСЬ», И ПУТАТЬ ИХ НЕЛЬЗЯ.
 *
 *  404 — такого платежа у ЮKassa нет: значит, письмо не про нас или
 *  номер выдуман. Отвечаем 200: повторять тут нечего, и просить их слать
 *  это ещё раз значит обречь на бесконечный цикл.
 *
 *  Всё остальное (сеть легла, у них авария) — мы просто не смогли
 *  проверить. Вот здесь 500 и нужен: пусть повторят позже, платёж-то
 *  может быть настоящим.
 *
 *  Разница не теоретическая: на пробе выдуманным номером обработчик
 *  отвечал 500, и ЮKassa долбилась бы в него сутками. */
if ($body !== false && $code === 404) {
    http_response_code(200);
    exit('ok');
}
if ($body === false || $code >= 300) {
    http_response_code(500);
    error_log('yk-hook: проверка платежа ' . $id . ' дала HTTP ' . $code);
    exit('retry');
}

$p = json_decode((string)$body, true);
if (($p['status'] ?? '') !== 'succeeded' || ($p['paid'] ?? false) !== true) {
    http_response_code(200);
    exit('ok');
}

/*  Начисление — одной записью и только один раз. Условие «status <>
 *  granted» и есть защита от повтора: второе уведомление о том же платеже
 *  просто не найдёт строку для обновления. */
/*  Пожертвование (строка без ника) сразу получает своё состояние
 *  «donated»: выдавать по нему нечего, и в «ждёт выдачи» оно висеть не
 *  должно — иначе управление вечно показывало бы застрявший платёж. */
$st = $pdo->prepare(
    "UPDATE payments
        SET status = CASE WHEN mc_nick IS NULL OR mc_nick = '' THEN 'donated' ELSE 'paid' END,
            paid_at = COALESCE(paid_at, NOW())
      WHERE yk_id = ? AND status NOT IN ('paid', 'granted', 'donated')"
);
$st->execute([$id]);

if ($st->rowCount() === 0) {
    /*  Либо уже обработали, либо платёж не наш. И то и другое — не ошибка:
     *  повтор уведомления штатное поведение сервиса. */
    http_response_code(200);
    exit('ok');
}

$q = $pdo->prepare('SELECT mc_nick, coins, amount_rub FROM payments WHERE yk_id = ? LIMIT 1');
$q->execute([$id]);
$row = $q->fetch();
if ($row) {
    if ((string)$row['mc_nick'] === '') {
        error_log(sprintf('yk-hook: пожертвование %s — %d ₽', $id, (int)$row['amount_rub']));
    } else {
        error_log(sprintf('yk-hook: оплачено %s — %d ₽ → %d ✦ для %s',
            $id, (int)$row['amount_rub'], (int)$row['coins'], (string)$row['mc_nick']));
    }
}

http_response_code(200);
echo 'ok';
