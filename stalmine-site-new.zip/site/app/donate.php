<?php
/* ============================================================================
 *  donate.php — добровольное пожертвование на разработку.
 *
 *  БЕЗ ВХОДА, БЕЗ НИКА, БЕЗ ТАЛОНОВ. Это не покупка: человек просто
 *  помогает проекту и ничего за это не получает. Поэтому страница не
 *  спрашивает ни аккаунта, ни ника, а платёж не привязывается к аккаунту
 *  даже у того, кто вошёл, — см. ykDonate() в inc/yookassa.php.
 *
 *  Кто хочет талоны — тому на /shop/: там другой договор и другая форма.
 *  Две вещи на одной странице путались бы, и кто-то заплатил бы «на
 *  разработку», ожидая талонов.
 * ========================================================================= */

if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/layout.php';
require_once __DIR__ . '/../inc/yookassa.php';

const DONATE_QUICK = [100, 300, 500, 1000, 3000];

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfOk()) {
        $err = 'Форма устарела. Обновите страницу.';
    } else {
        $rub = (int)preg_replace('/[^0-9]/', '', post('rub'));
        $res = ykDonate($pdo, $CFG, $rub, ipBin());
        if ($res['ok']) {
            header('Location: ' . $res['url']);
            exit;
        }
        $err = $res['error'];
    }
}

/*  Сумма из ссылки (?sum=300 — с главной) подставляется в поле, но ничего
 *  не решает: на сервер уходит то, что в форме в момент отправки. */
$start = (int)($_GET['sum'] ?? 300);
if ($start < DONATE_MIN || $start > DONATE_MAX) { $start = 300; }
$thanks = isset($_GET['thanks']);

pageHead('Поддержать разработку', 'donate');
?>
<section class="donate-hero">
  <div>
    <p class="sh-k"><span>✦</span>Без аккаунта</p>
    <h1 class="sec">Поддержать разработку</h1>
    <p class="lead">Сервер делают несколько человек в свободное время, а хостинг,
    домен и тесты оплачиваются из своего кармана. Если вам нравится то, что
    получается, — помогите сделать дальше.</p>
    <ul class="donate-facts">
      <li><b>Без регистрации.</b> Не нужен ни аккаунт, ни игровой ник —
          только сумма.</li>
      <li><b>Без привязки.</b> Платёж не связывается с аккаунтом, даже если вы
          вошли.</li>
      <li><b>Просто спасибо.</b> В игре пожертвование ничего не даёт — ни
          талонов, ни вещей. Нужны талоны — это <a href="/shop/">пополнение</a>.</li>
    </ul>
  </div>
  <div class="donate-art"><?= art('fire') ?></div>
</section>

<?php if ($thanks): ?>
  <div class="flash flash-ok donate-thanks"><b>Спасибо!</b> Если оплата прошла,
  деньги уже у нас и пойдут на сервер. Чек пришлёт платёжный сервис.</div>
<?php endif; ?>

<section class="panel payblock donate-box">
  <div class="panel-h">Сумма пожертвования</div>
  <div class="pad">
    <?php if ($err !== ''): ?><div class="flash flash-err"><?= h($err) ?></div><?php endif; ?>
    <form method="post" id="df">
      <?= csrfField() ?>
      <div class="payrow">
        <label class="paysum">
          <input id="dv" class="payinput" type="text" inputmode="numeric" name="rub"
                 value="<?= number_format($start, 0, '', ' ') ?>" aria-label="Сумма в рублях">
          <span class="cur">₽</span>
        </label>
        <p class="donate-where" id="dw"></p>
      </div>

      <div class="payquick">
        <?php foreach (DONATE_QUICK as $q): ?>
          <button type="button" data-v="<?= (int)$q ?>"><?= number_format($q, 0, '', ' ') ?> ₽</button>
        <?php endforeach; ?>
      </div>
      <p class="payends">от <?= DONATE_MIN ?> до <?= number_format(DONATE_MAX, 0, '', ' ') ?> ₽ ·
         картой или через СБП на странице ЮKassa</p>

      <div class="row">
        <button class="btn" type="submit">
          <svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 21s-7.5-4.6-9.6-9.2C.9 8.5 2.7 4.5 6.5 4.5c2.2 0 3.7 1.2 5.5 3.2 1.8-2 3.3-3.2 5.5-3.2 3.8 0 5.6 4 4.1 7.3C19.5 16.4 12 21 12 21z"/></svg>
          Поддержать</button>
      </div>
    </form>
    <p class="muted small">Нажимая «Поддержать», вы делаете добровольное
    безвозмездное пожертвование — условия в <a href="/legal/offer/#p8">разделе 8
    оферты</a>. Данные карты вводятся на стороне ЮKassa, к нам они не попадают.</p>
  </div>
</section>

<h2 class="sec">Куда идут деньги</h2>
<div class="donate-uses">
  <div><b>Хостинг</b><p>Игровой сервер, сайт и база работают круглосуточно — это
  главная статья расходов.</p></div>
  <div><b>Разработка</b><p>Модели, звуки, наряды, аномалии: всё новое в Зоне
  делается руками и требует времени.</p></div>
  <div><b>Тесты</b><p>Проверочные серверы, на которых правки обкатываются, прежде
  чем попасть к игрокам.</p></div>
</div>

<script nonce="<?= h(cspNonce()) ?>">
(function () {
  var v = document.getElementById('dv'), w = document.getElementById('dw'),
      cur = <?= (int)$start ?>;
  var words = [[0, 'На пару дней работы сервера.'], [300, 'Неделя хостинга — спасибо!'],
               [1000, 'Месяц хостинга. Серьёзная помощь.'],
               [3000, 'Это заметно продвинет разработку.'],
               [10000, 'Без таких людей проекта бы не было.']];
  function clamp(x) { return Math.max(<?= DONATE_MIN ?>, Math.min(<?= DONATE_MAX ?>, x)); }
  function fmt(x)   { return String(x).replace(/(\d)(?=(\d{3})+$)/g, '$1 '); }
  function draw(typing) {
    if (!typing) { v.value = fmt(cur); }
    var t = ''; words.forEach(function (p) { if (cur >= p[0]) { t = p[1]; } });
    w.textContent = t;
    Array.prototype.forEach.call(document.querySelectorAll('.payquick button'), function (b) {
      b.classList.toggle('on', +b.getAttribute('data-v') === cur);
    });
  }
  v.addEventListener('input', function () {
    var raw = v.value.replace(/[^0-9]/g, '');
    if (raw === '') { return; }
    cur = clamp(parseInt(raw, 10)); draw(true);
  });
  v.addEventListener('blur', function () { draw(); });
  Array.prototype.forEach.call(document.querySelectorAll('.payquick button'), function (b) {
    b.addEventListener('click', function () { cur = clamp(+b.getAttribute('data-v')); draw(); });
  });
  draw();
})();
</script>
<?php pageFoot();
