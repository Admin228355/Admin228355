<?php
/* Напрямую из браузера не открывается: настоящий адрес страницы — /login/.
 * Файл лежит в app/ и подключается из login/index.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}
?>
<?php
require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/auth.php';
require_once __DIR__ . '/../inc/layout.php';

if (user()) { header('Location: /profile/'); exit; }
$err = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfOk()) {
        $err[] = 'Форма устарела. Попробуйте ещё раз.';
    } else {
        $err = doLogin($pdo, trim(post('login')), post('pass'), isset($_POST['remember']));
        if (!$err) { flash('С возвращением.'); header('Location: /profile/'); exit; }
    }
}
pageHead('Вход');
?>
<div class="form-wrap">
  <h1 class="sec">Вход</h1>
  <?php foreach ($err as $e): ?><div class="flash flash-err"><?= h($e) ?></div><?php endforeach; ?>
  <form method="post" class="form">
    <?= csrfField() ?>
    <label>Логин<input name="login" required maxlength="32" autocomplete="username"
      value="<?= h(post('login')) ?>"></label>
    <label>Пароль<input type="password" name="pass" required autocomplete="current-password"></label>
    <label class="check"><input type="checkbox" name="remember" value="1" checked>
      Не спрашивать месяц на этом устройстве</label>
    <button class="btn" type="submit">Войти</button>
  </form>
  <p class="muted">Нет аккаунта? <a href="/register/">Зарегистрируйтесь</a>.</p>
</div>
<?php pageFoot();
