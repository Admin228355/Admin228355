<?php
/* Напрямую из браузера не открывается: настоящий адрес страницы — /news/.
 * Файл лежит в app/ и подключается из news/index.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}
?>
<?php
/* ============================================================================
 *  news.php — новости и обсуждение под ними.
 *
 *  КОММЕНТАРИИ ТОЛЬКО ОТ ВОШЕДШИХ И С ПРИВЯЗАННЫМ НИКОМ. Правило общее для
 *  всего, что пишут игроки, и живёт оно в inc/talk.php — чтобы у чата и у
 *  комментариев оно не разъехалось.
 *
 *  СКРЫТЫЕ КОММЕНТАРИИ НЕ УДАЛЯЮТСЯ, А ПРЯЧУТСЯ. Разбирая жалобу, надо
 *  видеть, за что человека наказали; стёртый вместе с поводом комментарий
 *  делает разбор невозможным.
 * ========================================================================= */

require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/layout.php';
require_once __DIR__ . '/../inc/talk.php';

/*  Пауза между комментариями. Больше, чем в чате: комментарий пишут
 *  вдумчиво, и подряд идущие — это почти всегда спор на два человека,
 *  который лучше вести в игре. */
const COM_GAP = 30;
const COM_MAX = 1000;

$slug = isset($_GET['s']) ? (string)$_GET['s'] : '';

/* ---------------------------------------------------------------------------
 *  ОДНА ЗАПИСЬ
 * ------------------------------------------------------------------------ */
if ($slug !== '') {
    $st = $pdo->prepare('SELECT * FROM news WHERE slug = ? AND published = 1 LIMIT 1');
    $st->execute([$slug]);
    $n = $st->fetch();
    if (!$n) {
        http_response_code(404);
        pageHead('Не найдено', 'news');
        echo '<h1 class="sec">Не найдено</h1><p class="muted">Такой записи нет.</p>';
        pageFoot();
        return;
    }

    [$u, $why] = talkWho();
    $err = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!csrfOk()) {
            $err = 'Форма устарела. Обновите страницу.';
        } elseif ($u === null) {
            $err = $why;
        } elseif (post('do') === 'com_hide' && isAdmin()) {
            /*  Прятать может только управление. Проверка стоит здесь, а не
             *  у кнопки: спрятанная кнопка — это не защита, запрос шлётся и
             *  без неё. */
            $pdo->prepare('UPDATE news_comments SET hidden = 1 WHERE id = ?')
                ->execute([(int)post('id')]);
            header('Location: /news/?s=' . rawurlencode($slug)); exit;
        } else {
            $body = talkClean(post('body'), COM_MAX, false);
            $wait = talkWait($pdo, 'news_comments', (int)$u['id'], COM_GAP);
            if ($body === '') {
                $err = 'Пустой комментарий.';
            } elseif ($wait > 0) {
                $err = 'Слишком часто. Следующий комментарий можно через ' . $wait . ' с.';
            } else {
                $pdo->prepare(
                    'INSERT INTO news_comments (news_id, user_id, author, body, ip)
                     VALUES (?,?,?,?,?)'
                )->execute([(int)$n['id'], (int)$u['id'], (string)$u['mc_nick'],
                            $body, ipBin()]);
                header('Location: /news/?s=' . rawurlencode($slug) . '#comments'); exit;
            }
        }
    }

    /*  Скрытые показываем только управлению — ему они нужны для разбора. */
    $sql = 'SELECT * FROM news_comments WHERE news_id = ?'
         . (isAdmin() ? '' : ' AND hidden = 0')
         . ' ORDER BY id ASC LIMIT 200';
    $st = $pdo->prepare($sql);
    $st->execute([(int)$n['id']]);
    $coms = $st->fetchAll();

    pageHead($n['title'], 'news');
    ?>
    <article class="post">
      <h1 class="sec"><?= h($n['title']) ?></h1>
      <time><?= h(date('d.m.Y', strtotime((string)$n['created_at']))) ?></time>
      <?php /* nl2br поверх экранированного текста: разметку из базы не
               пускаем, но переносы строк сохраняем. */ ?>
      <div class="body"><?= nl2br(h($n['body'])) ?></div>
    </article>

    <h2 class="sec" id="comments">Обсуждение<?= $coms ? ' · ' . count($coms) : '' ?></h2>

    <?php if ($err !== ''): ?><div class="flash flash-err"><?= h($err) ?></div><?php endif; ?>

    <?php if (!$coms): ?>
      <p class="muted">Пока никто не высказался.</p>
    <?php else: ?>
      <div class="talk">
        <?php foreach ($coms as $c): ?>
          <div class="talk-com<?= $c['hidden'] ? ' talk-hidden' : '' ?>">
            <div class="talk-top">
              <b class="who"><a href="/players/?n=<?= h(rawurlencode((string)$c['author'])) ?>"><?= h($c['author']) ?></a></b>
              <em><?= h(date('d.m.Y H:i', strtotime((string)$c['created_at']))) ?></em>
              <?php if ($c['hidden']): ?><em class="down">скрыто</em><?php endif; ?>
              <?php if (isAdmin() && !$c['hidden']): ?>
                <form method="post" class="inline">
                  <?= csrfField() ?>
                  <input type="hidden" name="do" value="com_hide">
                  <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                  <button class="btn small ghost" type="submit">скрыть</button>
                </form>
              <?php endif; ?>
            </div>
            <p><?= nl2br(h($c['body'])) ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if ($u === null): ?>
      <div class="flash"><?= h($why) ?>
        <?php if (!user()): ?>
          <a href="/login/">Войти</a> · <a href="/register/">зарегистрироваться</a>
        <?php else: ?>
          <a href="/profile/">В кабинет</a>
        <?php endif; ?>
      </div>
    <?php else: ?>
      <form method="post" class="form">
        <?= csrfField() ?>
        <label>От имени <b class="who"><?= h($u['mc_nick']) ?></b>
          <textarea name="body" rows="4" maxlength="<?= COM_MAX ?>" required
                    placeholder="Что думаете?"></textarea>
          <small>До <?= COM_MAX ?> знаков, не чаще раза в <?= COM_GAP ?> секунд</small></label>
        <button class="btn" type="submit">Отправить</button>
      </form>
    <?php endif; ?>

    <p><a href="/news/">← ко всем новостям</a></p>
    <?php pageFoot();
    return;
}

/* ---------------------------------------------------------------------------
 *  СПИСОК
 * ------------------------------------------------------------------------ */
$rows = $pdo->query(
    'SELECT n.id, n.slug, n.title, n.summary, n.created_at,
            (SELECT COUNT(*) FROM news_comments c
              WHERE c.news_id = n.id AND c.hidden = 0) coms
       FROM news n WHERE n.published = 1
      ORDER BY n.created_at DESC LIMIT 40'
)->fetchAll();

pageHead('Новости', 'news');
echo '<h1 class="sec">Новости</h1>';
if (!$rows) { echo '<p class="muted">Записей пока нет.</p>'; }
foreach ($rows as $n) {
    echo '<article class="card"><a href="/news/?s=' . h($n['slug']) . '"><h3>'
       . h($n['title']) . '</h3></a><time>'
       . h(date('d.m.Y', strtotime((string)$n['created_at'])))
       . ((int)$n['coms'] > 0 ? ' · ответов: ' . (int)$n['coms'] : '')
       . '</time>';
    if ($n['summary']) { echo '<p>' . h($n['summary']) . '</p>'; }
    echo '</article>';
}
pageFoot();
