<?php
/* ============================================================================
 *  shop.php — пополнение донат-валюты. Единственный товар на сайте.
 *
 *  ПОЧЕМУ ОДИН ТОВАР. Витрина вещей на сайте означала бы вторую таблицу цен
 *  рядом с игровой — они разошлись бы на первой правке, и человек платил бы
 *  за одно, а получал другое. Здесь продаётся только валюта; что на неё
 *  купить, решают в игре, где цены живут в одном месте.
 *
 *  ПОЛЗУНКА ЗДЕСЬ БОЛЬШЕ НЕТ. Стандартный input[type=range] выглядит
 *  чужеродно и по-разному во всех браузерах, а рисовать свой — возня ради
 *  того, чем пользуются один раз. Поле ввода делает то же самое и точнее,
 *  а быстрые кнопки закрывают случай «прикинуть, не думая».
 *
 *  БОНУС РАСТЁТ СТУПЕНЯМИ, А НЕ ПЛАВНО. Плавный процент никто не считает в
 *  уме; ступени видно глазом, и понятно, что до следующей чуть-чуть.
 *
 *  ПРОЦЕНТЫ СЧИТАЕТ СЕРВЕР. Скрипт на странице только показывает то же
 *  самое: если бы сумму считал браузер, её подделали бы за минуту.
 * ========================================================================= */

require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/layout.php';
require_once __DIR__ . '/../inc/yookassa.php';

/*  СОЗДАНИЕ ПЛАТЕЖА. Сумма приходит из формы, но проверяется и считается
 *  здесь — на странице она только показана. */
$payErr = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfOk()) {
        $payErr = 'Форма устарела. Обновите страницу.';
    } elseif (!user()) {
        $payErr = 'Сначала войдите.';
    } elseif (!isset($_POST['agree'])) {
        $payErr = 'Нужно согласиться с офертой.';
    } else {
        $rub = (int)preg_replace('/[^0-9]/', '', post('rub'));
        $res = ykCreate($pdo, $CFG, user(), $rub, ipBin());
        if ($res['ok']) {
            header('Location: ' . $res['url']);
            exit;
        }
        $payErr = $res['error'];
    }
}

const PAY_MIN = 50;
const PAY_MAX = 100000;

const PAY_TIERS = [
    [0, 0], [500, 5], [1500, 10], [5000, 15], [15000, 20], [50000, 25],
];

/*  Подписи по порогам. Меняются вместе с суммой — не ради лести, а чтобы
 *  человек видел, что его выбор замечен. */
const PAY_WORDS = [
    [0,     'На патроны и бинты хватит.'],
    [300,   'Этого хватит на кейс.'],
    [1000,  'Уже серьёзно. Спасибо.'],
    [5000,  'Это заметный вклад в сервер.'],
    [20000, 'Такое мы запоминаем.'],
    [50000, 'Без таких, как вы, проекта бы не было.'],
];

const PAY_QUICK = [100, 300, 500, 1000, 3000];

$u = user();
pageHead('Пополнение', 'shop');
?>
<h1 class="sec">Пополнение</h1>
<p class="lead">На сайте продаётся одно — талоны <b>✦</b>, внутренняя валюта
сервера. Что купить на них, вы решаете в игре: донат-магазин открывается
командой <b class="mono">/donate</b>.</p>

<div class="flash notice">Не нужны талоны, а хочется просто помочь проекту?
<a href="/donate/">Поддержите разработку</a> — без аккаунта и без привязки ника.</div>

<?php if (!$u): ?>
  <div class="flash">Чтобы пополнить, <a href="/login/">войдите</a> и привяжите
  игровой ник — иначе неизвестно, кому начислять.</div>
<?php elseif (empty($u['mc_nick'])): ?>
  <div class="flash flash-err">Ник не привязан. Привяжите его в
  <a href="/profile/">кабинете</a> — без этого начислять некуда.</div>
<?php endif; ?>

<!--  Три шага над формой: человек, который видит, сколько действий впереди,
      не бросает на середине.
      НЕ СПИСОК <ol> НАРОЧНО — он добавлял свою нумерацию поверх нашей, и
      на экране получалось «1. 1 Выберите сумму». -->
<div class="paysteps">
  <div><b>1</b><span>Выберите сумму</span></div>
  <div><b>2</b><span>Оплатите картой или через СБП</span></div>
  <div><b>3</b><span>Зайдите в игру — талоны уже там</span></div>
</div>

<section class="panel payblock">
  <div class="panel-h">Сколько пополнить</div>
  <div class="pad">
    <div class="payrow">
      <label class="paysum">
        <input id="pv" class="payinput" type="text" inputmode="numeric"
               value="300" aria-label="Сумма пополнения в рублях">
        <span class="cur">₽</span>
      </label>
      <div class="paycoins">начислим <b id="pc">300</b> ✦<span id="pb" class="up"></span></div>
    </div>

    <div class="payquick">
      <?php foreach (PAY_QUICK as $q): ?>
        <button type="button" data-v="<?= (int)$q ?>"><?= number_format($q, 0, '', ' ') ?></button>
      <?php endforeach; ?>
    </div>

    <p class="payends">от <?= PAY_MIN ?> до <?= number_format(PAY_MAX, 0, '', ' ') ?> ₽</p>
    <p class="paynote" id="pn">Этого хватит на кейс.</p>

    <!--  СОГЛАСИЕ С ОФЕРТОЙ ГАЛОЧКОЙ, А НЕ МЕЛКОЙ СТРОКОЙ ПОД КНОПКОЙ.
          Оферта — договор, и момент его принятия должен быть действием
          человека, а не фактом загрузки страницы.
          Свой квадрат вместо стандартного: системную галочку нельзя
          привести к оформлению сайта, её рисует операционная система. -->
    <?php if ($payErr !== ''): ?><div class="flash flash-err"><?= h($payErr) ?></div><?php endif; ?>
    <form method="post" id="pf">
    <?= csrfField() ?>
    <input type="hidden" name="rub" id="prub" value="300">
    <label class="payagree">
      <input type="checkbox" id="pa" name="agree" value="1">
      <span class="box" aria-hidden="true"></span>
      <span>Согласен с <a href="/legal/">офертой</a> и <a href="/rules/">правилами</a></span>
    </label>

    <div class="row">
      <button class="btn" type="submit" id="pgo" disabled>Перейти к оплате</button>
    </div>
    </form>
    <p class="muted small">Оплата картой или через СБП на странице ЮKassa.
    Талоны начисляются на привязанный ник.</p>
  </div>
</section>

<h2 class="sec">Как приходит покупка</h2>
<ol class="rules">
  <li><b>Привяжите ник</b> в кабинете — покупка начисляется на него.</li>
  <li><b>Оплатите</b> выбранную сумму.</li>
  <li><b>Зайдите в игру.</b> Талоны начисляются при входе. Если вы уже в
      игре — в течение минуты.</li>
</ol>
<p class="muted small">Заказ хранится за вами и не сгорает. Условия, возврат и
реквизиты продавца — на странице <a href="/legal/">реквизитов</a>.</p>

<script nonce="<?= h(cspNonce()) ?>">
(function () {
  var tiers = <?= json_encode(PAY_TIERS) ?>,
      words = <?= json_encode(PAY_WORDS, JSON_UNESCAPED_UNICODE) ?>,
      v  = document.getElementById('pv'), c = document.getElementById('pc'),
      b  = document.getElementById('pb'), n = document.getElementById('pn'),
      hid = document.getElementById('prub'), agree = document.getElementById('pa'),
      go = document.getElementById('pgo'),
      cur = 300;

  function clamp(x) { return Math.max(<?= PAY_MIN ?>, Math.min(<?= PAY_MAX ?>, x)); }
  function pct(x)   { var p = 0; tiers.forEach(function (t) { if (x >= t[0]) { p = t[1]; } }); return p; }
  function word(x)  { var w = ''; words.forEach(function (t) { if (x >= t[0]) { w = t[1]; } }); return w; }
  function fmt(x)   { return String(x).replace(/(\d)(?=(\d{3})+$)/g, '$1 '); }

  function draw(typing) {
    var p = pct(cur), coins = Math.floor(cur * (100 + p) / 100);
    // Пока печатают, поле не трогаем: подстановка отформатированного числа
    // посреди набора сбивает курсор в начало строки.
    if (!typing) { v.value = fmt(cur); }
    c.textContent = fmt(coins);
    b.textContent = p > 0 ? ' +' + p + '%' : '';
    n.textContent = word(cur);
    // Скрытое поле — единственное, что уходит на сервер. Всё остальное на
    // странице только показывает.
    hid.value = cur;
  }

  //  Кнопка оживает только после галочки: оферта принимается действием.
  function lock() { go.disabled = !agree.checked; }
  agree.addEventListener('change', lock);
  lock();

  v.addEventListener('input', function () {
    var raw = v.value.replace(/[^0-9]/g, '');
    if (raw === '') { return; }
    cur = clamp(parseInt(raw, 10));
    draw(true);
  });
  v.addEventListener('blur', function () { draw(); });
  v.addEventListener('keydown', function (e) { if (e.key === 'Enter') { v.blur(); } });

  Array.prototype.forEach.call(document.querySelectorAll('.payquick button'), function (btn) {
    btn.addEventListener('click', function () { cur = clamp(+btn.getAttribute('data-v')); draw(); });
  });

  draw();
})();
</script>
<?php pageFoot();
