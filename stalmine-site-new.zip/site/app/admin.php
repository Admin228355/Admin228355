<?php
/* Напрямую из браузера не открывается: настоящий адрес страницы — /admin/.
 * Файл лежит в app/ и подключается из admin/index.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}
?>
<?php
/* ============================================================================
 *  admin.php — управление сайтом.
 *
 *  ОДНИМ ФАЙЛОМ, НО РАЗНЫМИ РАЗДЕЛАМИ. Раньше здесь была одна лента: чтобы
 *  дойти до новостей, приходилось проматывать все сообщения об ошибках, а
 *  страница каждый раз тянула из базы всё сразу. Теперь разделы разнесены
 *  по вкладкам — но файл остался один, и это нарочно: проверка прав должна
 *  стоять в одном месте. Пять файлов — это пять шансов её забыть, а забытая
 *  проверка означает открытую всем админку.
 *
 *  ВКЛАДКА ОБЫЧНОЙ ССЫЛКОЙ, А НЕ СКРИПТОМ. Раздел попадает в адрес: его
 *  можно положить в закладки, открыть в новом окне и вернуться назад
 *  кнопкой браузера. Скриптовые вкладки не умеют ничего из этого.
 *
 *  ДАННЫЕ ТЯНЕМ ТОЛЬКО ДЛЯ ОТКРЫТОГО РАЗДЕЛА. Исключение — счётчики над
 *  вкладками: они нужны всегда, иначе о новом сообщении узнаёшь, только
 *  зайдя в раздел. Все три считаются одним запросом.
 *
 *  Всё, что меняет данные, идёт только методом POST и только с токеном:
 *  ссылка «удалить» вида admin.php?del=3 срабатывает от чужой картинки на
 *  чужом сайте, и узнать, кто удалил новость, потом невозможно.
 * ========================================================================= */

require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/auth.php';
require_once __DIR__ . '/../inc/layout.php';

$me = needAdmin();

/* Адрес новости из заголовка. Кириллицу переводим в латиницу: адрес с
 * русскими буквами браузер показывает как %D0%9A%D1%8B…, и такую ссылку
 * невозможно ни прочитать, ни продиктовать. */
function slugify(string $s): string {
    $map = ['а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'e',
            'ж'=>'zh','з'=>'z','и'=>'i','й'=>'y','к'=>'k','л'=>'l','м'=>'m',
            'н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u',
            'ф'=>'f','х'=>'h','ц'=>'c','ч'=>'ch','ш'=>'sh','щ'=>'sch','ъ'=>'',
            'ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya'];
    $s = strtr(mb_strtolower(trim($s)), $map);
    $s = preg_replace('/[^a-z0-9]+/u', '-', $s) ?? '';
    $s = trim($s, '-');
    return $s === '' ? 'zapis-' . date('Ymd-His') : mb_substr($s, 0, 70);
}

/*  ПРОВЕРКА АДРЕСА ССЫЛКИ. Пускаем только http и https.
 *
 *  Без этого в поле можно вписать «javascript:...», и подвал на КАЖДОЙ
 *  странице сайта получит рабочую кнопку с чужим кодом. Что ссылки заводит
 *  владелец, роли не играет: заводит их тот, кто вошёл в управление. */
function okUrl(string $u): bool {
    $u = trim($u);
    if ($u === '' || mb_strlen($u) > 300) { return false; }
    $s = strtolower(parse_url($u, PHP_URL_SCHEME) ?? '');
    return ($s === 'http' || $s === 'https') && parse_url($u, PHP_URL_HOST);
}

/* Какой раздел открыт. Неизвестное имя — на сводку, а не «пустая страница». */
const ADM_TABS = ['svodka', 'chat', 'nicks', 'pay', 'bugs', 'news', 'links', 'set'];
$tab = (string)($_GET['t'] ?? 'svodka');
if (!in_array($tab, ADM_TABS, true)) { $tab = 'svodka'; }

/** Уйти обратно в тот же раздел: после сохранения человек должен остаться
 *  там, где работал, а не оказаться на сводке. */
function admBack(string $tab, string $anchor = ''): never {
    header('Location: /admin/?t=' . $tab . $anchor);
    exit;
}

$err = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfOk()) {
        $err[] = 'Форма устарела. Обновите страницу и попробуйте ещё раз.';
    } else {
        $do = post('do');

        /* --- новость: создать или переписать ------------------------------ */
        if ($do === 'news_save') {
            $id      = (int)post('id');
            $title   = trim(post('title'));
            $summary = trim(post('summary'));
            $body    = trim(post('body'));
            $slug    = trim(post('slug'));
            $pub     = isset($_POST['published']) ? 1 : 0;

            if ($title === '')             { $err[] = 'Заголовок пустой.'; }
            if ($body === '')              { $err[] = 'Текст пустой.'; }
            if (mb_strlen($summary) > 400) { $err[] = 'Подводка длиннее 400 знаков.'; }
            if ($slug === '')              { $slug = slugify($title); }

            if (!$err) {
                try {
                    if ($id > 0) {
                        $pdo->prepare(
                            'UPDATE news SET slug = ?, title = ?, summary = ?, body = ?, published = ?
                              WHERE id = ?'
                        )->execute([$slug, $title, ($summary ?: null), $body, $pub, $id]);
                        flash('Запись сохранена.');
                    } else {
                        $pdo->prepare(
                            'INSERT INTO news (slug, title, summary, body, author_id, published)
                             VALUES (?, ?, ?, ?, ?, ?)'
                        )->execute([$slug, $title, ($summary ?: null), $body, (int)$me['id'], $pub]);
                        flash('Запись создана.');
                    }
                    admBack('news');
                } catch (PDOException $e) {
                    error_log('news_save: ' . $e->getMessage());
                    /* Единственная реальная причина — занятый адрес: он
                     * уникален в базе, и это правильно. */
                    $err[] = 'Такой адрес записи уже занят. Поменяйте адрес.';
                }
            }
        }

        /* --- новость: удалить --------------------------------------------- */
        if ($do === 'news_del') {
            $pdo->prepare('DELETE FROM news WHERE id = ?')->execute([(int)post('id')]);
            flash('Запись удалена.');
            admBack('news');
        }

        /* --- ник: подтвердить --------------------------------------------
         *  Код выдаётся в кабинете, сюда попадает вместе с ником и хозяином.
         *  Подтверждение и пометка «использован» идут ОДНОЙ транзакцией:
         *  иначе при обрыве между ними код останется рабочим, а ник уже
         *  будет привязан — и тем же кодом его привяжут ещё раз. */
        if ($do === 'nick_ok') {
            $code = post('code');
            $st = $pdo->prepare(
                'SELECT * FROM link_codes WHERE code = ? AND used_at IS NULL
                   AND expires_at > NOW() LIMIT 1'
            );
            $st->execute([$code]);
            $lc = $st->fetch();
            if (!$lc) {
                $err[] = 'Код не найден, уже использован или просрочен.';
            } else {
                try {
                    $pdo->beginTransaction();
                    $pdo->prepare('UPDATE users SET mc_nick = ? WHERE id = ?')
                        ->execute([$lc['mc_nick'], (int)$lc['user_id']]);
                    $pdo->prepare('UPDATE link_codes SET used_at = NOW() WHERE code = ?')
                        ->execute([$code]);
                    $pdo->commit();
                    flash('Ник ' . $lc['mc_nick'] . ' привязан.');
                    admBack('nicks');
                } catch (PDOException $e) {
                    $pdo->rollBack();
                    error_log('nick_ok: ' . $e->getMessage());
                    $err[] = 'Этот ник уже привязан к другому аккаунту.';
                }
            }
        }

        /* --- ник: отклонить ------------------------------------------------ */
        if ($do === 'nick_no') {
            $pdo->prepare('DELETE FROM link_codes WHERE code = ?')->execute([post('code')]);
            flash('Заявка отклонена.');
            admBack('nicks');
        }

        /* --- сообщение об ошибке: разбор -----------------------------------
         *  Состояние, ответ и сумма ставятся одной формой: разбирая находку,
         *  всё это решается за один раз, и три отдельные кнопки означали бы
         *  три захода в базу за одним и тем же.
         *
         *  Отметка «выдано» отдельная и НЕОБРАТИМАЯ по смыслу: сумма может
         *  быть назначена сегодня, а выдана в игре завтра, и без отметки
         *  одну находку легко оплатить дважды. */
        if ($do === 'bug_save') {
            $id     = (int)post('id');
            $status = post('status');
            $reward = max(0, min(1000000, (int)post('reward')));
            $note   = mb_substr(trim(post('admin_note')), 0, 500);
            $paid   = isset($_POST['paid']);
            if (!in_array($status, ['new', 'confirmed', 'fixed', 'rejected', 'duplicate'], true)) {
                $err[] = 'Неизвестное состояние.';
            } else {
                $pdo->prepare(
                    'UPDATE bug_reports
                        SET status = ?, reward = ?, admin_note = ?,
                            paid_at = CASE WHEN ? = 1 AND paid_at IS NULL THEN NOW() ELSE paid_at END
                      WHERE id = ?'
                )->execute([$status, $reward, ($note ?: null), $paid ? 1 : 0, $id]);
                flash('Сообщение №' . $id . ' обновлено.');
                admBack('bugs');
            }
        }

        /* --- ссылка на сообщество: сохранить ------------------------------- */
        if ($do === 'link_save') {
            $id    = (int)post('id');
            $kind  = post('kind');
            $title = mb_substr(trim(post('title')), 0, 60);
            $url   = trim(post('url'));
            $note  = mb_substr(trim(post('note')), 0, 120);
            $sort  = max(-999, min(999, (int)post('sort')));
            $vis   = isset($_POST['visible']) ? 1 : 0;

            if (!isset(LINK_KINDS[$kind])) { $err[] = 'Неизвестный вид ссылки.'; }
            if ($title === '')             { $err[] = 'У ссылки нет названия.'; }
            if (!okUrl($url))              { $err[] = 'Адрес должен начинаться с http:// или https://'; }

            if (!$err) {
                if ($id > 0) {
                    $pdo->prepare(
                        'UPDATE site_links SET kind=?, title=?, url=?, note=?, sort=?, visible=?
                          WHERE id=?'
                    )->execute([$kind, $title, $url, ($note ?: null), $sort, $vis, $id]);
                    flash('Ссылка сохранена.');
                } else {
                    $pdo->prepare(
                        'INSERT INTO site_links (kind, title, url, note, sort, visible)
                         VALUES (?,?,?,?,?,?)'
                    )->execute([$kind, $title, $url, ($note ?: null), $sort, $vis]);
                    flash('Ссылка добавлена.');
                }
                admBack('links');
            }
        }

        /* --- ссылка: удалить ----------------------------------------------- */
        if ($do === 'link_del') {
            $pdo->prepare('DELETE FROM site_links WHERE id = ?')->execute([(int)post('id')]);
            flash('Ссылка удалена.');
            admBack('links');
        }

        /* --- написать в игровой чат ----------------------------------------
         *  Сообщение не уходит никуда сразу: оно ложится в очередь, а
         *  игровой сервер забирает её мостом. Если сервер выключен,
         *  написанное дождётся его включения, а не пропадёт. */
        if ($do === 'msg_send') {
            $body = mb_substr(trim(post('body')), 0, 300);
            if ($body === '') {
                $err[] = 'Пустое сообщение.';
            } else {
                $pdo->prepare('INSERT INTO site_msgs (user_id, author, body) VALUES (?, ?, ?)')
                    ->execute([(int)$me['id'], (string)($me['mc_nick'] ?: $me['login']), $body]);
                flash('Отправлено — появится в игре в течение нескольких секунд.');
                admBack('chat');
            }
        }

        /* --- отменить неотправленное ---------------------------------------
         *  Только пока не показано: стирать показанное бессмысленно, из
         *  чужого чата оно уже не пропадёт. */
        if ($do === 'msg_del') {
            $pdo->prepare('DELETE FROM site_msgs WHERE id = ? AND sent_at IS NULL')
                ->execute([(int)post('id')]);
            flash('Сообщение снято из очереди.');
            admBack('chat');
        }

        /* --- настройки ------------------------------------------------------
         *  Пустое значение стирается, а не пишется пустой строкой: пусто
         *  должно означать «работает значение по умолчанию», а не «показывай
         *  ничего». Особенно это важно для адреса сервера. */
        if ($do === 'set_save') {
            foreach (['meta_desc' => 400, 'notice' => 300, 'mc_show' => 80] as $k => $max) {
                settingSet($pdo, $k, mb_substr(trim(post($k)), 0, $max));
            }
            flash('Настройки сохранены.');
            admBack('set');
        }
    }
}

/*  СЧЁТЧИКИ НАД ВКЛАДКАМИ — ОДНИМ ЗАПРОСОМ.
 *
 *  «Ждёт выдачи» тут не для красоты: с работающим мостом платежи уходят в
 *  игру за полминуты, и любое число больше нуля дольше пяти минут означает,
 *  что мост встал. Это единственное место, где такое видно, не заходя на
 *  игровой сервер. */
$cnt = $pdo->query(
    "SELECT
       (SELECT COUNT(*) FROM link_codes WHERE used_at IS NULL AND expires_at > NOW()) nicks,
       (SELECT COUNT(*) FROM bug_reports WHERE status = 'new') bugs,
       (SELECT COUNT(*) FROM payments WHERE status = 'paid') paywait,
       (SELECT COUNT(*) FROM payments
         WHERE status = 'paid' AND paid_at < NOW() - INTERVAL 5 MINUTE) paystuck,
       (SELECT COUNT(*) FROM site_msgs WHERE sent_at IS NULL) msgwait"
)->fetch();

pageHead('Управление', 'admin');

/*  Число рядом с названием вкладки — только там, где оно означает работу
 *  для человека. У «Новостей» и «Настроек» его нет: показывать «новостей 4»
 *  бессмысленно, это не задача. */
$tabs = [
    'svodka' => ['Сводка',     0],
    'chat'   => ['Чат в игре', (int)$cnt['msgwait']],
    'nicks'  => ['Ники',       (int)$cnt['nicks']],
    'pay'    => ['Платежи',    (int)$cnt['paystuck']],
    'bugs'   => ['Ошибки',     (int)$cnt['bugs']],
    'news'   => ['Новости',    0],
    'links'  => ['Сообщества', 0],
    'set'    => ['Настройки',  0],
];
?>
<h1 class="sec">Управление</h1>
<?php foreach ($err as $e): ?><div class="flash flash-err"><?= h($e) ?></div><?php endforeach; ?>

<nav class="adm">
  <?php foreach ($tabs as $k => [$label, $n]): ?>
    <a href="/admin/?t=<?= h($k) ?>"<?= $k === $tab ? ' class="on"' : '' ?>><?= h($label) ?><?php
       if ($n > 0): ?> <b><?= $n ?></b><?php endif; ?></a>
  <?php endforeach; ?>
</nav>

<?php /* ========================================================= СВОДКА == */
if ($tab === 'svodka'):
    $sum = $pdo->query(
        "SELECT COUNT(*) n, COALESCE(SUM(amount_rub),0) rub, COALESCE(SUM(coins),0) coins
           FROM payments WHERE status IN ('paid','granted','donated')"
    )->fetch();
    $today = (int)$pdo->query(
        "SELECT COALESCE(SUM(amount_rub),0) FROM payments
          WHERE status IN ('paid','granted','donated') AND paid_at >= CURDATE()"
    )->fetchColumn();
    $users = $pdo->query(
        'SELECT COUNT(*) n, SUM(mc_nick IS NOT NULL) linked FROM users'
    )->fetch();
    $newsN = (int)$pdo->query('SELECT COUNT(*) FROM news WHERE published = 1')->fetchColumn();
?>
  <div class="tiles">
    <div><span>Получено всего</span><b><?= number_format((int)$sum['rub'], 0, '', ' ') ?> ₽</b>
      <small><?= (int)$sum['n'] ?> платеж(ей)</small></div>
    <div><span>Сегодня</span><b><?= number_format($today, 0, '', ' ') ?> ₽</b>
      <small>с полуночи</small></div>
    <div><span>Начислено талонов</span><b><?= number_format((int)$sum['coins'], 0, '', ' ') ?></b>
      <small>всего за всё время</small></div>
    <div><span>Аккаунтов</span><b><?= (int)$users['n'] ?></b>
      <small>с привязанным ником — <?= (int)$users['linked'] ?></small></div>
    <div><span>Новостей</span><b><?= $newsN ?></b><small>опубликовано</small></div>
    <div><span>Ошибок на разборе</span><b class="<?= (int)$cnt['bugs'] ? 'down' : '' ?>"><?= (int)$cnt['bugs'] ?></b>
      <small>ждут ответа</small></div>
  </div>

  <?php /*  СОСТОЯНИЕ МОСТА. Не «работает ли скрипт», а единственное, что
            важно: доехали ли деньги до игры. Если платёж висит оплаченным
            дольше пяти минут — не доехали. */ ?>
  <section class="panel">
    <div class="panel-h">Мост с игрой</div>
    <div class="readout">
      <div><span>Ждут выдачи в игре</span>
        <b class="num <?= (int)$cnt['paywait'] ? '' : 'up' ?>"><?= (int)$cnt['paywait'] ?></b></div>
      <div><span>Из них висят дольше 5 минут</span>
        <b class="num <?= (int)$cnt['paystuck'] ? 'down' : 'up' ?>"><?= (int)$cnt['paystuck'] ?></b></div>
    </div>
    <p class="pad muted small">
      <?php if ((int)$cnt['paystuck'] > 0): ?>
        Похоже, мост стоит: обычно оплата уходит в игру за полминуты. Проверьте,
        запущен ли игровой сервер — в его консоли команда <b class="mono">bridge</b>
        покажет, доходит ли опрос до сайта.
      <?php else: ?>
        Оплата уходит в игру сама, обычно за полминуты. Ноль в обеих строках —
        это норма, значит, всё выдано.
      <?php endif; ?>
    </p>
  </section>

  <h2 class="sec">Что сделать</h2>
  <ol class="rules">
    <?php if ((int)$cnt['nicks']): ?>
      <li>Подтвердить <b><?= (int)$cnt['nicks'] ?></b> заявк(и) на ник —
        <a href="/admin/?t=nicks">раздел «Ники»</a>.</li>
    <?php endif; ?>
    <?php if ((int)$cnt['bugs']): ?>
      <li>Разобрать <b><?= (int)$cnt['bugs'] ?></b> сообщени(я) об ошибках —
        <a href="/admin/?t=bugs">раздел «Ошибки»</a>.</li>
    <?php endif; ?>
    <?php if (!siteLinks($pdo, false)): ?>
      <li>Добавить ссылки на телеграм и youtube —
        <a href="/admin/?t=links">раздел «Сообщества»</a>. Пока их нет,
        подвал сайта пустой, и людям негде узнать актуальные адреса.</li>
    <?php endif; ?>
    <?php if (!(int)$cnt['nicks'] && !(int)$cnt['bugs'] && siteLinks($pdo, false)): ?>
      <li class="muted">Ничего не ждёт. Можно писать новость.</li>
    <?php endif; ?>
  </ol>

<?php /* ============================================================ ЧАТ == */
elseif ($tab === 'chat'):
    $msgs = $pdo->query(
        'SELECT * FROM site_msgs ORDER BY id DESC LIMIT 40'
    )->fetchAll();
?>
  <h2 class="sec">Написать игрокам</h2>
  <p class="muted">Сообщение появится в игровом чате с пометкой
  <b class="mono">[САЙТ]</b> и вашим ником — чтобы его нельзя было принять за
  слова игрока, стоящего рядом. Сервер забирает написанное раз в несколько
  секунд; если он выключен, сообщение дождётся включения и не пропадёт.</p>

  <form method="post" class="form">
    <?= csrfField() ?>
    <input type="hidden" name="do" value="msg_send">
    <label>Текст
      <textarea name="body" rows="3" maxlength="300" required
        placeholder="Через десять минут заброска у комбината"></textarea>
      <small>До 300 знаков. Коды цвета не работают — их вырезает мост,
      иначе Skript портит строку целиком</small></label>
    <button class="btn" type="submit">Отправить в игру</button>
  </form>

  <h2 class="sec">Что уже писали</h2>
  <?php if (!$msgs): ?>
    <p class="muted">Пока ничего.</p>
  <?php else: ?>
  <div class="tw">
  <table>
    <thead><tr><th>Когда</th><th>Кто</th><th>Текст</th><th>Показано</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($msgs as $m): ?>
      <tr>
        <td class="num"><?= h(date('d.m H:i', strtotime((string)$m['created_at']))) ?></td>
        <td class="who"><?= h($m['author']) ?></td>
        <td><?= h($m['body']) ?></td>
        <td><?= $m['sent_at']
              ? '<b class="up">' . h(date('H:i:s', strtotime((string)$m['sent_at']))) . '</b>'
              : '<b class="down">в очереди</b>' ?></td>
        <td><?php if (!$m['sent_at']): ?>
          <form method="post" class="inline">
            <?= csrfField() ?>
            <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
            <button class="btn small ghost" name="do" value="msg_del">снять</button>
          </form>
        <?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>

<?php /* =========================================================== НИКИ == */
elseif ($tab === 'nicks'):
    $codes = $pdo->query(
        'SELECT c.code, c.mc_nick, c.expires_at, u.login
           FROM link_codes c JOIN users u ON u.id = c.user_id
          WHERE c.used_at IS NULL AND c.expires_at > NOW()
          ORDER BY c.expires_at DESC'
    )->fetchAll();
?>
  <h2 class="sec">Заявки на привязку ника</h2>
  <?php if (!$codes): ?>
    <p class="muted">Заявок нет. Человек получает код в своём кабинете, называет
    его вам — и код появляется здесь.</p>
  <?php else: ?>
  <div class="tw">
  <table>
    <thead><tr><th>Код</th><th>Аккаунт</th><th>Ник в игре</th><th>Годен до</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($codes as $c): ?>
      <tr>
        <td class="num"><?= h($c['code']) ?></td>
        <td><?= h($c['login']) ?></td>
        <td class="who"><?= h($c['mc_nick']) ?></td>
        <td class="num"><?= h(date('d.m.Y H:i', strtotime((string)$c['expires_at']))) ?></td>
        <td>
          <form method="post" class="inline">
            <?= csrfField() ?>
            <input type="hidden" name="code" value="<?= h($c['code']) ?>">
            <button class="btn small" name="do" value="nick_ok">Привязать</button>
            <button class="btn small ghost" name="do" value="nick_no">Отклонить</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>

<?php /* ======================================================== ПЛАТЕЖИ == */
elseif ($tab === 'pay'):
    $sum = $pdo->query(
        "SELECT COUNT(*) n, COALESCE(SUM(amount_rub),0) rub, COALESCE(SUM(coins),0) coins
           FROM payments WHERE status IN ('paid','granted','donated')"
    )->fetch();
    $today = (int)$pdo->query(
        "SELECT COALESCE(SUM(amount_rub),0) FROM payments
          WHERE status IN ('paid','granted','donated') AND paid_at >= CURDATE()"
    )->fetchColumn();
    /*  Пожертвования считаем отдельно: в «Получено» они входят, но
     *  талонов за них нет, и без отдельной плитки не видно, сколько
     *  пришло просто так. */
    $don = $pdo->query(
        "SELECT COUNT(*) n, COALESCE(SUM(amount_rub),0) rub
           FROM payments WHERE status = 'donated'"
    )->fetch();
    $top = $pdo->query(
        "SELECT mc_nick, COUNT(*) n, SUM(amount_rub) rub, SUM(coins) coins,
                SUM(status = 'paid') waiting
           FROM payments WHERE status IN ('paid','granted') AND mc_nick IS NOT NULL
          GROUP BY mc_nick ORDER BY rub DESC LIMIT 50"
    )->fetchAll();
    $last = $pdo->query(
        "SELECT mc_nick, amount_rub, coins, status, created_at, paid_at
           FROM payments ORDER BY id DESC LIMIT 30"
    )->fetchAll();
?>
  <div class="tiles">
    <div><span>Получено</span><b><?= number_format((int)$sum['rub'], 0, '', ' ') ?> ₽</b>
      <small><?= (int)$sum['n'] ?> платеж(ей)</small></div>
    <div><span>Сегодня</span><b><?= number_format($today, 0, '', ' ') ?> ₽</b><small>с полуночи</small></div>
    <div><span>Талонов выдано</span><b><?= number_format((int)$sum['coins'], 0, '', ' ') ?></b><small>всего</small></div>
    <div><span>Пожертвования</span><b><?= number_format((int)$don['rub'], 0, '', ' ') ?> ₽</b>
      <small><?= (int)$don['n'] ?> шт., без аккаунта</small></div>
    <div><span>Ждёт выдачи</span><b class="<?= (int)$cnt['paywait'] ? 'down' : 'up' ?>"><?= (int)$cnt['paywait'] ?></b>
      <small>мост забирает сам</small></div>
  </div>

  <h2 class="sec">Кто сколько внёс</h2>
  <?php if (!$top): ?>
    <p class="muted">Пока никто.</p>
  <?php else: ?>
  <div class="tw">
  <table>
    <thead><tr><th>#</th><th>Ник</th><th>Платежей</th><th>Сумма</th><th>Талонов</th><th>Ждёт выдачи</th></tr></thead>
    <tbody>
    <?php foreach ($top as $i => $p): ?>
      <tr>
        <td class="num"><?= $i + 1 ?></td>
        <td class="who"><?= h($p['mc_nick']) ?></td>
        <td class="num"><?= (int)$p['n'] ?></td>
        <td class="num"><?= number_format((int)$p['rub'], 0, '', ' ') ?> ₽</td>
        <td class="num"><?= number_format((int)$p['coins'], 0, '', ' ') ?> ✦</td>
        <td class="num"><?= (int)$p['waiting'] > 0 ? '<b class="down">' . (int)$p['waiting'] . '</b>' : '—' ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>

  <h2 class="sec">Последние платежи</h2>
  <?php if (!$last): ?><p class="muted">Платежей ещё не было.</p><?php else: ?>
  <div class="tw">
  <table>
    <thead><tr><th>Когда</th><th>Ник</th><th>Сумма</th><th>Талонов</th><th>Состояние</th></tr></thead>
    <tbody>
    <?php foreach ($last as $p): [$lb, $cl] = payState((string)$p['status']); ?>
      <tr>
        <td class="num"><?= h(date('d.m.Y H:i', strtotime((string)$p['created_at']))) ?></td>
        <td class="who"><?= $p['mc_nick'] ? h($p['mc_nick']) : '<span class="muted">пожертвование</span>' ?></td>
        <td class="num"><?= (int)$p['amount_rub'] ?> ₽</td>
        <td class="num"><?= (int)$p['coins'] ?> ✦</td>
        <td><b class="<?= h($cl) ?>"><?= h($lb) ?></b></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>

<?php /* ========================================================= ОШИБКИ == */
elseif ($tab === 'bugs'):
    /* Неразобранные — вверху и целиком; разобранные — свёрнутым списком
       ниже. Смешивать нельзя: разобранных за месяц накопятся сотни, и новое
       сообщение потеряется среди них. */
    $bugsNew = $pdo->query(
        "SELECT b.*, u.login FROM bug_reports b LEFT JOIN users u ON u.id = b.user_id
          WHERE b.status = 'new' ORDER BY b.created_at ASC"
    )->fetchAll();
    $bugsOld = $pdo->query(
        "SELECT b.*, u.login FROM bug_reports b LEFT JOIN users u ON u.id = b.user_id
          WHERE b.status <> 'new' ORDER BY b.updated_at DESC LIMIT 60"
    )->fetchAll();

    /** Карточка сообщения. Вынесена, чтобы разобранные и неразобранные
     *  рисовались одним и тем же кодом: разойдясь, две копии начнут
     *  показывать одно и то же по-разному. */
    $card = function (array $b): void {
        [$label, $cls] = bugState((string)$b['status']); ?>
      <article class="panel" style="margin:14px 0">
        <div class="panel-h">№<?= (int)$b['id'] ?> · <?= h($b['login'] ?: 'удалён') ?><?=
          $b['mc_nick'] ? ' · ' . h($b['mc_nick']) : '' ?> ·
          <?= h(date('d.m.Y H:i', strtotime((string)$b['created_at']))) ?> ·
          <b class="<?= h($cls) ?>"><?= h($label) ?></b></div>
        <div class="pad">
          <h3><?= h($b['title']) ?></h3>
          <?php if ($b['where_at']): ?><p class="muted small">Где: <?= h($b['where_at']) ?></p><?php endif; ?>
          <p><b>Что делал:</b><br><?= nl2br(h($b['steps'])) ?></p>
          <?php if ($b['expected']): ?><p><b>Ожидал:</b><br><?= nl2br(h($b['expected'])) ?></p><?php endif; ?>
          <form method="post" class="form">
            <?= csrfField() ?>
            <input type="hidden" name="do" value="bug_save">
            <input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
            <label>Состояние
              <select name="status">
                <?php foreach (['new','confirmed','fixed','rejected','duplicate'] as $s):
                      [$lb] = bugState($s); ?>
                  <option value="<?= h($s) ?>"<?= $b['status'] === $s ? ' selected' : '' ?>><?= h($lb) ?></option>
                <?php endforeach; ?>
              </select></label>
            <label>Начислить, ₽<input name="reward" type="number" min="0" step="100"
              value="<?= (int)$b['reward'] ?>"><small>Выдаётся в игре командой
              <b class="mono">donate give ник сумма</b></small></label>
            <label>Ответ автору<input name="admin_note" maxlength="500"
              value="<?= h($b['admin_note'] ?? '') ?>"><small>Видно ему на странице «Ошибки»</small></label>
            <label class="check"><input type="checkbox" name="paid" value="1"
              <?= $b['paid_at'] ? 'checked disabled' : '' ?>> Деньги выданы
              <?= $b['paid_at'] ? '(' . h(date('d.m.Y', strtotime((string)$b['paid_at']))) . ')' : '' ?></label>
            <button class="btn" type="submit">Сохранить</button>
          </form>
        </div>
      </article>
    <?php };
?>
  <h2 class="sec">На разборе<?= $bugsNew ? ' · ' . count($bugsNew) : '' ?></h2>
  <?php if (!$bugsNew): ?>
    <p class="muted">Ничего не ждёт разбора.</p>
  <?php else: foreach ($bugsNew as $b) { $card($b); } endif; ?>

  <?php if ($bugsOld): ?>
  <details class="fold">
    <summary>Разобранные — <?= count($bugsOld) ?></summary>
    <div class="inner">
      <?php foreach ($bugsOld as $b) { $card($b); } ?>
    </div>
  </details>
  <?php endif; ?>

<?php /* ======================================================== НОВОСТИ == */
elseif ($tab === 'news'):
    /* Что правим: ?edit=<id> открывает существующую запись в той же форме. */
    $edit = null;
    if (isset($_GET['edit'])) {
        $st = $pdo->prepare('SELECT * FROM news WHERE id = ? LIMIT 1');
        $st->execute([(int)$_GET['edit']]);
        $edit = $st->fetch() ?: null;
    }
    $rows = $pdo->query(
        'SELECT n.id, n.slug, n.title, n.published, n.created_at, u.login AS author
           FROM news n LEFT JOIN users u ON u.id = n.author_id
          ORDER BY n.created_at DESC LIMIT 100'
    )->fetchAll();
?>
  <h2 class="sec"><?= $edit ? 'Правка записи' : 'Новая запись' ?></h2>
  <form method="post" class="form">
    <?= csrfField() ?>
    <input type="hidden" name="do" value="news_save">
    <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
    <label>Заголовок<input name="title" required maxlength="200"
      value="<?= h($edit['title'] ?? post('title')) ?>"></label>
    <label>Адрес записи <span class="opt">— можно не трогать</span>
      <input name="slug" maxlength="80" value="<?= h($edit['slug'] ?? '') ?>">
      <small>Останется в ссылке: /news/?s=<b>адрес</b>. Пусто — соберём из заголовка</small></label>
    <label>Подводка <span class="opt">— строка под заголовком в списке</span>
      <input name="summary" maxlength="400" value="<?= h($edit['summary'] ?? '') ?>"></label>
    <label>Текст
      <textarea name="body" rows="14" required><?= h($edit['body'] ?? '') ?></textarea>
      <small>Обычный текст. Разметка не нужна и не сработает — переносы строк
      сохранятся сами</small></label>
    <label class="check"><input type="checkbox" name="published" value="1"
      <?= (!$edit || $edit['published']) ? 'checked' : '' ?>> Показывать на сайте</label>
    <button class="btn" type="submit"><?= $edit ? 'Сохранить' : 'Опубликовать' ?></button>
    <?php if ($edit): ?><p><a href="/admin/?t=news" class="muted">отменить правку</a></p><?php endif; ?>
  </form>

  <h2 class="sec">Все записи</h2>
  <?php if (!$rows): ?>
    <p class="muted">Записей ещё нет.</p>
  <?php else: ?>
  <div class="tw">
  <table>
    <thead><tr><th>Дата</th><th>Заголовок</th><th>Кто</th><th>Видно</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td class="num"><?= h(date('d.m.Y', strtotime((string)$r['created_at']))) ?></td>
        <td><a href="/news/?s=<?= h($r['slug']) ?>"><?= h($r['title']) ?></a></td>
        <td><?= h($r['author'] ?: '—') ?></td>
        <td><?= $r['published'] ? '<b class="up">да</b>' : '<b class="down">черновик</b>' ?></td>
        <td>
          <a href="/admin/?t=news&edit=<?= (int)$r['id'] ?>">править</a>
          <form method="post" class="inline" data-ask="Удалить запись без возврата?">
            <?= csrfField() ?>
            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <button class="btn small ghost" name="do" value="news_del">удалить</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php endif; ?>

<?php /* ===================================================== СООБЩЕСТВА == */
elseif ($tab === 'links'):
    $links = siteLinks($pdo, false);

    /** Одна строка списка — она же форма. Правится на месте, без перехода
     *  на отдельную страницу: ссылок мало, и открывать ради галочки
     *  «показывать» новую страницу — лишний шаг. */
    $row = function (?array $l): void { ?>
      <form method="post" class="linkrow">
        <?= csrfField() ?>
        <input type="hidden" name="do" value="link_save">
        <input type="hidden" name="id" value="<?= (int)($l['id'] ?? 0) ?>">
        <label>Вид
          <select name="kind">
            <?php foreach (LINK_KINDS as $k => $name): ?>
              <option value="<?= h($k) ?>"<?= ($l['kind'] ?? 'telegram') === $k ? ' selected' : '' ?>><?= h($name) ?></option>
            <?php endforeach; ?>
          </select></label>
        <label>Название<input name="title" maxlength="60" required
          value="<?= h($l['title'] ?? '') ?>" placeholder="Наш канал"></label>
        <label>Адрес<input name="url" maxlength="300" required
          value="<?= h($l['url'] ?? '') ?>" placeholder="https://t.me/..."></label>
        <label>Приписка<input name="note" maxlength="120"
          value="<?= h($l['note'] ?? '') ?>" placeholder="новости и анонсы"></label>
        <label>Порядок<input name="sort" type="number"
          value="<?= (int)($l['sort'] ?? 0) ?>"></label>
        <div class="go">
          <label class="check" style="text-transform:none;letter-spacing:0;font-size:13px">
            <input type="checkbox" name="visible" value="1"
              <?= (!$l || $l['visible']) ? 'checked' : '' ?>> видно</label>
          <button class="btn small" type="submit"><?= $l ? 'Сохранить' : 'Добавить' ?></button>
        </div>
      </form>
      <?php if ($l): ?>
        <form method="post" class="linkrow" style="padding-top:0"
              data-ask="Удалить ссылку «<?= h($l['title']) ?>»?">
          <?= csrfField() ?>
          <input type="hidden" name="id" value="<?= (int)$l['id'] ?>">
          <div class="go" style="grid-column:1/-1">
            <button class="btn small ghost" name="do" value="link_del">удалить</button>
            <span class="muted small">так это выглядит в подвале:
              <?= linkIcon((string)$l['kind']) ?> <?= h($l['title']) ?></span>
          </div>
        </form>
      <?php endif;
    };
?>
  <h2 class="sec">Ссылки на сообщества</h2>
  <p class="muted">Показываются в подвале КАЖДОЙ страницы. Меньше порядок —
  выше в списке. Снятая галочка прячет ссылку, не стирая её: канал закрыли на
  неделю — спрятали, потом вернули, не набирая адрес заново.</p>

  <?php if ($links): ?>
    <div class="linklist"><?php foreach ($links as $l) { $row($l); } ?></div>
  <?php else: ?>
    <p class="muted">Ссылок пока нет — подвал сайта пустой.</p>
  <?php endif; ?>

  <h3 class="sec">Добавить</h3>
  <div class="linklist"><?php $row(null); ?></div>

<?php /* ====================================================== НАСТРОЙКИ == */
elseif ($tab === 'set'): ?>
  <h2 class="sec">Настройки сайта</h2>
  <form method="post" class="form">
    <?= csrfField() ?>
    <input type="hidden" name="do" value="set_save">

    <label>Объявление на всех страницах
      <input name="notice" maxlength="300" value="<?= h(setting($pdo, 'notice')) ?>"
             placeholder="Пусто — объявления нет">
      <small>Одна строка вверху каждой страницы: «сервер на профилактике»,
      «сегодня в 20:00 вылазка». Очистите поле — строка пропадёт</small></label>

    <label>Описание для поиска
      <textarea name="meta_desc" rows="3" maxlength="400"><?= h(setting($pdo, 'meta_desc')) ?></textarea>
      <small>Тот текст, что Яндекс и Google показывают под ссылкой на сайт.
      Уложитесь в 150–200 знаков: длиннее они обрезают. Пусто — возьмём
      описание по умолчанию</small></label>

    <label>Адрес сервера для игроков
      <input name="mc_show" maxlength="80" value="<?= h(setting($pdo, 'mc_show')) ?>"
             placeholder="<?= h(mcShow($CFG)) ?>">
      <small>Что написано в подвале и на главной. ПРОВЕРЬТЕ, ЧТО ЭТОТ АДРЕС
      РАБОТАЕТ: здесь месяц стоял несуществующий, и люди вписывали его в
      клиент. Пусто — покажем настоящий адрес из настроек подключения</small></label>

    <button class="btn" type="submit">Сохранить</button>
  </form>

  <h3 class="sec">Что менять здесь нельзя</h3>
  <p class="muted">Пароль базы, ключи оплаты и ключ моста лежат в файле выше
  корня сайта и через страницу не правятся — намеренно. Страница управления
  доступна из интернета, а такие вещи не должны быть доступны из интернета
  вообще.</p>
<?php endif; ?>
<?php /*  ПОДТВЕРЖДЕНИЕ УДАЛЕНИЯ — ОДНИМ СЛУШАТЕЛЕМ, А НЕ onsubmit В РАЗМЕТКЕ.
          Политика безопасности (boot.php) запрещает код прямо в атрибутах:
          на них не распространяется одноразовая метка, и браузер их просто
          не выполняет. Вопрос берётся из data-ask, так что добавить его к
          новой форме — это по-прежнему один атрибут. */ ?>
<script nonce="<?= h(cspNonce()) ?>">
document.addEventListener('submit', function (e) {
  var q = e.target.getAttribute && e.target.getAttribute('data-ask');
  if (q && !confirm(q)) { e.preventDefault(); }
});
</script>
<?php pageFoot();
