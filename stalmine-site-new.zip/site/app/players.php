<?php
/* Напрямую из браузера не открывается: настоящий адрес страницы — /players/.
 * Файл лежит в app/ и подключается из players/index.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}
?>
<?php
/* ============================================================================
 *  players.php — поиск игроков и открытый профиль.
 *
 *  ДВЕ СТРАНИЦЫ В ОДНОМ ФАЙЛЕ. Без «?n=» это поиск, с «?n=Ник» — профиль.
 *  Разделять незачем: обе живут на одних и тех же двух таблицах, и вторая
 *  копия шапки с поиском разошлась бы с первой на первой же правке.
 *
 *  ПРОФИЛЬ ОТКРЫТ ВСЕМ, И ЭТО РЕШЕНИЕ, А НЕ НЕДОСМОТР. Рейтинг и так
 *  показывает репутацию и наряды каждого; прятать за входом то, что уже
 *  висит на соседней странице, — самообман. Но донат в профиль не попадает
 *  вовсе (см. STAT_GROUPS в inc/site.php): сколько человек потратил, его
 *  личное дело.
 *
 *  ЧЕГО НЕТ В БАЗЕ, ТОГО НЕ БУДЕТ И НА СТРАНИЦЕ. Данные кладёт игровой
 *  сервер (9-stats-push.sk). Пока игрок не заходил после установки моста,
 *  его карточки просто нет — и об этом сказано прямо, а не пустой таблицей.
 * ========================================================================= */

require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/layout.php';

$nick = trim((string)($_GET['n'] ?? ''));
$q    = trim((string)($_GET['q'] ?? ''));

/* ---------------------------------------------------------------------------
 *  ПРОФИЛЬ
 * ------------------------------------------------------------------------ */
if ($nick !== '') {
    $st = $pdo->prepare('SELECT * FROM players WHERE mc_nick = ? LIMIT 1');
    $st->execute([$nick]);
    $p = $st->fetch();

    if (!$p) {
        http_response_code(404);
        pageHead('Игрок не найден', 'players');
        ?>
        <h1 class="sec">Такого игрока нет</h1>
        <p class="lead">Ник <b class="who"><?= h($nick) ?></b> на сервере не
        встречался — либо он написан иначе, либо этот человек ещё не заходил
        после того, как заработала передача показателей.</p>
        <p><a class="btn" href="/players/">Искать по нику</a></p>
        <?php pageFoot();
        return;
    }

    /*  Счётчики достаём одним запросом и раскладываем по разделам уже здесь:
     *  двадцать два отдельных запроса ради двадцати двух чисел — это
     *  двадцать два обращения к базе на каждый просмотр профиля. */
    $st = $pdo->prepare('SELECT k, v FROM player_stats WHERE mc_nick = ?');
    $st->execute([$nick]);
    $stats = $st->fetchAll(PDO::FETCH_KEY_PAIR);

    /*  Место в рейтинге считает база: тянуть весь список в память ради
     *  одного номера — работа впустую. */
    $st = $pdo->prepare(
        'SELECT COUNT(*) + 1 FROM players WHERE reputation > ?'
    );
    $st->execute([(int)$p['reputation']]);
    $place = (int)$st->fetchColumn();

    pageHead($p['mc_nick'], 'players');
    ?>
    <h1 class="sec"><?= h($p['mc_nick']) ?></h1>
    <p class="muted small">
      Показатели обновляются, пока человек в игре, и окончательно — при
      выходе. Последнее обновление:
      <b class="mono"><?= h(date('d.m.Y H:i', strtotime((string)$p['updated_at']))) ?></b>
    </p>

    <div class="tiles">
      <div><span>Сторона</span><b><?= h($p['faction'] ?: 'Одиночка') ?></b></div>
      <div><span>Ранг</span><b><?= h($p['rank_name'] ?: '—') ?></b></div>
      <div><span>Репутация</span><b><?= (int)$p['reputation'] ?></b>
        <small><?= $place ?>-е место в рейтинге</small></div>
      <div><span>В Зоне</span><b><?= h(playtimeText((int)$p['playtime_m'])) ?></b></div>
      <div><span>Нарядов</span><b><?= (int)$p['contracts'] ?></b></div>
      <div><span>Отголосков</span><b><?= (int)$p['artifacts'] ?></b></div>
    </div>

    <?php if ($p['patch_worn']): ?>
      <p>Носит нашивку: <b><?= h($p['patch_worn']) ?></b></p>
    <?php endif; ?>

    <?php
    /*  Раздел показываем, только если в нём есть хоть одно ненулевое число.
     *  Иначе новый игрок получал бы шесть таблиц из одних нулей — это
     *  выглядит как поломка, а не как «ещё ничего не сделал». */
    $shown = false;
    foreach (STAT_GROUPS as $group => $keys):
        $have = array_filter($keys, fn($k) => (int)($stats[$k] ?? 0) > 0, ARRAY_FILTER_USE_KEY);
        if (!$have) { continue; }
        $shown = true; ?>
      <h2 class="sec"><?= h($group) ?></h2>
      <div class="tw">
      <table>
        <tbody>
        <?php foreach ($have as $k => $label): ?>
          <tr><td><?= h($label) ?></td>
              <td class="num"><?= number_format((int)$stats[$k], 0, '', ' ') ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
    <?php endforeach; ?>

    <?php if (!$shown): ?>
      <p class="muted">Счётчиков пока нет: человек либо только зарегистрировался,
      либо ещё не выходил в Зону.</p>
    <?php endif; ?>

    <p><a href="/players/">← ко всем игрокам</a> · <a href="/top/">рейтинг</a></p>
    <?php pageFoot();
    return;
}

/* ---------------------------------------------------------------------------
 *  ПОИСК И СПИСОК
 * ------------------------------------------------------------------------ */
if ($q !== '') {
    /*  LIKE со звёздочкой с обеих сторон — то, чего человек ждёт от поиска:
     *  «раз» должно находить «Razban». Экранируем «%» и «_», иначе они
     *  сработают как подстановочные знаки и поиск по «_» вернёт всех. */
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
    $st = $pdo->prepare(
        'SELECT mc_nick, faction, rank_name, reputation, contracts, playtime_m, updated_at
           FROM players WHERE mc_nick LIKE ?
          ORDER BY reputation DESC LIMIT 100'
    );
    $st->execute([$like]);
    $rows = $st->fetchAll();
} else {
    $rows = $pdo->query(
        'SELECT mc_nick, faction, rank_name, reputation, contracts, playtime_m, updated_at
           FROM players ORDER BY updated_at DESC LIMIT 100'
    )->fetchAll();
}

pageHead('Игроки', 'players');
?>
<h1 class="sec">Игроки</h1>
<p class="lead">Все, кто заходил в Зону. Показатели приходят из игры сами —
пока человек играет, они обновляются, а при выходе записываются окончательно.</p>

<form method="get" class="form narrow">
  <label>Найти по нику
    <input name="q" value="<?= h($q) ?>" maxlength="32" placeholder="часть ника">
  </label>
  <button class="btn" type="submit">Искать</button>
</form>

<?php if (!$rows): ?>
  <p class="muted"><?= $q !== ''
     ? 'По такому нику никого. Проверьте написание — ник в Minecraft различает большие и маленькие буквы.'
     : 'Пока пусто: игра ещё не присылала показатели. Они появятся, как только кто-нибудь зайдёт на сервер.' ?></p>
<?php else: ?>
  <p class="muted small"><?= $q !== '' ? 'Найдено: ' . count($rows) : 'Последние по времени в игре' ?></p>
  <div class="tw">
  <table>
    <thead><tr><th>Ник</th><th>Сторона</th><th>Ранг</th><th>Репутация</th>
      <th>Нарядов</th><th>В Зоне</th><th>Был</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td class="who"><a href="/players/?n=<?= h(rawurlencode((string)$r['mc_nick'])) ?>"><?= h($r['mc_nick']) ?></a></td>
        <td><?= h($r['faction'] ?: 'Одиночка') ?></td>
        <td><?= h($r['rank_name'] ?: '—') ?></td>
        <td class="num"><?= (int)$r['reputation'] ?></td>
        <td class="num"><?= (int)$r['contracts'] ?></td>
        <td class="num"><?= h(playtimeText((int)$r['playtime_m'])) ?></td>
        <td class="num"><?= h(date('d.m.Y', strtotime((string)$r['updated_at']))) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
<?php endif; pageFoot();
