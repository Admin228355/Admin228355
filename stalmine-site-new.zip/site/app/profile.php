<?php
/* Напрямую из браузера не открывается: настоящий адрес страницы — /profile/.
 * Файл лежит в app/ и подключается из profile/index.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}
?>
<?php
require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/auth.php';
require_once __DIR__ . '/../inc/layout.php';

$u = needUser();
$code = null; $err = [];

/*  ТЕЛЕГРАМ. Привязка идёт ССЫЛКОЙ, а не набором кода: человек нажимает
 *  кнопку, Telegram открывается и сам отправляет боту «/start КОД».
 *  Набирать восемь знаков с телефона — это половина отвалившихся на полпути.
 *
 *  Код одноразовый и короткоживущий: ссылка оседает в истории браузера и в
 *  списке чатов, и вечный код в ней — это вечная возможность привязать
 *  чужой аккаунт. */
$tg = null; $tgLink = null;
try {
    $st = $pdo->prepare('SELECT tg_id, tg_name FROM tg_users WHERE user_id = ? LIMIT 1');
    $st->execute([(int)$u['id']]);
    $tg = $st->fetch() ?: null;

    if ($tg === null && !empty($CFG['tg_bot'])) {
        /*  Старые коды этого человека гасим: иначе по каждой открытой
         *  вкладке остаётся рабочая ссылка. */
        $pdo->prepare('DELETE FROM tg_codes WHERE user_id = ? OR expires_at < NOW()')
            ->execute([(int)$u['id']]);
        $tgCode = bin2hex(random_bytes(8));
        $pdo->prepare(
            'INSERT INTO tg_codes (code, user_id, expires_at)
             VALUES (?, ?, NOW() + INTERVAL 30 MINUTE)'
        )->execute([$tgCode, (int)$u['id']]);
        $tgLink = 'https://t.me/' . $CFG['tg_bot'] . '?start=' . $tgCode;
    }
} catch (PDOException $e) {
    error_log('profile tg: ' . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfOk()) {
        $err[] = 'Форма устарела. Попробуйте ещё раз.';
    } else {
        $nick = trim(post('nick'));
        if (!validNick($nick)) {
            $err[] = 'Ник: латиница, цифры и подчёркивание, от 3 до 16 знаков.';
        } else {
            $st = $pdo->prepare('SELECT 1 FROM users WHERE mc_nick = ? AND id <> ? LIMIT 1');
            $st->execute([$nick, $u['id']]);
            if ($st->fetch()) {
                $err[] = 'Этот ник уже привязан к другому аккаунту.';
            } else {
                $code = makeLinkCode($pdo, (int)$u['id'], $nick);
            }
        }
    }
}

/* Заявка, поданная раньше и ещё не рассмотренная. Без неё человек, закрыв
   страницу, терял код и подавал заявку снова — а каждая новая стирает
   предыдущую (makeLinkCode). Со стороны это выглядело как «код не
   работает». */
$pending = null;
if ($code === null) {
    $st = $pdo->prepare(
        'SELECT code, mc_nick, expires_at FROM link_codes
          WHERE user_id = ? AND used_at IS NULL AND expires_at > NOW() LIMIT 1'
    );
    $st->execute([(int)$u['id']]);
    $pending = $st->fetch() ?: null;
}

/* Игровые показатели. Их может не быть — и это НЕ ошибка: пока мост из
   игры в базу не поставлен, писать сюда некому. Показываем честно. */
$gp = null;
if (!empty($u['mc_nick'])) {
    $st = $pdo->prepare('SELECT * FROM players WHERE mc_nick = ? LIMIT 1');
    $st->execute([$u['mc_nick']]);
    $gp = $st->fetch() ?: null;
}

pageHead('Кабинет', 'profile');
?>
<h1 class="sec">Кабинет</h1>

<div class="two">
  <section class="panel">
    <div class="panel-h">Аккаунт</div>
    <div class="readout">
      <div><span>Логин</span><b><?= h($u['login']) ?></b></div>
      <div><span>Ник в игре</span><b><?= $u['mc_nick'] ? h($u['mc_nick']) : '<i class="muted">не привязан</i>' ?></b></div>
      <div><span>Зарегистрирован</span><b class="num"><?= h(date('d.m.Y', strtotime($u['created_at']))) ?></b></div>
    </div>
  </section>

  <section class="panel">
    <div class="panel-h">Показатели в Зоне</div>
    <?php if (!$u['mc_nick']): ?>
      <p class="muted pad">Привяжите ник, чтобы здесь появились ваши показатели.</p>
    <?php elseif (!$gp): ?>
      <p class="muted pad">Данных пока нет. Игра ещё не передаёт их на сайт —
      см. примечание внизу страницы.</p>
    <?php else: ?>
      <div class="readout">
        <div><span>Сторона</span><b><?= h($gp['faction'] ?: 'Одиночка') ?></b></div>
        <div><span>Ранг</span><b><?= h($gp['rank_name'] ?: '—') ?></b></div>
        <div><span>Репутация</span><b class="num"><?= (int)$gp['reputation'] ?></b></div>
        <div><span>Нашивка</span><b><?= h($gp['patch_worn'] ?: '—') ?></b></div>
        <div><span>Нарядов сдано</span><b class="num"><?= (int)$gp['contracts'] ?></b></div>
        <div><span>Отголосков</span><b class="num"><?= (int)$gp['artifacts'] ?></b></div>
      </div>
    <?php endif; ?>
  </section>
</div>

<section>
  <h2 class="sec">Телеграм</h2>
  <?php if ($tg !== null): ?>
    <p class="up">Привязан<?= $tg['tg_name'] ? ' — ' . h((string)$tg['tg_name']) : '' ?>.
    Настроить уведомления можно в самом боте командой <b class="mono">/notify</b>,
    там же <b class="mono">/stats</b> покажет вашу статистику.</p>
    <p class="muted small">Отвязать — командой <b class="mono">/unlink</b> в боте.</p>
  <?php elseif ($tgLink !== null): ?>
    <p>Бот присылает то, что легко пропустить: заброску, всплеск, новости и
    сообщение о том, что талоны за пополнение дошли до игры. Что именно
    присылать — вы выбираете сами, любое можно выключить.</p>
    <div class="row">
      <a class="btn" href="<?= h($tgLink) ?>" target="_blank" rel="noopener">Привязать телеграм</a>
    </div>
    <p class="muted small">Ссылка живёт полчаса и срабатывает один раз.
    Откроется бот — нажмите в нём «Запустить».</p>
  <?php else: ?>
    <p class="muted">Бот пока не настроен.</p>
  <?php endif; ?>

  <h2 class="sec">Привязка ника</h2>
  <?php foreach ($err as $e): ?><div class="flash flash-err"><?= h($e) ?></div><?php endforeach; ?>
  <?php $show = $code !== null ? ['code' => $code, 'nick' => post('nick'), 'till' => null] : null;
        if ($show === null && $pending !== null) {
            $show = ['code' => $pending['code'], 'nick' => $pending['mc_nick'],
                     'till' => $pending['expires_at']];
        } ?>
  <?php if ($show !== null): ?>
    <div class="codebox">
      <p>Код на привязку ника <b><?= h($show['nick']) ?></b>:</p>
      <div class="code" id="lcode" data-cmd="/привязка <?= h($show['code']) ?>"><?= h($show['code']) ?></div>
      <!--  КНОПКА «СКОПИРОВАТЬ». Код из восьми знаков без похожих букв, но
            выделять его мышью на телефоне неудобно, а ошибиться в одном
            знаке — значит получить «код не найден» и не понять почему.
            Запасной путь на случай, если браузер не даёт доступ к буферу
            (так бывает на http и в старых версиях): выделяем текст, и
            человек копирует привычным способом.  -->
      <p><button class="btn small" type="button" id="lcopy">Скопировать команду</button>
         <span class="muted small" id="lcopied" hidden>скопировано</span></p>
      <script nonce="<?= h(cspNonce()) ?>">
      (function () {
        var b = document.getElementById('lcopy'),
            c = document.getElementById('lcode'),
            k = document.getElementById('lcopied');
        if (!b || !c) { return; }
        b.addEventListener('click', function () {
          //  Копируем ЦЕЛУЮ команду, а не голый код: игроку всё равно
          //  придётся дописывать «/привязка» руками, и ошибиться в ней
          //  так же легко, как в самом коде. Строку берём из data-атрибута,
          //  чтобы имя команды правилось в PHP, а не в двух местах.
          var t = (c.getAttribute('data-cmd') || c.textContent).trim();
          function done() { k.hidden = false; setTimeout(function(){ k.hidden = true; }, 2000); }
          if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(t).then(done, select);
          } else { select(); }
          function select() {
            var r = document.createRange(); r.selectNodeContents(c);
            var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(r);
            try { document.execCommand('copy'); done(); } catch (e) {}
          }
        });
      })();
      </script>
      <p class="muted">Назовите этот код администратору — в игре или там, где
        вы с ним общаетесь. Он сверит, что ник ваш, и привяжет.
        <?php if ($show['till']): ?>Годен до
        <b class="mono"><?= h(date('H:i', strtotime((string)$show['till']))) ?></b>,
        <?php else: ?>Годен полчаса, <?php endif; ?>и только один раз.</p>
    </div>
    <form method="post" class="form narrow">
      <?= csrfField() ?>
      <input type="hidden" name="nick" value="<?= h($show['nick']) ?>">
      <p class="muted small">Ошиблись ником? <button class="btn small ghost" type="submit"
        name="again" value="1">Выпустить новый код</button></p>
    </form>
  <?php else: ?>
    <form method="post" class="form narrow">
      <?= csrfField() ?>
      <label>Ник в игре<input name="nick" required maxlength="16" pattern="[A-Za-z0-9_]{3,16}"
        value="<?= h($u['mc_nick'] ?? '') ?>"><small>Тот, которым заходите на
        сервер: латиница, цифры и подчёркивание</small></label>
      <button class="btn" type="submit">Получить код</button>
    </form>
  <?php endif; ?>
  <p class="muted small">Пока показатели в Зоне на сайт не приезжают: игра
  хранит их у себя, и мост в базу сайта ещё не поставлен. Привязка при этом
  работает — она нужна как раз для того, чтобы было к чему их привязать,
  когда мост появится.</p>
</section>
<?php pageFoot();
