<?php
/* Напрямую из браузера не открывается: настоящий адрес страницы — /bugs/.
 * Файл лежит в app/ и подключается из bugs/index.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}
?>
<?php
/* ============================================================================
 *  bugs.php — сообщить об ошибке и посмотреть, что стало с прежними.
 *
 *  ПОЧЕМУ НЕ ПРОСТО «ОПИШИТЕ ПРОБЛЕМУ» ОДНИМ ПОЛЕМ. Из строки «сломался
 *  рюкзак» починить нельзя ничего: неизвестно, где это было, что человек
 *  делал и чего ждал. Три поля вместо одного — единственное, что отличает
 *  сообщение, по которому можно работать, от сообщения, на которое можно
 *  только ответить «не воспроизводится».
 *
 *  ВОЗНАГРАЖДЕНИЕ НАЗНАЧАЕТ ЧЕЛОВЕК, А НЕ КОД. Автоматическая выплата за
 *  «сообщение принято» превращается в способ печатать деньги: достаточно
 *  писать по десять штук в день. Здесь заявка только регистрируется.
 * ========================================================================= */

require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/layout.php';

$u = needUser();
$err = [];

/* Сколько заявок в сутки от одного человека. Не защита от злого умысла, а
 * защита от привычки писать по строчке на каждую мысль. */
const BUGS_PER_DAY = 5;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfOk()) {
        $err[] = 'Форма устарела. Обновите страницу.';
    } else {
        $title    = trim(post('title'));
        $where    = trim(post('where_at'));
        $steps    = trim(post('steps'));
        $expected = trim(post('expected'));

        if (mb_strlen($title) < 6)  { $err[] = 'Коротко назовите, что сломалось — хотя бы несколько слов.'; }
        if (mb_strlen($title) > 160){ $err[] = 'Название длиннее 160 знаков.'; }
        if (mb_strlen($steps) < 20) { $err[] = 'Опишите, что вы делали, подробнее. По одной строке починить нечего.'; }
        if (mb_strlen($steps) > 4000) { $err[] = 'Описание длиннее 4000 знаков.'; }

        $st = $pdo->prepare(
            'SELECT COUNT(*) FROM bug_reports
              WHERE user_id = ? AND created_at > (NOW() - INTERVAL 1 DAY)'
        );
        $st->execute([(int)$u['id']]);
        if ((int)$st->fetchColumn() >= BUGS_PER_DAY) {
            $err[] = 'На сегодня хватит: не больше ' . BUGS_PER_DAY
                   . ' сообщений в сутки. Допишите остальное завтра.';
        }

        if (!$err) {
            $pdo->prepare(
                'INSERT INTO bug_reports (user_id, mc_nick, title, where_at, steps, expected, ip)
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            )->execute([(int)$u['id'], ($u['mc_nick'] ?: null), $title,
                        ($where ?: null), $steps, ($expected ?: null), ipBin()]);
            flash('Записал. Ответ появится здесь же, на этой странице.');
            header('Location: /bugs/'); exit;
        }
    }
}

$mine = $pdo->prepare(
    'SELECT * FROM bug_reports WHERE user_id = ? ORDER BY created_at DESC LIMIT 50'
);
$mine->execute([(int)$u['id']]);
$mine = $mine->fetchAll();

pageHead('Сообщить об ошибке', 'bugs');
?>
<h1 class="sec">Сообщить об ошибке</h1>
<p class="lead">Если что-то работает не так, как написано в памятке, — это
ошибка, и её надо чинить. За находку, по которой удалось починить, платят.</p>

<div class="panel" style="margin:18px 0">
  <div class="panel-h">Как платят</div>
  <div class="pad">
    <p>Деньги начисляются в игре, после того как ошибку удалось повторить и
    исправить. Размер зависит от того, насколько тяжёлая находка: за мелочь
    вроде опечатки — символически, за дюп или способ потерять вещи —
    заметно.</p>
    <p class="muted small">Не платят за: «у меня лагает», предложения и идеи,
    повторы уже присланного и сообщения, по которым ничего не удалось
    повторить. Выдумывать ошибки ради выплаты — обман из правил.</p>
  </div>
</div>

<?php foreach ($err as $e): ?><div class="flash flash-err"><?= h($e) ?></div><?php endforeach; ?>

<form method="post" class="form">
  <?= csrfField() ?>
  <label>Что сломалось<input name="title" required maxlength="160"
    value="<?= h(post('title')) ?>"><small>Одной строкой, как заголовок</small></label>
  <label>Где это было<input name="where_at" maxlength="160"
    value="<?= h(post('where_at')) ?>"><small>Место, НПС, меню, координаты —
    что знаете</small></label>
  <label>Что вы делали
    <textarea name="steps" rows="7" required><?= h(post('steps')) ?></textarea>
    <small>По шагам: сначала это, потом это, потом сломалось. Это самое
    важное поле — без него повторить ошибку не получится</small></label>
  <label>Что должно было произойти
    <textarea name="expected" rows="3"><?= h(post('expected')) ?></textarea>
    <small>Чего вы ждали вместо того, что вышло</small></label>
  <button class="btn" type="submit">Отправить</button>
</form>

<h2 class="sec">Ваши сообщения</h2>
<?php if (!$mine): ?>
  <p class="muted">Пока ни одного.</p>
<?php else: ?>
<div class="tw">
<table>
  <thead><tr><th>Дата</th><th>Что сломалось</th><th>Состояние</th><th>Начислено</th><th>Ответ</th></tr></thead>
  <tbody>
  <?php foreach ($mine as $b): [$label, $cls] = bugState((string)$b['status']); ?>
    <tr>
      <td class="num"><?= h(date('d.m.Y', strtotime((string)$b['created_at']))) ?></td>
      <td><?= h($b['title']) ?></td>
      <td><b class="<?= h($cls) ?>"><?= h($label) ?></b></td>
      <td class="num"><?= $b['reward'] > 0 ? (int)$b['reward'] . ' ₽' : '—' ?>
          <?= ($b['reward'] > 0 && !$b['paid_at']) ? '<span class="muted small">(не выдано)</span>' : '' ?></td>
      <td class="small"><?= h($b['admin_note'] ?: '') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; pageFoot();
