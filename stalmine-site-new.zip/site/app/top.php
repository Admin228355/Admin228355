<?php
/* Напрямую из браузера не открывается: настоящий адрес страницы — /top/.
 * Файл лежит в app/ и подключается из top/index.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}
?>
<?php
require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/layout.php';

$rows = $pdo->query(
    'SELECT mc_nick, faction, rank_name, reputation, contracts, patch_worn
       FROM players ORDER BY reputation DESC, contracts DESC LIMIT 50'
)->fetchAll();

pageHead('Рейтинг', 'top');
?>
<h1 class="sec">Рейтинг</h1>
<?php if (!$rows): ?>
  <p class="muted">Таблица пуста: игра ещё не присылала показатели. Они
  появятся сами, как только кто-нибудь зайдёт на сервер.</p>
<?php else: ?>
<div class="tw">
<table>
  <thead><tr><th>#</th><th>Ник</th><th>Сторона</th><th>Ранг</th>
    <th>Репутация</th><th>Нарядов</th><th>Нашивка</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $i => $r): ?>
    <tr>
      <td class="num"><?= $i + 1 ?></td>
      <td class="who"><a href="/players/?n=<?= h(rawurlencode((string)$r['mc_nick'])) ?>"><?= h($r['mc_nick']) ?></a></td>
      <td><?= h($r['faction'] ?: 'Одиночка') ?></td>
      <td><?= h($r['rank_name'] ?: '—') ?></td>
      <td class="num"><?= (int)$r['reputation'] ?></td>
      <td class="num"><?= (int)$r['contracts'] ?></td>
      <td><?= h($r['patch_worn'] ?: '—') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
<?php endif; pageFoot();
