<?php
/* Напрямую из браузера не открывается: настоящий адрес страницы — /chat/.
 * Файл лежит в app/ и подключается из chat/index.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}
?>
<?php
/* ============================================================================
 *  chat.php — написать в игровой чат прямо с сайта.
 *
 *  ЗАЧЕМ ЭТО ИГРОКУ. Человек сидит на работе или в школе, зайти в игру не
 *  может, а спросить что-то у тех, кто в Зоне, — хочет. Раньше для этого
 *  нужен был телеграм и чтобы там кто-то оказался; теперь достаточно сайта.
 *
 *  ПИШУТ ТОЛЬКО СО СВОИМ ИГРОВЫМ НИКОМ. В игре сообщение появляется под
 *  пометкой [САЙТ] и настоящим ником — иначе с сайта можно было бы говорить
 *  от чужого имени, и чат превратился бы в помойку за вечер.
 *
 *  ЗАДЕРЖКА МЕЖДУ СООБЩЕНИЯМИ ОБЯЗАТЕЛЬНА. Форма на сайте отправляется
 *  быстрее, чем человек печатает в игре: без задержки один скучающий
 *  посетитель зальёт игровой чат за минуту, и выключать пришлось бы всё.
 *
 *  Дальше сообщение живёт так же, как написанное из управления: ложится в
 *  очередь, игровой сервер забирает её мостом раз в пять секунд.
 * ========================================================================= */

require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/layout.php';
require_once __DIR__ . '/../inc/talk.php';

/*  Пауза между сообщениями и предел длины. Здесь, а не в разных местах:
 *  правило одно, и меняться оно должно в одном месте. */
const CHAT_GAP = 20;
const CHAT_MAX = 200;

[$u, $why] = talkWho();
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfOk()) {
        $err = 'Форма устарела. Обновите страницу.';
    } elseif ($u === null) {
        $err = $why;
    } else {
        $body = talkClean(post('body'), CHAT_MAX, true);
        $wait = talkWait($pdo, 'site_msgs', (int)$u['id'], CHAT_GAP);
        if ($body === '') {
            $err = 'Пустое сообщение.';
        } elseif ($wait > 0) {
            $err = 'Слишком часто. Следующее сообщение можно через ' . $wait . ' с.';
        } else {
            $pdo->prepare('INSERT INTO site_msgs (user_id, author, body) VALUES (?,?,?)')
                ->execute([(int)$u['id'], (string)$u['mc_nick'], $body]);
            flash('Отправлено. В игре появится в течение нескольких секунд.');
            header('Location: /chat/'); exit;
        }
    }
}

/*  ОБА НАПРАВЛЕНИЯ В ОДНОЙ ЛЕНТЕ.
 *
 *  Написанное с сайта и сказанное в игре — это ОДИН разговор, и разносить
 *  его по двум спискам значит заставить человека читать диалог в двух
 *  колонках. Складываем запросом UNION и сортируем по времени.
 *
 *  Из игры приходит только общий канал: переговоры группировки и разговор
 *  рядом сюда не попадают намеренно.
 *
 *  ЗАПРОС ВЫНЕСЕН В ФУНКЦИЮ, потому что его зовут ДВА раза: при обычной
 *  загрузке страницы и при опросе с неё же. Две копии одного запроса
 *  разъехались бы на первой правке, и лента показывала бы разное. */
function chatFeed(PDO $pdo, int $limit = 100): array {
    $st = $pdo->prepare(
        "SELECT id, author, faction, body, created_at, src, sent_at FROM (
             SELECT id, author, faction, body, created_at, 'game' AS src,
                    NULL AS sent_at
               FROM game_msgs
             UNION ALL
             SELECT id, author, NULL, body, created_at, 'site', sent_at
               FROM site_msgs
         ) x ORDER BY created_at DESC, id DESC LIMIT ?"
    );
    $st->bindValue(1, $limit, PDO::PARAM_INT);
    $st->execute();
    /*  Наверху страницы должно быть старое, внизу свежее — как в любом
     *  чате. Из базы удобнее брать «последние сто», то есть в обратном
     *  порядке, поэтому переворачиваем здесь. */
    return array_reverse($st->fetchAll());
}

/*  ОПРОС С САМОЙ СТРАНИЦЫ. Отвечаем коротким JSON вместо целой страницы:
 *  перезагружать ради трёх новых строк сорок килобайт разметки —
 *  расточительство, особенно с телефона. */
if (isset($_GET['json'])) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    $out = [];
    foreach (chatFeed($pdo, 100) as $r) {
        $out[] = [
            'k'    => $r['src'] . $r['id'],
            'src'  => $r['src'],
            'who'  => $r['author'],
            'fac'  => $r['faction'],
            'text' => $r['body'],
            'time' => date('H:i', strtotime((string)($r['sent_at'] ?: $r['created_at']))),
            'wait' => ($r['src'] === 'site' && !$r['sent_at']),
        ];
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit;
}

$rows = chatFeed($pdo, 100);

pageHead('Чат с Зоной', 'chat');
?>
<h1 class="sec">Чат с Зоной</h1>
<p class="lead">Написанное здесь появляется в игровом чате под пометкой
<b class="mono">[САЙТ]</b> и вашим ником. Те, кто сейчас в Зоне, увидят это
через несколько секунд. Сказанное в общем чате на базе видно здесь же — разговор идёт в обе стороны.</p>

<?php if ($err !== ''): ?><div class="flash flash-err"><?= h($err) ?></div><?php endif; ?>

<?php if ($u === null): ?>
  <div class="flash"><?= h($why) ?>
    <?php if (!user()): ?>
      <a href="/login/">Войти</a> · <a href="/register/">зарегистрироваться</a>
    <?php else: ?>
      <a href="/profile/">В кабинет</a>
    <?php endif; ?>
  </div>
<?php else: ?>
  <form method="post" class="form">
    <?= csrfField() ?>
    <label>Сообщение от <b class="who"><?= h($u['mc_nick']) ?></b>
      <input name="body" maxlength="<?= CHAT_MAX ?>" required autocomplete="off"
             placeholder="Кто на базе? Нужен фильтр">
      <small>До <?= CHAT_MAX ?> знаков, не чаще раза в <?= CHAT_GAP ?> секунд</small></label>
    <button class="btn" type="submit">Отправить в игру</button>
  </form>
<?php endif; ?>

<h2 class="sec">Разговор</h2>
<?php /*  ОКНО, А НЕ ТАБЛИЦА. Чат читают снизу вверх и глазами по краю строки:
          лента с прокруткой внутри и прижатием к низу ведёт себя привычно, а
          длинный список на всю страницу — нет. */ ?>
<div class="chatbox" id="chatbox" data-empty="Пока никто не писал.">
  <?php foreach ($rows as $r): ?>
    <div class="cm<?= $r['src'] === 'site' ? ' from-site' : '' ?>"
         data-k="<?= h($r['src'] . $r['id']) ?>">
      <span class="cm-time"><?= h(date('H:i', strtotime((string)($r['sent_at'] ?: $r['created_at'])))) ?></span>
      <?php if ($r['src'] === 'site'): ?><i class="tag">САЙТ</i><?php endif; ?>
      <a class="cm-who" href="/players/?n=<?= h(rawurlencode((string)$r['author'])) ?>"><?= h($r['author']) ?></a>
      <?php if (!empty($r['faction'])): ?><i class="fac"><?= h($r['faction']) ?></i><?php endif; ?>
      <span class="cm-text"><?= h($r['body']) ?></span>
      <?php if ($r['src'] === 'site' && !$r['sent_at']): ?><em class="cm-wait">уходит…</em><?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<?php /*  ЖИВОЕ ОБНОВЛЕНИЕ. Спрашиваем короткий JSON раз в несколько секунд и
          дорисовываем только новое. Перезагружать страницу ради трёх строк —
          это сорок килобайт разметки на каждый чужой «привет».

          Опрос ЗАМИРАЕТ, когда вкладка не видна: держать соединение к сайту
          из десяти забытых вкладок незачем ни телефону, ни хостингу. */ ?>
<script nonce="<?= h(cspNonce()) ?>">
(function () {
  var box = document.getElementById('chatbox');
  if (!box) { return; }
  var seen = {}, atBottom = true;
  Array.prototype.forEach.call(box.children, function (el) {
    seen[el.getAttribute('data-k')] = 1;
  });

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function toBottom() { box.scrollTop = box.scrollHeight; }
  box.addEventListener('scroll', function () {
    /*  Если человек отмотал вверх и читает старое — не дёргаем его вниз при
        каждом новом сообщении. Возвращаемся сами, только когда он и так внизу. */
    atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
  });

  function draw(list) {
    var added = 0;
    list.forEach(function (m) {
      if (seen[m.k]) { return; }
      seen[m.k] = 1;
      var d = document.createElement('div');
      d.className = 'cm' + (m.src === 'site' ? ' from-site' : '') + ' cm-new';
      d.setAttribute('data-k', m.k);
      d.innerHTML =
        '<span class="cm-time">' + esc(m.time) + '</span>' +
        (m.src === 'site' ? '<i class="tag">САЙТ</i>' : '') +
        '<a class="cm-who" href="/players/?n=' + encodeURIComponent(m.who) + '">' + esc(m.who) + '</a>' +
        (m.fac ? '<i class="fac">' + esc(m.fac) + '</i>' : '') +
        '<span class="cm-text">' + esc(m.text) + '</span>' +
        (m.wait ? '<em class="cm-wait">уходит…</em>' : '');
      box.appendChild(d);
      added++;
    });
    if (added && atBottom) { toBottom(); }
  }

  var timer = null;
  function tick() {
    if (document.hidden) { return; }
    fetch('/chat/?json=1', { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) { if (j) { draw(j); } })
      .catch(function () {});
  }
  function start() { if (!timer) { timer = setInterval(tick, 5000); } }
  function stop() { clearInterval(timer); timer = null; }
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { stop(); } else { tick(); start(); }
  });
  toBottom();
  start();
})();
</script>
<?php pageFoot();
