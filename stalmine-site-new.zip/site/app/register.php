<?php
/* Напрямую из браузера не открывается: настоящий адрес страницы — /register/.
 * Файл лежит в app/ и подключается из register/index.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}
?>
<?php
require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/auth.php';
require_once __DIR__ . '/../inc/layout.php';

if (user()) { header('Location: /profile/'); exit; }
$err = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrfOk()) {
        $err[] = 'Форма устарела. Попробуйте ещё раз.';
    } else {
        $err = doRegister($pdo, trim(post('login')), post('pass'),
                          post('pass2'), trim(post('email')));
        if (!$err) {
            flash('Аккаунт создан. Войдите.');
            header('Location: /login/'); exit;
        }
    }
}
pageHead('Регистрация');
?>
<div class="form-wrap">
  <h1 class="sec">Регистрация</h1>
  <?php foreach ($err as $e): ?><div class="flash flash-err"><?= h($e) ?></div><?php endforeach; ?>
  <form method="post" class="form">
    <?= csrfField() ?>
    <label>Логин<input name="login" required minlength="3" maxlength="32" autocomplete="username"
      value="<?= h(post('login')) ?>"><small>Латиница, цифры, точка, дефис, подчёркивание</small></label>
    <label>Почта <span class="opt">— по желанию</span><input type="email" name="email" maxlength="190"
      autocomplete="email" value="<?= h(post('email')) ?>"><small>Восстановления пароля по почте пока нет.
      Оставьте адрес, если хотите, чтобы было к чему привязаться потом</small></label>
    <label>Пароль<input type="password" name="pass" required minlength="8" autocomplete="new-password"><small>От восьми знаков</small></label>
    <label>Пароль ещё раз<input type="password" name="pass2" required autocomplete="new-password"></label>
    <button class="btn" type="submit">Создать</button>
  </form>
</div>
<?php pageFoot();
