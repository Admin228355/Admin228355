<?php
/* Напрямую из браузера не открывается: настоящий адрес страницы — /logout/.
 * Файл лежит в app/ и подключается из logout/index.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}
?>
<?php
require_once __DIR__ . '/../inc/boot.php';
require_once __DIR__ . '/../inc/auth.php';

/* ВЫХОД ТРЕБУЕТ ТОКЕНА.
 *
 * Без него достаточно было заманить человека на картинку с адресом
 * logout.php, и его выкидывало из аккаунта на ровном месте. Урона мало,
 * а понять, почему тебя постоянно разлогинивает, невозможно. */
if (!isset($_GET['t']) || !is_string($_GET['t']) || !hash_equals(csrf(), $_GET['t'])) {
    header('Location: index.php');
    exit;
}

doLogout($pdo);
header('Location: index.php');
