<?php
/*  Адрес /chat/. Сама страница — в app/chat.php, здесь только вход. */
require __DIR__ . '/../app/chat.php';
