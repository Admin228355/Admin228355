<?php
/*  ГЛАВНАЯ ОТКРЫВАЕТСЯ ТОЛЬКО ПО «/», А НЕ ПО «/index.php».
 *
 *  Яндекс показывал сайт как «stalmine.ru › index.php»: он взял тот адрес,
 *  по которому страница ему попалась, а других указаний не было. Выглядит
 *  это как недоделанный сайт, и вдобавок один и тот же текст доступен по
 *  двум адресам — для поисковика это две страницы, делящие между собой вес.
 *
 *  Здесь второй адрес закрывается насовсем: 301 говорит «переехало и
 *  навсегда», и поисковик заменяет адрес в выдаче сам. Пара к этому —
 *  <link rel="canonical"> в layout.php.
 *
 *  Проверка идёт ДО boot.php: тот заводит сессию и лезет в базу, а для
 *  перенаправления ни то ни другое не нужно. */
if (str_contains((string)($_SERVER['REQUEST_URI'] ?? ''), '/index.php')) {
    header('Location: https://stalmine.ru/', true, 301);
    exit;
}

require_once __DIR__ . '/inc/boot.php';
require_once __DIR__ . '/inc/layout.php';
require_once __DIR__ . '/inc/mcstatus.php';

$st = mcStatus($CFG['mc_host'], (int)$CFG['mc_port']);
$news = $pdo->query(
    'SELECT slug, title, summary, created_at FROM news
      WHERE published = 1 ORDER BY created_at DESC LIMIT 3'
)->fetchAll();

/*  ЧИСЛА ДЛЯ СЧЁТЧИКОВ БЕРУТСЯ ИЗ БАЗЫ, А НЕ ВПИСЫВАЮТСЯ РУКАМИ.
 *
 *  Крутящаяся цифра, которая всегда показывает одно и то же, — это обман,
 *  и первый же человек, сложивший два и два, перестанет верить и всему
 *  остальному на странице. Здесь всё настоящее: сколько людей заходило,
 *  сколько нарядов сделано, сколько часов проведено в Зоне.
 *
 *  Если игра ещё ничего не присылала, показываем нули — это честно и
 *  выглядит как «сервер молодой», а не как поломка. */
try {
    $agg = $pdo->query(
        'SELECT COUNT(*) players,
                COALESCE(SUM(contracts),0) contracts,
                COALESCE(SUM(artifacts),0) artifacts,
                COALESCE(SUM(playtime_m),0) minutes
           FROM players'
    )->fetch() ?: [];
} catch (PDOException $e) {
    error_log('index agg: ' . $e->getMessage());
    $agg = [];
}
$mPlayers   = (int)($agg['players'] ?? 0);
$mContracts = (int)($agg['contracts'] ?? 0);
$mArtifacts = (int)($agg['artifacts'] ?? 0);
$mHours     = intdiv((int)($agg['minutes'] ?? 0), 60);

/** Стрелка в углу карточки. Одна на всю страницу — вынесена, чтобы не
 *  повторять разметку шесть раз. */
function goArrow(): string {
    return '<i class="go"><svg viewBox="0 0 24 24" aria-hidden="true">'
         . '<path d="M7 17 17 7M9 7h8v8"/></svg></i>';
}

/** Карточка «чем это отличается». Целиком ссылка: раньше стрелка в углу
 *  намекала на переход, а нажать было некуда — обманутое ожидание хуже, чем
 *  отсутствие стрелки. Ведёт в памятку, к подробному разбору.
 *  Сверху — рисунок той же рукой, что и первый экран. */
function feat(string $art, string $title, string $text, string $href): string {
    return sprintf('<a class="feat" href="%s"><div class="feat-art">%s</div>%s<b>%s</b><p>%s</p></a>',
                   h($href), art($art), goArrow(), h($title), h($text));
}

/** Заголовок раздела: номер, подпись над заголовком, сам заголовок и
 *  пояснение. Номер — не украшение: по нему видно, сколько осталось. */
function secHead(string $n, string $kicker, string $title, string $note = ''): string {
    return '<header class="sh" data-fx="1"><p class="sh-k"><span>' . h($n) . '</span>' . h($kicker) . '</p>'
         . '<h2 class="lead-h">' . h($title) . '</h2>'
         . ($note !== '' ? '<p class="lead-note">' . $note . '</p>' : '') . '</header>';
}

/*  Пустой второй довод НАРОЧНО: на главной не подсвечивается ни один
 *  пункт меню. Раньше горели «Новости» — человек видел подсветку и
 *  решал, что уже открыл их. */
pageHead('Главная');
?>
<section class="lead-hero">
  <div class="hero-copy" data-fx="1">
    <p class="over"><i class="tick"></i>Урал · закрытая территория · Minecraft 26.1.2</p>
    <h1>Кыштымский<br><span>Пробой</span></h1>
    <p class="sub">Здесь ходят в зону отчуждения и возвращаются оттуда с
    добычей. База — торговцы, оружейник, мастерская и работа. За воротами —
    фон, мутанты и аномалии.</p>

    <?php /*  АДРЕС СЕРВЕРА — ОДНОЙ СТРОКОЙ ПОД ЗАГОЛОВКОМ, А НЕ ПАНЕЛЬЮ СБОКУ.
              Те же сведения — адрес, состояние, сколько людей — в строку,
              и заголовку ничего не мешает. */ ?>
    <div class="joinbar">
      <div class="jb-addr">
        <span>Адрес сервера</span>
        <b class="mono" id="mcaddr"><?= h(mcShow($CFG)) ?></b>
        <button type="button" class="jb-copy" data-copy="<?= h(mcShow($CFG)) ?>"
                title="Скопировать адрес">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M16 1H4a2 2 0 0 0-2 2v14h2V3h12zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11z"/></svg>
        </button>
      </div>
      <div class="jb-state">
        <i class="dot<?= $st['online'] ? ' on' : '' ?>"></i>
        <b class="<?= $st['online'] ? 'up' : 'down' ?>"><?= $st['online'] ? 'на связи' : 'молчит' ?></b>
        <span class="mono"><?= (int)$st['now'] ?><?= $st['max'] ? ' / ' . (int)$st['max'] : '' ?> в Зоне</span>
      </div>
    </div>

    <div class="row">
      <a class="btn" href="/start/">Как начать играть
        <svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M13 5l7 7-7 7-1.4-1.4 4.6-4.6H4v-2h12.2l-4.6-4.6z"/></svg></a>
      <a class="btn ghost" href="/wiki/">Памятка</a>
    </div>
  </div>

  <?php /*  РИСУНОК ПЕРВОГО ЭКРАНА вместо пустоты справа. Линией, в цветах
            темы, без загрузки картинки — см. inc/art.php. */ ?>
  <figure class="hero-art" data-fx="2">
    <?= art('hero') ?>
    <figcaption><span>Сектор 7</span><span class="mono">56°42′ с. ш. · 60°49′ в. д.</span></figcaption>
  </figure>
</section>

<div class="metrics" data-fx="3">
  <div class="metric">
    <svg class="ic" viewBox="0 0 24 24"><path fill="currentColor" d="M16 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm-8 0a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm0 2c-3 0-8 1.5-8 4.5V20h9v-2.5c0-1.2.6-2.3 1.5-3.1A12 12 0 0 0 8 13zm8 0a11 11 0 0 0-2.6.3A4.6 4.6 0 0 1 15 17.5V20h9v-2.5c0-3-5-4.5-8-4.5z"/></svg>
    <div class="t"><b>Сталкеров</b><span>заходило в Зону</span></div>
    <div class="n" data-count="<?= $mPlayers ?>">0</div>
  </div>
  <div class="metric">
    <svg class="ic" viewBox="0 0 24 24"><path fill="currentColor" d="M19 3h-4.2a3 3 0 0 0-5.6 0H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm-7 0a1 1 0 1 1-1 1 1 1 0 0 1 1-1zm-1.3 14L7 13.4l1.4-1.4 2.3 2.3 5-5L17 10.7z"/></svg>
    <div class="t"><b>Нарядов</b><span>выполнено для Связного</span></div>
    <div class="n" data-count="<?= $mContracts ?>">0</div>
  </div>
  <div class="metric">
    <svg class="ic" viewBox="0 0 24 24"><path fill="currentColor" d="m12 2 2.6 6.3L21 9.6l-4.8 4.3L17.6 21 12 17.6 6.4 21l1.4-7.1L3 9.6l6.4-1.3z"/></svg>
    <div class="t"><b>Отголосков</b><span>поднято из аномалий</span></div>
    <div class="n" data-count="<?= $mArtifacts ?>">0</div>
  </div>
  <div class="metric">
    <svg class="ic" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm1 10.6V6h-2v7.4l5.2 3.1 1-1.7z"/></svg>
    <div class="t"><b>Часов</b><span>проведено за воротами</span></div>
    <div class="n" data-count="<?= $mHours ?>">0</div>
  </div>
</div>

<?= secHead('01', 'Особенности', 'Чем это отличается от обычного выживания',
    'Шесть вещей, из-за которых первый выход обычно заканчивается плохо. Подробно — в <a href="/wiki/">памятке</a>.') ?>

<div class="feats" data-fx="2">
  <?= feat('work', 'Работа',
      'Наряды выдаёт Связной на базе: принести, найти, зачистить. За сделанное платят и растёт репутация, а с ней открывается то, что деньгами не берётся.',
      '/wiki/#work') ?>
  <?= feat('suit', 'Костюм',
      'Вместо четырёх кусков брони — один комплект. Внутрь вставляется фильтр, и он расходуется. Без фильтра в грязных местах доза набирается быстро.',
      '/wiki/#suit') ?>
  <?= feat('weight', 'Вес',
      'Рюкзак не бездонный, и жадность видно сразу: перегруз отнимает скорость. Весит только то, у чего вес написан в описании.',
      '/wiki/#weight') ?>
  <?= feat('death', 'Смерть',
      'Из карманов не пропадает ничего. Рюкзак с добычей падает на месте — тело можно найти и забрать своё, если успеешь раньше остальных.',
      '/wiki/#death') ?>
  <?= feat('guns', 'Оружие',
      'Стволы выдаёт оружейник, и он же принимает их обратно. Патрон подбирается по классу ствола. Клавиша выброса перезаряжает, а не выбрасывает.',
      '/wiki/#guns') ?>
  <?= feat('burst', 'Всплеск',
      'Иногда по всей Зоне объявляют выброс. Времени ровно столько, чтобы дойти до ближайшей крыши. Кто остался под открытым небом, тот не остался.',
      '/wiki/#burst') ?>
</div>

<?= secHead('02', 'Ранги', 'Путь сталкера',
    'Ступени открываются репутацией, а не деньгами. Купить нельзя ни одну.') ?>

<?php /*  НАШИВКИ В РЯД, А НЕ СТОЛБИКОМ. Четыре ступени читаются как путь
          слева направо; на телефоне складываются в столбик сами. */ ?>
<div class="ranks" data-fx="2">
  <div class="rank"><?= art('rank1') ?>
    <div class="rank-h"><b>Новичок</b><span class="pill now">начало</span></div>
    <p>Стартовый набор, костюм без фильтра и наряды «принести». Первые сутки в
    чате видна метка новичка — чтобы подсказали, а не обобрали.</p></div>
  <div class="rank"><?= art('rank2') ?>
    <div class="rank-h"><b>Сталкер</b><span class="pill">репутация</span></div>
    <p>Оружейник начинает продавать, а не только чинить. Открывается барахолка
    и обмен с другими.</p></div>
  <div class="rank"><?= art('rank3') ?>
    <div class="rank-h"><b>Ветеран</b><span class="pill">репутация</span></div>
    <p>Наряды на зачистку, дальние точки, тайники. Цена у торговцев ниже:
    со своими торгуются иначе.</p></div>
  <div class="rank"><?= art('rank4') ?>
    <div class="rank-h"><b>Легенда</b><span class="pill ok">потолок</span></div>
    <p>Нашивки, которые не купить, и вещи, которые не выпадают. Дальше ступеней
    нет — дальше только имя.</p></div>
</div>

<?php /*  ЛЕНТА «ЧТО В ЗОНЕ» — ритм страницы, а не украшение.
          ЗДЕСЬ ТОЛЬКО ТО, ЧТО ДЕЙСТВИТЕЛЬНО РАБОТАЕТ: в подвале обещано
          «чего в описании нет, того нет и в игре». */ ?>
<?= secHead('03', 'Содержание', 'Что в Зоне', 'Всё перечисленное работает сейчас, а не запланировано.') ?>

<div class="strip" data-fx="2">
  <span>Аномалии</span><span>Отголоски</span><span>Мутанты</span>
  <span>Заброска</span><span>Всплеск</span><span>Тайники</span>
  <span>Наряды</span><span>Барахолка</span><span>Мастерская</span>
  <span>Оружейник</span><span>Нашивки</span><span>Группировки</span>
  <span>Радиация</span><span>Ранения</span><span>Вес</span>
  <span>Склад</span><span>Тела</span><span>Журнал</span>
</div>

<?php /*  ТРИ ШАГА. Нумерация здесь честная: это последовательность. */ ?>
<?= secHead('04', 'Начало', 'Три шага до Зоны') ?>

<ol class="steps" data-fx="2">
  <li>
    <b>Поставьте версию 26.1.2</b>
    <p>Подойдёт любой лаунчер. Модов не нужно: HUD, мини-карта и оружие
    приезжают набором ресурсов сами, при первом входе.</p>
    <a href="/start/">Где взять лаунчер</a>
  </li>
  <li>
    <b>Заведите аккаунт и привяжите ник</b>
    <p>Без привязки неизвестно, кому начислять талоны и чью статистику
    показывать в профиле.</p>
    <?php if (!user()): ?><a href="/register/">Зарегистрироваться</a>
    <?php else: ?><a href="/profile/">Личный кабинет</a><?php endif; ?>
  </li>
  <li>
    <b>Зайдите по адресу сервера</b>
    <p>Первый вход начинается с обучения на полигоне: семь шагов, после
    которых понятно, зачем фильтр и почему рюкзак выпадает.</p>
    <button type="button" class="linklike" data-copy="<?= h(mcShow($CFG)) ?>">Скопировать адрес</button>
  </li>
</ol>

<?= secHead('05', 'Сводки', 'Новости') ?>
<div class="newsgrid" data-fx="2">
  <?php if (!$news): ?>
    <p class="muted">Пока пусто.</p>
  <?php else: foreach ($news as $n): ?>
    <a class="ncard" href="/news/?s=<?= h($n['slug']) ?>">
      <time><?= h(date('d.m.Y', strtotime((string)$n['created_at']))) ?></time>
      <h3><?= h($n['title']) ?></h3>
      <?php if ($n['summary']): ?><p><?= h($n['summary']) ?></p><?php endif; ?>
      <span class="more">Читать</span>
    </a>
  <?php endforeach; endif; ?>
</div>
<p class="allnews" data-fx="1"><a href="/news/">Все новости</a></p>

<?php /*  ПОДДЕРЖКА — ОТДЕЛЬНО ОТ ПОКУПКИ. Тут не продаётся ничего: ни
          талонов, ни вещей. Без входа и без ника — кнопка ведёт на
          /donate/, где хватает одной суммы. */ ?>
<section class="giveband" data-fx="1">
  <div class="gb-art"><?= art('fire') ?></div>
  <div class="gb-txt">
    <p class="sh-k"><span>06</span>Поддержка</p>
    <h2>Подкиньте дров в костёр</h2>
    <p>Сервер делают несколько человек в свободное время и платят за него из
    своего кармана. Пожертвование идёт на хостинг и разработку — без аккаунта,
    без привязки ника и без обязательств. В игре оно ничего не даёт: это просто
    спасибо.</p>
    <div class="gb-quick">
      <?php foreach ([100, 300, 500, 1000] as $q): ?>
        <a href="/donate/?sum=<?= $q ?>"><?= number_format($q, 0, '', ' ') ?> ₽</a>
      <?php endforeach; ?>
      <a href="/donate/" class="other">своя сумма</a>
    </div>
    <a class="btn" href="/donate/">Поддержать разработку</a>
  </div>
</section>

<section class="cta" data-fx="1">
  <h2>Зона не ждёт</h2>
  <p>Аккаунт нужен, чтобы привязать ник, получать талоны за пополнение и видеть
  свою статистику. Пять минут — и можно выходить.</p>
  <div class="cta-pros">
    <div><svg class="ic" viewBox="0 0 24 24"><path fill="currentColor" d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg> Клиент обычный, без модов</div>
    <div><svg class="ic" viewBox="0 0 24 24"><path fill="currentColor" d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg> Версия 26.1.2</div>
    <div><svg class="ic" viewBox="0 0 24 24"><path fill="currentColor" d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg> Вход бесплатный</div>
  </div>
  <?php if (!user()): ?>
    <a class="btn" href="/register/">Зарегистрироваться</a>
    <p class="fine">Уже есть аккаунт? <a href="/login/">Войти</a></p>
  <?php else: ?>
    <a class="btn" href="/start/">Как зайти на сервер</a>
    <p class="fine">Вы вошли как <b class="who"><?= h(user()['login']) ?></b></p>
  <?php endif; ?>
  <div class="cta-art"><?= art('gate') ?></div>
</section>
<?php pageFoot();
