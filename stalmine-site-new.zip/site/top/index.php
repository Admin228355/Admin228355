<?php
/* Красивый адрес /top/. Сама страница — в app/top.php. */
require __DIR__ . '/../app/top.php';
