<?php
/* Старый адрес. 301 — переезд навсегда. */
header('Location: /legal/', true, 301);
