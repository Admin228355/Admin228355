<?php
/* Красивый адрес /profile/. Сама страница — в app/profile.php. */
require __DIR__ . '/../app/profile.php';
