<?php
/*  Адрес /start/. Сама страница — в app/start.php, здесь только вход. */
require __DIR__ . '/../app/start.php';
