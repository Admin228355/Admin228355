<?php
/* Красивый адрес /donate/. Сама страница — в app/donate.php. */
require __DIR__ . '/../app/donate.php';
