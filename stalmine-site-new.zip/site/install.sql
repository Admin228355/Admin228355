-- ============================================================================
--  Схема сайта «Кыштымский Пробой»
--
--  Заливать один раз, до первого запуска сайта:
--      mysql -h ХОСТ -u ПОЛЬЗОВАТЕЛЬ -p ИМЯ_БАЗЫ < install.sql
--  или вставить целиком в phpMyAdmin на вкладке SQL.
--
--  ПОЧЕМУ utf8mb4. utf8 в MySQL — это не полный UTF-8, он держит только три
--  байта на символ: кириллица влезает, а эмодзи и часть знаков нет, и
--  вставка молча обрезается. utf8mb4 — настоящий UTF-8.
--
--  ПОЧЕМУ ВЕЗДЕ InnoDB. Нужны внешние ключи и транзакции: привязка ника к
--  аккаунту должна либо пройти целиком, либо не пройти вовсе.
-- ============================================================================

SET NAMES utf8mb4;

-- ---------------------------------------------------------------------------
--  Аккаунты сайта
--
--  ПАРОЛЬ ХРАНИТСЯ ХЕШЕМ, и только им. Поле называется pass_hash, а не
--  password, чтобы никому не пришло в голову положить туда пароль.
--  Длина 255 — password_hash() в PHP может сменить алгоритм и удлинить
--  результат, и обрезка сломала бы вход всем разом.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  login         VARCHAR(32)  NOT NULL,
  email         VARCHAR(190) DEFAULT NULL,
  pass_hash     VARCHAR(255) NOT NULL,
  -- Ник в игре. Пустой, пока не привязали.
  mc_nick       VARCHAR(32)  DEFAULT NULL,
  mc_uuid       CHAR(36)     DEFAULT NULL,
  -- Роль: player | moder | admin. Строкой, а не числом: в базе должно быть
  -- видно глазами, кто есть кто.
  role          VARCHAR(16)  NOT NULL DEFAULT 'player',
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login    DATETIME     DEFAULT NULL,
  last_ip       VARBINARY(16) DEFAULT NULL,
  -- Адрес, с которого РЕГИСТРИРОВАЛИСЬ. Отдельно от last_ip нарочно: тот
  -- перезаписывается при каждом входе, и считать по нему регистрации за
  -- сутки нельзя — счёт разъедется на первом же заходе.
  reg_ip        VARBINARY(16) DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_login (login),
  UNIQUE KEY uq_nick  (mc_nick),
  KEY ix_created (created_at),
  KEY ix_reg_ip (reg_ip, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  Привязка ника: одноразовый код
--
--  Как это работает: человек в кабинете жмёт «привязать», сайт выдаёт код.
--  В игре тот же код вводится командой. Пока в игре нет моста к базе,
--  подтверждает администратор — таблица к этому готова заранее.
--
--  Код одноразовый и с сроком: без срока выданный код живёт вечно, и
--  случайно показанный на стриме код останется рабочим.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS link_codes (
  code       CHAR(8)      NOT NULL,
  user_id    INT UNSIGNED NOT NULL,
  mc_nick    VARCHAR(32)  NOT NULL,
  expires_at DATETIME     NOT NULL,
  used_at    DATETIME     DEFAULT NULL,
  PRIMARY KEY (code),
  KEY ix_user (user_id),
  CONSTRAINT fk_code_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  Новости
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS news (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  slug       VARCHAR(80)  NOT NULL,
  title      VARCHAR(200) NOT NULL,
  -- Не «lead»: это зарезервированное слово MySQL 8 (оконная функция
  -- LEAD), и как имя столбца оно требует кавычек в каждом запросе.
  summary    VARCHAR(400) DEFAULT NULL,
  body       MEDIUMTEXT   NOT NULL,
  author_id  INT UNSIGNED DEFAULT NULL,
  published  TINYINT(1)   NOT NULL DEFAULT 0,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_slug (slug),
  KEY ix_pub (published, created_at),
  CONSTRAINT fk_news_author FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  Игровые показатели
--
--  ПОКА ЭТА ТАБЛИЦА ПУСТА, И ЭТО НЕ ОШИБКА. Игра хранит всё в
--  variables.csv (Skript), а писать в MySQL она не умеет: на сервере нет
--  ни аддона к базе, ни возможности сделать сетевой запрос — проверено
--  пробой. Пока мост не поставлен, сайт честно показывает «нет данных»,
--  а не выдумывает нули.
--
--  Схема сделана заранее, чтобы мост, когда появится, просто писал сюда.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS players (
  mc_nick     VARCHAR(32)  NOT NULL,
  mc_uuid     CHAR(36)     DEFAULT NULL,
  faction     VARCHAR(32)  DEFAULT NULL,
  rank_name   VARCHAR(32)  DEFAULT NULL,
  reputation  INT          NOT NULL DEFAULT 0,
  money       BIGINT       NOT NULL DEFAULT 0,
  playtime_m  INT UNSIGNED NOT NULL DEFAULT 0,
  deaths      INT UNSIGNED NOT NULL DEFAULT 0,
  contracts   INT UNSIGNED NOT NULL DEFAULT 0,
  artifacts   INT UNSIGNED NOT NULL DEFAULT 0,
  patch_worn  VARCHAR(48)  DEFAULT NULL,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (mc_nick),
  KEY ix_rep (reputation DESC),
  KEY ix_upd (updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  Нашивки игрока — отдельной таблицей, а не полем со списком.
--  Список в одном поле нельзя ни отсортировать, ни посчитать.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS player_patches (
  mc_nick  VARCHAR(32) NOT NULL,
  patch_id VARCHAR(32) NOT NULL,
  got_at   DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (mc_nick, patch_id),
  KEY ix_patch (patch_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  Попытки входа — против перебора пароля.
--  Считаем по логину И по адресу: только по адресу забанит весь подъезд,
--  только по логину — даст перебирать разные логины с одного места.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_tries (
  id       INT UNSIGNED NOT NULL AUTO_INCREMENT,
  login    VARCHAR(32)  NOT NULL,
  ip       VARBINARY(16) NOT NULL,
  ok       TINYINT(1)   NOT NULL DEFAULT 0,
  at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_login_at (login, at),
  KEY ix_ip_at (ip, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  Сообщения об ошибках с сайта
--
--  ЗАЧЕМ ОТДЕЛЬНО ОТ ИГРОВОГО /bug. В игре сообщение пишется на бегу и
--  почти всегда состоит из одной строки «сломалось». С сайта человек
--  пишет спокойно, и есть куда положить «что делал» и «что ожидал» —
--  без этих двух полей воспроизвести чужую ошибку почти невозможно.
--
--  СОСТОЯНИЯ: new → confirmed | rejected → fixed. Отдельно reward: сколько
--  начислено за находку. Строкой, а не числом, состояния сделаны нарочно —
--  в базе должно быть видно глазами.
--
--  ВЫПЛАТА ХРАНИТСЯ ЗДЕСЬ, А НАЧИСЛЯЕТСЯ В ИГРЕ. Пока моста нет,
--  администратор выдаёт вручную и ставит отметку paid_at, чтобы одну и ту
--  же находку не оплатили дважды.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bug_reports (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    INT UNSIGNED DEFAULT NULL,
  mc_nick    VARCHAR(32)  DEFAULT NULL,
  title      VARCHAR(160) NOT NULL,
  where_at   VARCHAR(160) DEFAULT NULL,
  steps      TEXT         NOT NULL,
  expected   TEXT         DEFAULT NULL,
  status     VARCHAR(16)  NOT NULL DEFAULT 'new',
  admin_note VARCHAR(500) DEFAULT NULL,
  reward     INT          NOT NULL DEFAULT 0,
  paid_at    DATETIME     DEFAULT NULL,
  ip         VARBINARY(16) DEFAULT NULL,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_status (status, created_at),
  KEY ix_user (user_id),
  CONSTRAINT fk_bug_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------
--  ПЛАТЕЖИ
--
--  Таблица была заведена вручную 06.09, когда подключали приём оплаты, и в
--  этот файл не попала. Описана здесь задним числом: схема, которой нет в
--  install.sql, существует только в голове, а голова забывает.
--
--  СОСТОЯНИЯ И ПОЧЕМУ ИХ ЧЕТЫРЕ.
--    pending  — счёт выставлен, денег ещё нет;
--    paid     — ЮKassa подтвердила оплату (yk-hook.php), знаки не выданы;
--    granted  — знаки выданы в игре (мост, 9-bridge.sk);
--    canceled — платёж отменён.
--  Разделение paid и granted не формальность: между приходом денег и
--  выдачей стоит игровой сервер, и он может быть выключен. Пока состояние
--  paid — платёж висит в очереди моста и будет выдан, как только сервер
--  ответит.
--
--  yk_id УНИКАЛЕН, И ЭТО ГЛАВНАЯ ЗАЩИТА. ЮKassa повторяет уведомление об
--  оплате, пока не получит 200, — сеть моргнула, пришло второе и третье.
--  Уникальный ключ делает двойную запись невозможной на уровне базы, а не
--  на уровне внимательности кода.
--
--  coins ХРАНИТСЯ, А НЕ СЧИТАЕТСЯ ЗАНОВО. Проценты бонуса со временем
--  меняются; платёж должен помнить те условия, на которые человек
--  согласился, а не те, что действуют сегодня.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  yk_id      VARCHAR(64)  NOT NULL,
  user_id    INT UNSIGNED DEFAULT NULL,
  mc_nick    VARCHAR(32)  DEFAULT NULL,
  amount_rub INT          NOT NULL,
  bonus_pct  INT          NOT NULL DEFAULT 0,
  coins      INT          NOT NULL,
  status     VARCHAR(16)  NOT NULL DEFAULT 'pending',
  ip         VARBINARY(16) DEFAULT NULL,
  paid_at    DATETIME     DEFAULT NULL,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY ux_yk (yk_id),
  KEY ix_status (status, id),
  KEY ix_nick (mc_nick),
  CONSTRAINT fk_pay_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------
--  НАСТРОЙКИ САЙТА
--
--  Пары «ключ — значение» для того, что владелец меняет сам: описание для
--  поисковика, подпись в подвале, картинка предпросмотра.
--
--  ПОЧЕМУ НЕ В КОНФИГЕ. Конфиг лежит выше корня сайта, и чтобы поправить в
--  нём строчку, нужен доступ по FTP. Адрес телеграм-канала меняется чаще,
--  чем пароль базы, — держать их в одном файле значит звать постороннего
--  ради ссылки.
--
--  ЗНАЧЕНИЯ ПО УМОЛЧАНИЮ ЗАДАНЫ В КОДЕ, А НЕ ЗДЕСЬ. Пустая таблица не
--  должна ломать сайт: setting() возвращает запасное значение, и страница
--  открывается даже на нетронутой базе.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS site_settings (
  k VARCHAR(48) NOT NULL,
  v TEXT DEFAULT NULL,
  PRIMARY KEY (k)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------
--  ССЫЛКИ НА СООБЩЕСТВА
--
--  Показываются в подвале каждой страницы и на главной. Отдельной таблицей,
--  а не строкой в настройках: ссылок несколько, у каждой свой порядок и
--  своя видимость, и разбирать всё это из одной строки — лишняя морока.
--
--  kind ЗАДАЁТ ЗНАЧОК. Список видов закрыт (см. LINK_KINDS в inc/site.php):
--  значки нарисованы прямо в странице, и вида, которого там нет, взяться
--  неоткуда.
--
--  visible ВМЕСТО УДАЛЕНИЯ. Канал закрыли на неделю — ссылку прячут, а не
--  стирают: потом её не придётся набирать заново.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS site_links (
  id      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  kind    VARCHAR(16)  NOT NULL DEFAULT 'site',
  title   VARCHAR(60)  NOT NULL,
  url     VARCHAR(300) NOT NULL,
  note    VARCHAR(120) DEFAULT NULL,
  sort    INT          NOT NULL DEFAULT 0,
  visible TINYINT(1)   NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  KEY ix_show (visible, sort)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------
--  СООБЩЕНИЯ С САЙТА В ИГРОВОЙ ЧАТ
--
--  Владелец пишет из раздела управления, игровой сервер забирает мостом и
--  показывает в чате с пометкой «САЙТ», чтобы это нельзя было принять за
--  слова игрока, стоящего рядом.
--
--  ПОЧЕМУ ОЧЕРЕДЬ, А НЕ ПРЯМАЯ ОТПРАВКА. Сайт не умеет достучаться до
--  игрового сервера и не должен уметь: входящих соединений в игру не
--  существует. Сообщение просто ждёт в таблице, пока сервер за ним придёт.
--  Заодно это переживает выключенный сервер: написанное ночью покажется,
--  как только он поднимется.
--
--  body, А НЕ text: «text» — тип данных MySQL, и как имя столбца он требует
--  кавычек в каждом запросе.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS site_msgs (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    INT UNSIGNED DEFAULT NULL,
  author     VARCHAR(32)  NOT NULL,
  body       VARCHAR(300) NOT NULL,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sent_at    DATETIME     DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_pending (sent_at, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------
--  СЧЁТЧИКИ ИГРОКА
--
--  Всё, что игра считает про человека: вылазки, находки, сделки, смерти.
--
--  ПОЧЕМУ ОТДЕЛЬНОЙ ТАБЛИЦЕЙ, А НЕ СТОЛБЦАМИ В players. В players лежит то,
--  что показывают в рейтинге, — десяток полей, и они меняются редко.
--  Счётчиков в игре два десятка, и новые появляются с каждой механикой.
--  Столбцами это означало бы правку схемы базы при каждой правке скрипта;
--  здесь новый ключ принимается без единого изменения.
--
--  Ключ приходит из игры и чистится по белому списку символов (см. bridge.php):
--  в имя столбца он не попадает, но в базу — да, а мусор оттуда потом не
--  вычистить.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS player_stats (
  mc_nick VARCHAR(32) NOT NULL,
  k       VARCHAR(32) NOT NULL,
  v       BIGINT      NOT NULL DEFAULT 0,
  PRIMARY KEY (mc_nick, k),
  KEY ix_key (k, v)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------
--  КОММЕНТАРИИ ПОД НОВОСТЯМИ
--
--  Пишут только вошедшие: аноним под новостью — это спам через сутки после
--  открытия, проверено на любом сайте с открытой формой.
--
--  hidden ВМЕСТО УДАЛЕНИЯ. Убранный комментарий должен оставаться видимым
--  для управления: иначе разбирая жалобу невозможно понять, за что человека
--  наказали, — доказательства стёрты вместе с поводом.
--
--  author ХРАНИТСЯ ОТДЕЛЬНО ОТ user_id. Ник в игре может смениться, а под
--  комментарием должно остаться то имя, под которым его написали.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS news_comments (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  news_id    INT UNSIGNED NOT NULL,
  user_id    INT UNSIGNED DEFAULT NULL,
  author     VARCHAR(32)  NOT NULL,
  body       VARCHAR(1000) NOT NULL,
  hidden     TINYINT(1)   NOT NULL DEFAULT 0,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ip         VARBINARY(16) DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_news (news_id, hidden, id),
  CONSTRAINT fk_com_news FOREIGN KEY (news_id) REFERENCES news(id) ON DELETE CASCADE,
  CONSTRAINT fk_com_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------
--  ИГРОВОЙ ЧАТ НА САЙТЕ
--
--  Обратная половина разговора: что сказали в игре, видно на сайте.
--  Приходит ТОЛЬКО общий канал (см. 9-chat-relay.sk) — переговоры
--  группировки и разговор рядом сюда не попадают намеренно.
--
--  ЭТО ПОТОК, А НЕ АРХИВ. Читают отсюда сорок последних строк; старое
--  удаляется само, иначе таблица растёт вечно ради того, что никто не
--  откроет.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS game_msgs (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  author     VARCHAR(32)  NOT NULL,
  faction    VARCHAR(32)  DEFAULT NULL,
  body       VARCHAR(300) NOT NULL,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_time (id DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------------------------------------------
--  ТЕЛЕГРАМ
--
--  tg_users — кто привязал бота. Ключ — идентификатор в Telegram, а не наш:
--  сообщение приходит именно от него, и искать по нему надо на каждое.
--
--  user_id ОБНУЛЯЕТСЯ ПРИ ОТВЯЗКЕ, А СТРОКА ОСТАЁТСЯ. Человек часто
--  отвязывается и возвращается; сохранённые настройки уведомлений избавляют
--  его от повторной возни, а без привязки они всё равно не работают.
--
--  Флаги n_* — по одному на вид уведомления. Список закрыт в TG_KINDS
--  (inc/tg.php): имя столбца подставляется в запрос, и приходить снаружи оно
--  не должно.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tg_users (
  tg_id      BIGINT       NOT NULL,
  user_id    INT UNSIGNED DEFAULT NULL,
  tg_name    VARCHAR(64)  DEFAULT NULL,
  n_airdrop  TINYINT(1)   NOT NULL DEFAULT 1,
  n_emission TINYINT(1)   NOT NULL DEFAULT 1,
  n_news     TINYINT(1)   NOT NULL DEFAULT 1,
  n_pay      TINYINT(1)   NOT NULL DEFAULT 1,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (tg_id),
  KEY ix_user (user_id),
  CONSTRAINT fk_tg_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------------
--  Разовые коды привязки телеграма.
--
--  Код уходит В ССЫЛКУ вида t.me/бот?start=КОД: человек нажимает кнопку в
--  кабинете, Telegram открывается и сам отправляет «/start КОД». Набирать
--  восемь знаков с телефона — это половина отвалившихся на полпути.
--
--  Срок жизни короткий нарочно: ссылка попадает в историю браузера и в
--  список чатов, и вечный код в ней — это вечная возможность привязать
--  чужой аккаунт.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS tg_codes (
  code       VARCHAR(24)  NOT NULL,
  user_id    INT UNSIGNED NOT NULL,
  expires_at DATETIME     NOT NULL,
  used_at    DATETIME     DEFAULT NULL,
  PRIMARY KEY (code),
  KEY ix_user (user_id),
  CONSTRAINT fk_tgc_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
