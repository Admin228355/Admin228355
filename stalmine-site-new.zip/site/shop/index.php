<?php
/* Красивый адрес /shop/. Сама страница — в app/shop.php. */
require __DIR__ . '/../app/shop.php';
