<?php
/* Красивый адрес /rules/. Сама страница — в app/rules.php. */
require __DIR__ . '/../app/rules.php';
