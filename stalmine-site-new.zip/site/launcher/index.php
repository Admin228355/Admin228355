<?php
/* Красивый адрес /launcher/. Сама страница — в app/get.php.
 * Рядом в этой же папке лежит сам STALMINE.exe. */
require __DIR__ . '/../app/get.php';
