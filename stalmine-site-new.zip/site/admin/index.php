<?php
/* Красивый адрес /admin/. Сама страница — в app/admin.php. */
require __DIR__ . '/../app/admin.php';
