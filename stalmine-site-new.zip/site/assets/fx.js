/* ============================================================================
 *  fx.js — декоративный и анимационный слой главной.
 *
 *  БЕЗ БИБЛИОТЕК, И ЭТО ТРЕБОВАНИЕ, А НЕ ПРИНЦИП. Сайт открывают с телефона
 *  и не всегда с хорошей связью; полтора мегабайта чужого кода ради сетки на
 *  фоне — это секунды ожидания вместо секунд игры.
 *
 *  ВСЁ ТЯЖЁЛОЕ РИСУЕТ ОДИН ХОЛСТ. Сетка пола и слой узлов — это две тысячи
 *  элементов, если делать их разметкой; браузер на слабом телефоне на этом
 *  ложится. На холсте они стоят один кадр отрисовки и не трогают вёрстку.
 *
 *  «УМЕНЬШИТЬ ДВИЖЕНИЕ» УВАЖАЕТСЯ ЧЕСТНО. Если в системе стоит эта
 *  настройка, анимации не приглушаются, а НЕ ЗАПУСКАЮТСЯ: счётчики сразу
 *  показывают итог, блоки сразу видны, холст рисует один неподвижный кадр.
 *  Для части людей движущийся фон — это не украшение, а головная боль.
 * ========================================================================= */

(function () {
  'use strict';

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------------
   *  1. ФОН: изометрическая сетка пола + слой узлов
   *
   *  Сетка уходит к линии горизонта — под содержимым появляется «пол», и
   *  страница перестаёт быть плоским листом. Узлы дрейфуют сами по себе и
   *  соединяются линиями, когда оказываются близко: это дешевле, чем
   *  хранить готовый граф, и выглядит живее.
   * --------------------------------------------------------------------- */
  function background() {
    var cv = document.getElementById('fx-bg');
    if (!cv) { return; }
    var ctx = cv.getContext('2d');
    var W = 0, H = 0, dpr = Math.min(window.devicePixelRatio || 1, 2);

    /*  Цвета берём из самой страницы, а не вписываем сюда: тема
     *  переключается на лету, и вшитый цвет остался бы от старой. */
    function tone(name, fallback) {
      var v = getComputedStyle(document.documentElement)
                .getPropertyValue(name).trim();
      return v || fallback;
    }
    var cRule, cBrass;
    function readTones() {
      cRule = tone('--rule', '#33362A');
      cBrass = tone('--brass', '#C8A22B');
    }

    /*  КУРСОР УЧАСТВУЕТ В КАРТИНКЕ.
     *
     *  Точки разбегаются от него, а точка схода сетки уходит следом — фон
     *  перестаёт быть обоями и начинает отвечать. Держим цель отдельно от
     *  текущего значения и подтягиваем плавно: если гнать сетку прямо за
     *  мышью, она дёргается и от этого рябит в глазах.
     *
     *  Пальцем по экрану это не воспроизвести, и не надо: на телефоне курсора
     *  нет, mx/my остаются посередине, и всё выглядит как раньше. */
    var mx = 0.5, my = 0.5, tx = 0.5, ty = 0.5;
    window.addEventListener('pointermove', function (e) {
      if (e.pointerType === 'touch') { return; }
      tx = e.clientX / window.innerWidth;
      ty = e.clientY / window.innerHeight;
    }, { passive: true });

    var nodes = [];
    function seed() {
      nodes = [];
      /*  Плотность узлов от ширины, а не постоянная: на телефоне тридцать
       *  точек выглядят мусором, на широком экране — пустотой. */
      var n = Math.round(Math.min(110, Math.max(26, W / 17)));
      for (var i = 0; i < n; i++) {
        nodes.push({
          x: Math.random() * W,
          y: Math.random() * H,
          dx: (Math.random() - 0.5) * 0.12,
          dy: (Math.random() - 0.5) * 0.12
        });
      }
    }

    function resize() {
      W = cv.clientWidth;
      H = cv.clientHeight;
      cv.width = Math.round(W * dpr);
      cv.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      readTones();
      seed();
    }

    /*  Сетка в перспективе. Горизонт — на трети высоты; линии «вглубь»
     *  сходятся к точке схода, поперечные сгущаются к горизонту. */
    function grid(off) {
      /*  Точка схода гуляет вслед за курсором, но не дальше четверти экрана
       *  от центра: иначе «пол» заваливается набок и выглядит поломкой. */
      var hz = H * 0.34, vx = W * (0.5 + (mx - 0.5) * 0.5);
      var i, k, t, y, x;

      /*  ДВА СЛОЯ ВМЕСТО ОДНОГО.
       *
       *  Крупный держит форму пола, мелкий — заполняет промежутки и даёт
       *  ощущение глубины: у горизонта клетка мельче, под ногами крупнее,
       *  как на настоящем полу. Одним слоем такого не выходит: сделать его
       *  гуще значит получить муар у горизонта и кашу вблизи. */

      /* --- мелкий слой: тусклее, вдвое чаще ------------------------------ */
      ctx.lineWidth = 1;
      ctx.strokeStyle = cRule;
      ctx.globalAlpha = 0.22;
      ctx.beginPath();
      for (i = -44; i <= 44; i++) {
        x = vx + i * (W / 28);
        ctx.moveTo(vx + (x - vx) * 0.04, hz);
        ctx.lineTo(x, H);
      }
      for (k = 1; k <= 52; k++) {
        t = (k + off) / 52;
        y = hz + (H - hz) * t * t;
        if (y < hz || y > H) { continue; }
        ctx.moveTo(0, y);
        ctx.lineTo(W, y);
      }
      ctx.stroke();

      /* --- крупный слой: он и держит форму -------------------------------- */
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      for (i = -22; i <= 22; i++) {
        x = vx + i * (W / 7);
        ctx.moveTo(vx + (x - vx) * 0.04, hz);
        ctx.lineTo(x, H);
      }
      for (k = 1; k <= 26; k++) {
        /*  Шаг растёт нелинейно — так поперечные линии ложатся как на полу,
         *  а не как на лестнице. Сдвиг «off» гонит их к зрителю. */
        t = (k + off) / 26;
        y = hz + (H - hz) * t * t;
        if (y < hz || y > H) { continue; }
        ctx.moveTo(0, y);
        ctx.lineTo(W, y);
      }
      ctx.stroke();

      /* --- линия горизонта и свечение над ней ----------------------------- */
      var g = ctx.createLinearGradient(0, hz - 90, 0, hz + 10);
      g.addColorStop(0, 'transparent');
      g.addColorStop(1, cBrass);
      ctx.globalAlpha = 0.12;
      ctx.fillStyle = g;
      ctx.fillRect(0, hz - 90, W, 100);
      ctx.globalAlpha = 0.42;
      ctx.strokeStyle = cBrass;
      ctx.beginPath();
      ctx.moveTo(0, hz); ctx.lineTo(W, hz);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    function graph() {
      var i, j, a, b, d;
      ctx.globalAlpha = 0.55;
      ctx.strokeStyle = cRule;
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (i = 0; i < nodes.length; i++) {
        for (j = i + 1; j < nodes.length; j++) {
          a = nodes[i]; b = nodes[j];
          d = Math.hypot(a.x - b.x, a.y - b.y);
          if (d < 132) {
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
          }
        }
      }
      ctx.stroke();
      ctx.globalAlpha = 0.9;
      ctx.fillStyle = cBrass;
      for (i = 0; i < nodes.length; i++) {
        ctx.beginPath();
        ctx.arc(nodes[i].x, nodes[i].y, 1.4, 0, 6.3);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    var off = 0;
    function frame() {
      ctx.clearRect(0, 0, W, H);
      grid(off);
      graph();
      if (reduce) { return; }
      off = (off + 0.012) % 1;
      /*  Догоняем цель по десятой доле за кадр — движение получается
       *  тягучим, как будто фон тяжелее курсора. */
      mx += (tx - mx) * 0.06;
      my += (ty - my) * 0.06;
      var cx = mx * W, cy = my * H, R = 190;
      for (var i = 0; i < nodes.length; i++) {
        var p = nodes[i];
        p.x += p.dx; p.y += p.dy;
        /*  Отталкивание тем сильнее, чем ближе точка к курсору, и совсем
         *  пропадает за радиусом: иначе весь слой уезжает в угол. */
        var ddx = p.x - cx, ddy = p.y - cy;
        var d = Math.hypot(ddx, ddy);
        if (d > 0.5 && d < R) {
          var f = (1 - d / R) * 1.6;
          p.x += (ddx / d) * f;
          p.y += (ddy / d) * f;
        }
        if (p.x < 0) { p.x = 0; p.dx *= -1; }
        if (p.x > W) { p.x = W; p.dx *= -1; }
        if (p.y < 0) { p.y = 0; p.dy *= -1; }
        if (p.y > H) { p.y = H; p.dy *= -1; }
      }
      requestAnimationFrame(frame);
    }

    resize();
    var t;
    window.addEventListener('resize', function () {
      clearTimeout(t);
      t = setTimeout(resize, 180);
    });
    /*  Тему переключают кнопкой в шапке — цвета надо перечитать, иначе
     *  сетка останется тёмной на светлом фоне. */
    new MutationObserver(readTones).observe(document.documentElement,
      { attributes: true, attributeFilter: ['data-theme'] });
    frame();
  }

  /* ------------------------------------------------------------------------
   *  2. ПОЯВЛЕНИЕ ПРИ ПРОКРУТКЕ
   *
   *  Наблюдатель, а не обработчик прокрутки: обработчик считает положение
   *  на каждый кадр и на длинной странице заметно греет телефон.
   * --------------------------------------------------------------------- */
  function reveal() {
    var items = document.querySelectorAll('[data-fx]');
    if (!items.length) { return; }
    if (reduce || !('IntersectionObserver' in window)) {
      Array.prototype.forEach.call(items, function (el) { el.classList.add('fx-in'); });
      Array.prototype.forEach.call(document.querySelectorAll('[data-count]'), function (el) {
        el.textContent = fmt(+el.getAttribute('data-count'));
      });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) { return; }
        e.target.classList.add('fx-in');
        countIn(e.target);
        io.unobserve(e.target);
      });
    }, { threshold: 0.18, rootMargin: '0px 0px -40px 0px' });
    Array.prototype.forEach.call(items, function (el) { io.observe(el); });
  }

  function fmt(n) {
    return String(Math.round(n)).replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
  }

  /*  Счётчики крутятся от нуля до настоящего значения. Значение приходит
   *  из базы разметкой — выдуманных чисел на странице нет. */
  function countIn(root) {
    var list = root.matches('[data-count]') ? [root]
             : root.querySelectorAll('[data-count]');
    Array.prototype.forEach.call(list, function (el) {
      var to = +el.getAttribute('data-count') || 0;
      if (reduce || to === 0) { el.textContent = fmt(to); return; }
      var t0 = performance.now(), dur = 900 + Math.min(700, to / 40);
      (function step(now) {
        var p = Math.min(1, (now - t0) / dur);
        /*  Замедление к концу: число «доезжает», а не обрывается. */
        el.textContent = fmt(to * (1 - Math.pow(1 - p, 3)));
        if (p < 1) { requestAnimationFrame(step); }
      })(t0);
    });
  }

  /* ------------------------------------------------------------------------
   *  3. ПАРАЛЛАКС ФОНА
   *
   *  Холст едет медленнее содержимого — появляется глубина. Считаем в
   *  requestAnimationFrame, а не прямо в обработчике прокрутки: иначе
   *  раскладка пересчитывается по нескольку раз за кадр.
   * --------------------------------------------------------------------- */
  function parallax() {
    var cv = document.getElementById('fx-bg');
    if (!cv || reduce) { return; }
    var y = 0, run = false;
    window.addEventListener('scroll', function () {
      y = window.scrollY || 0;
      if (run) { return; }
      run = true;
      requestAnimationFrame(function () {
        cv.style.transform = 'translate3d(0,' + (y * 0.18) + 'px,0)';
        run = false;
      });
    }, { passive: true });
  }

  /* ------------------------------------------------------------------------
   *  4. ЛЕНТА ОТЗЫВОВ СО «СКАНОМ»
   *
   *  Полоса света идёт поперёк ленты и на миг обнажает слой «кода» позади
   *  карточек. Эффект чисто декоративный и от курсора не зависит — но
   *  выглядит как отклик, и этого достаточно.
   *
   *  Слой кода заполняем здесь, а не в разметке: полсотни строк мусорных
   *  символов в исходнике страницы мешают читать её и лезут в поиск.
   * --------------------------------------------------------------------- */
  function scanCode() {
    var box = document.querySelector('.scan-code');
    if (!box) { return; }
    var abc = '0123456789ABCDEF·▚▞■□/\\|<>{}[]=+-';
    var rows = 26, cols = 220, out = [];
    for (var r = 0; r < rows; r++) {
      var s = '';
      for (var c = 0; c < cols; c++) {
        s += abc[(Math.random() * abc.length) | 0];
      }
      out.push(s);
    }
    box.textContent = out.join('\n');
  }

  /* ------------------------------------------------------------------------
   *  5. СОСТОЯНИЕ СЕРВЕРА ЖИВЬЁМ — точка «на связи» пульсирует только
   *     тогда, когда сервер действительно отвечает. Мигающая точка при
   *     лежащем сервере — это ложь в оформлении.
   * --------------------------------------------------------------------- */
  /* ------------------------------------------------------------------------
   *  5. КОПИРОВАНИЕ АДРЕСА СЕРВЕРА
   *
   *  Адрес переписывают в клиент руками и ошибаются в одной букве — а потом
   *  пишут, что сервер не работает. Кнопка убирает этот класс жалоб целиком.
   * --------------------------------------------------------------------- */
  function copyBtn() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-copy]'), function (b) {
      b.addEventListener('click', function () {
        var v = b.getAttribute('data-copy') || '';
        var done = function () {
          b.classList.add('done');
          setTimeout(function () { b.classList.remove('done'); }, 1400);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(v).then(done, function () {});
          return;
        }
        /*  Запасной путь для старых браузеров и страниц без https. */
        var t = document.createElement('textarea');
        t.value = v; t.style.position = 'fixed'; t.style.opacity = '0';
        document.body.appendChild(t); t.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
        document.body.removeChild(t);
      });
    });
  }

  function init() {
    background();
    reveal();
    parallax();
    scanCode();
    copyBtn();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
