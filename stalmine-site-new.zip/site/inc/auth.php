<?php
/* ============================================================================
 *  auth.php — регистрация, вход, привязка ника.
 *
 *  ПАРОЛЬ НИГДЕ НЕ ХРАНИТСЯ И НИГДЕ НЕ ЛОГИРУЕТСЯ. Только password_hash()
 *  и password_verify(). Алгоритм не задаём числом — PASSWORD_DEFAULT сам
 *  возьмёт актуальный, а старые хеши продолжат проверяться.
 * ========================================================================= */

declare(strict_types=1);

/* Напрямую из браузера не открывается — причина в boot.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}

const LOGIN_MIN = 3;
const LOGIN_MAX = 32;
const PASS_MIN  = 8;

/* Ник Minecraft: буквы, цифры, подчёркивание, 3–16. Проверяем сами, а не
 * доверяем вводу: этот ник потом станет ключом в игровых таблицах. */
function validNick(string $n): bool {
    return (bool)preg_match('/^[A-Za-z0-9_]{3,16}$/', $n);
}

function validLogin(string $l): bool {
    return (bool)preg_match('/^[A-Za-z0-9_.\-]{' . LOGIN_MIN . ',' . LOGIN_MAX . '}$/u', $l);
}

/**
 * Регистрация. Возвращает пустой массив при успехе, иначе список ошибок.
 */
function doRegister(PDO $pdo, string $login, string $pass, string $pass2, ?string $email): array {
    $err = [];
    if (!validLogin($login)) {
        $err[] = 'Логин: от ' . LOGIN_MIN . ' до ' . LOGIN_MAX
               . ' знаков, латиница, цифры, точка, дефис, подчёркивание.';
    }
    if (mb_strlen($pass) < PASS_MIN) {
        $err[] = 'Пароль короче ' . PASS_MIN . ' знаков.';
    }
    if ($pass !== $pass2) {
        $err[] = 'Пароли не совпадают.';
    }
    if ($email !== null && $email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $err[] = 'Почта выглядит неправильно.';
    }
    if ($err) {
        return $err;
    }

    $st = $pdo->prepare('SELECT 1 FROM users WHERE login = ? LIMIT 1');
    $st->execute([$login]);
    if ($st->fetch()) {
        return ['Такой логин уже занят.'];
    }

    /*  СКОЛЬКО АККАУНТОВ МОЖНО ЗАВЕСТИ С ОДНОГО АДРЕСА ЗА СУТКИ.
     *
     *  Единственная форма на сайте, у которой предела не было вовсе: вход
     *  ограничен десятью попытками, чат и комментарии — паузой, сообщения
     *  об ошибках — пятью в сутки, а регистрацию можно было гнать скриптом
     *  сколько угодно. Это не «взлом», но полсотни пустых аккаунтов за ночь
     *  разгребать руками.
     *
     *  Пять — с запасом на общий адрес: за одним провайдером или в одной
     *  школе легко сидят несколько человек, и запирать их из-за соседа
     *  нельзя. Скрипту же пять аккаунтов в сутки бессмысленны.
     *
     *  Считаем по reg_ip, а НЕ по last_ip: последний перезаписывается при
     *  каждом входе, и по нему счёт разъехался бы на первом же заходе. */
    $ip = ipBin();
    $st = $pdo->prepare(
        'SELECT COUNT(*) FROM users
          WHERE reg_ip = ? AND created_at > (NOW() - INTERVAL 1 DAY)'
    );
    $st->execute([$ip]);
    if ((int)$st->fetchColumn() >= 5) {
        return ['С вашего адреса сегодня уже создали несколько аккаунтов. '
              . 'Попробуйте завтра или напишите нам.'];
    }

    $st = $pdo->prepare(
        'INSERT INTO users (login, email, pass_hash, reg_ip, created_at)
         VALUES (?, ?, ?, ?, NOW())'
    );
    try {
        $st->execute([$login, ($email ?: null),
                      password_hash($pass, PASSWORD_DEFAULT), $ip]);
    } catch (PDOException $e) {
        /* Гонка: между проверкой и вставкой логин мог занять кто-то ещё.
         * Уникальный ключ в базе — последняя линия, и она сработала. */
        error_log('register: ' . $e->getMessage());
        return ['Такой логин уже занят.'];
    }
    return [];
}

/**
 * Вход. Возвращает пустой массив при успехе.
 *
 * ОДИН И ТОТ ЖЕ ОТВЕТ на «нет такого логина» и «неверный пароль». Разные
 * ответы позволяют перебрать существующие логины, ничего не подбирая.
 */
function doLogin(PDO $pdo, string $login, string $pass, bool $remember = false): array {
    $ip = ipBin();

    /* Ограничение попыток: не больше десяти неудач за пятнадцать минут —
     * по логину ИЛИ по адресу. Только по адресу забанит весь подъезд,
     * только по логину даст перебирать разные логины с одного места. */
    $st = $pdo->prepare(
        'SELECT COUNT(*) FROM login_tries
          WHERE ok = 0 AND at > (NOW() - INTERVAL 15 MINUTE)
            AND (login = ? OR ip = ?)'
    );
    $st->execute([$login, $ip]);
    if ((int)$st->fetchColumn() >= 10) {
        return ['Слишком много попыток. Подождите пятнадцать минут.'];
    }

    $st = $pdo->prepare('SELECT * FROM users WHERE login = ? LIMIT 1');
    $st->execute([$login]);
    $u = $st->fetch();

    $ok = $u !== false && password_verify($pass, $u['pass_hash']);

    $pdo->prepare('INSERT INTO login_tries (login, ip, ok) VALUES (?, ?, ?)')
        ->execute([$login, $ip, $ok ? 1 : 0]);

    if (!$ok) {
        return ['Неверный логин или пароль.'];
    }

    /* Хеш мог устареть — например, PHP сменил алгоритм по умолчанию.
     * Пароль у нас на руках ровно сейчас, другого случая пересчитать не
     * будет до следующего входа. */
    if (password_needs_rehash($u['pass_hash'], PASSWORD_DEFAULT)) {
        $pdo->prepare('UPDATE users SET pass_hash = ? WHERE id = ?')
            ->execute([password_hash($pass, PASSWORD_DEFAULT), $u['id']]);
    }

    /* Новый идентификатор сессии: иначе тот, кто подсунул свой до входа,
     * останется в ней и после. */
    session_regenerate_id(true);
    unset($u['pass_hash']);
    $_SESSION['user'] = $u;

    $pdo->prepare('UPDATE users SET last_login = NOW(), last_ip = ? WHERE id = ?')
        ->execute([$ip, $u['id']]);

    if ($remember) { rememberIssue($pdo, (int)$u['id']); }

    return [];
}

/* ============================================================================
 *  «ЗАПОМНИТЬ МЕНЯ»
 *
 *  ПОЧЕМУ НЕ «ПРОСТО ДЛИННАЯ СЕССИЯ». Сессия живёт, пока её не почистит
 *  сервер, а чистит он их по своему расписанию — на общем хостинге это
 *  часы, не недели. Растягивать её бессмысленно.
 *
 *  ПОЧЕМУ ДВЕ ЧАСТИ В КУКЕ. Хранится «указатель:пароль»: по указателю
 *  находим строку, пароль сверяем хешем. Если бы в базе лежал сам ключ,
 *  утёкшая копия таблицы означала бы вход в любой аккаунт без пароля —
 *  ровно то, от чего мы храним хеши вместо паролей.
 *
 *  Ключ ОДНОРАЗОВЫЙ: при каждом входе по куке он меняется. Украденную
 *  куку это не спасёт саму по себе, но кража становится заметной — у
 *  хозяина перестаёт работать вход, и он это увидит.
 * ========================================================================= */

const REMEMBER_DAYS = 30;
const REMEMBER_COOKIE = 'stalmine_r';

function rememberIssue(PDO $pdo, int $userId): void {
    $sel = bin2hex(random_bytes(8));      // 16 знаков
    $val = bin2hex(random_bytes(32));     // 64 знака
    $pdo->prepare(
        'INSERT INTO remember_me (selector, validator_hash, user_id, expires_at)
         VALUES (?, ?, ?, NOW() + INTERVAL ? DAY)'
    )->execute([$sel, hash('sha256', $val), $userId, REMEMBER_DAYS]);

    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    setcookie(REMEMBER_COOKIE, $sel . ':' . $val, [
        'expires'  => time() + REMEMBER_DAYS * 86400,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => $https,
    ]);
}

function rememberForget(PDO $pdo): void {
    $c = $_COOKIE[REMEMBER_COOKIE] ?? '';
    if (is_string($c) && str_contains($c, ':')) {
        [$sel] = explode(':', $c, 2);
        $pdo->prepare('DELETE FROM remember_me WHERE selector = ?')->execute([$sel]);
    }
    setcookie(REMEMBER_COOKIE, '', ['expires' => time() - 42000, 'path' => '/']);
}

/** Попробовать войти по куке. Вызывается из boot.php, когда сессии нет. */
function rememberTry(PDO $pdo): ?array {
    $c = $_COOKIE[REMEMBER_COOKIE] ?? '';
    if (!is_string($c) || !str_contains($c, ':')) { return null; }
    [$sel, $val] = explode(':', $c, 2);

    $st = $pdo->prepare(
        'SELECT r.*, u.* FROM remember_me r JOIN users u ON u.id = r.user_id
          WHERE r.selector = ? AND r.expires_at > NOW() LIMIT 1'
    );
    $st->execute([$sel]);
    $row = $st->fetch();
    /* hash_equals, а не «==»: сравнение строк прекращается на первом
     * различии, и по времени ответа ключ подбирается по одному знаку. */
    if (!$row || !hash_equals((string)$row['validator_hash'], hash('sha256', $val))) {
        rememberForget($pdo);
        return null;
    }
    $pdo->prepare('DELETE FROM remember_me WHERE selector = ?')->execute([$sel]);
    rememberIssue($pdo, (int)$row['user_id']);
    unset($row['pass_hash'], $row['validator_hash'], $row['selector']);
    return $row;
}

function doLogout(?PDO $pdo = null): void {
    /* Ключ «запомнить меня» снимается ВМЕСТЕ с сессией. Иначе «выйти»
     * закрывало сессию, а следующая же страница поднимала её обратно по
     * куке — со стороны кнопка выхода просто не работала. */
    if ($pdo !== null) { rememberForget($pdo); }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
                  $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/**
 * Выдать код привязки ника. Код одноразовый и живёт полчаса.
 *
 * Восемь знаков без похожих букв: ноль и «O», единица и «I» на экране
 * неразличимы, а код человек переписывает руками в игру.
 */
function makeLinkCode(PDO $pdo, int $userId, string $nick): string {
    $abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $code = '';
    for ($i = 0; $i < 8; $i++) {
        $code .= $abc[random_int(0, strlen($abc) - 1)];
    }
    $pdo->prepare('DELETE FROM link_codes WHERE user_id = ? AND used_at IS NULL')
        ->execute([$userId]);
    $pdo->prepare(
        'INSERT INTO link_codes (code, user_id, mc_nick, expires_at)
         VALUES (?, ?, ?, NOW() + INTERVAL 30 MINUTE)'
    )->execute([$code, $userId, $nick]);
    return $code;
}
