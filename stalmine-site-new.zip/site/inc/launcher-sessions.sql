-- Пропуска лаунчера STALMINE.
--
-- ОДНА ТАБЛИЦА НА ДВЕ РАЗНЫЕ ВЕЩИ, И ЭТО НАРОЧНО:
--   token_hash + expires_at  — «лаунчер помнит вход» (30 дней);
--   game_until               — «этому нику прямо сейчас можно зайти в игру»
--                              (15 минут, выдаётся нажатием «Играть»).
-- Разводить их по двум таблицам смысла нет: пропуск в игру всегда выдаётся
-- той же сессии, что вошла, и умирает вместе с ней.
--
-- ip хранится в двоичном виде (varbinary(16)) — так же, как в `users`:
-- inet_pton кладёт и IPv4, и IPv6 в одно поле, и сравнение точное.

CREATE TABLE IF NOT EXISTS launcher_sessions (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     INT UNSIGNED NOT NULL,
  token_hash  CHAR(64)     NOT NULL,
  nick        VARCHAR(16)  NOT NULL DEFAULT '',
  ip          VARBINARY(16) DEFAULT NULL,
  created_at  DATETIME     NOT NULL,
  expires_at  DATETIME     NOT NULL,
  game_until  DATETIME     DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uniq_token (token_hash),
  KEY idx_nick_pass (nick, game_until),
  KEY idx_user (user_id),
  KEY idx_expires (expires_at),
  CONSTRAINT fk_ls_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ник не может принадлежать двум аккаунтам: иначе двое войдут одним
-- персонажем, и чей это инвентарь — не разберёт никто.
-- Индекс ставится отдельной строкой нарочно: на живой базе он может не встать
-- из-за уже существующих повторов, и тогда это надо увидеть, а не проглотить.
ALTER TABLE users ADD UNIQUE KEY uniq_mc_nick (mc_nick);
