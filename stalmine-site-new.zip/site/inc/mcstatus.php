<?php
/* ============================================================================
 *  mcstatus.php — состояние игрового сервера.
 *
 *  БЕЗ ПЛАГИНОВ И БЕЗ ДОСТУПА К СЕРВЕРУ. Это обычный опрос из списка
 *  серверов — тот самый, которым клиент показывает онлайн в меню. Работает
 *  всегда, потому что этот ответ сервер обязан отдавать по протоколу.
 *
 *  Почему не через панель хостинга: ключ панели даёт полный доступ к
 *  файлам и консоли, и класть его в код сайта нельзя ни при каких
 *  обстоятельствах. Опрос порта не требует никаких доступов вовсе.
 *
 *  Результат кешируется в файл: без кеша каждая загрузка главной лезла бы
 *  в игровой сервер, и при наплыве это уже похоже на атаку.
 * ========================================================================= */

declare(strict_types=1);

/* Напрямую из браузера не открывается — причина в boot.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}

/** VarInt — так протокол Minecraft пишет числа: по семь бит на байт,
 *  восьмой говорит «продолжение следует». */
function mcVarInt(int $v): string {
    $out = '';
    do {
        $b = $v & 0x7F;
        $v >>= 7;
        if ($v !== 0) { $b |= 0x80; }
        $out .= chr($b);
    } while ($v !== 0);
    return $out;
}

function mcReadVarInt($sock): int {
    $n = 0; $shift = 0;
    while (true) {
        $c = fgetc($sock);
        if ($c === false) { throw new RuntimeException('обрыв'); }
        $b = ord($c);
        $n |= ($b & 0x7F) << $shift;
        if (($b & 0x80) === 0) { return $n; }
        $shift += 7;
        if ($shift > 35) { throw new RuntimeException('varint слишком длинный'); }
    }
}

/**
 * Опросить сервер. Возвращает ['online'=>bool, 'now'=>int, 'max'=>int]
 * либо ['online'=>false] — с причиной наружу не выходим, она в лог.
 */
function mcStatus(string $host, int $port, int $cacheSec = 60): array {
    $cache = sys_get_temp_dir() . '/stalmine_mc_' . md5($host . ':' . $port) . '.json';
    if (is_file($cache) && (time() - filemtime($cache)) < $cacheSec) {
        $c = json_decode((string)file_get_contents($cache), true);
        if (is_array($c)) { return $c; }
    }

    $res = ['online' => false, 'now' => 0, 'max' => 0];
    try {
        $sock = @fsockopen($host, $port, $eno, $estr, 3);
        if (!$sock) { throw new RuntimeException("$eno $estr"); }
        stream_set_timeout($sock, 3);

        /* Рукопожатие: номер протокола -1 значит «просто спрашиваю статус». */
        $hs = mcVarInt(0x00) . mcVarInt(-1 & 0xFFFFFFFF)
            . mcVarInt(strlen($host)) . $host . pack('n', $port) . mcVarInt(1);
        fwrite($sock, mcVarInt(strlen($hs)) . $hs);
        fwrite($sock, mcVarInt(1) . mcVarInt(0x00));

        mcReadVarInt($sock);            // длина пакета целиком
        mcReadVarInt($sock);            // идентификатор пакета
        $len = mcReadVarInt($sock);     // длина строки JSON

        $json = '';
        while (strlen($json) < $len) {
            $chunk = fread($sock, $len - strlen($json));
            if ($chunk === false || $chunk === '') { break; }
            $json .= $chunk;
        }
        fclose($sock);

        $d = json_decode($json, true);
        if (is_array($d)) {
            $res = [
                'online' => true,
                'now'    => (int)($d['players']['online'] ?? 0),
                'max'    => (int)($d['players']['max'] ?? 0),
            ];
        }
    } catch (Throwable $e) {
        error_log('mcstatus: ' . $e->getMessage());
    }

    @file_put_contents($cache, json_encode($res));
    return $res;
}
