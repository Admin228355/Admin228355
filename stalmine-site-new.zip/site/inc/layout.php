<?php
/* ============================================================================
 *  layout.php — шапка и подвал.
 *
 *  Оформление то же, что у памятки: служебная инструкция закрытого
 *  предприятия. Узкий шрифт заголовков, засечки в тексте, моноширинный на
 *  показаниях. Второго стиля у проекта быть не должно — сайт и памятка
 *  должны читаться как один документ.
 * ========================================================================= */

/* Напрямую из браузера не открывается — причина в boot.php. */
if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/site.php';
require_once __DIR__ . '/art.php';

/** Состояние сообщения об ошибке: подпись и цвет. Ключи те же, что в базе.
 *  Живёт здесь, а не в двух страницах сразу: подписи должны совпадать в
 *  кабинете игрока и в управлении, иначе один и тот же ответ читается
 *  по-разному с двух сторон. */
function bugState(string $s): array {
    return [
        'new'       => ['на разборе',   ''],
        'confirmed' => ['подтверждено', 'up'],
        'fixed'     => ['исправлено',   'up'],
        'rejected'  => ['не ошибка',    'down'],
        'duplicate' => ['уже было',     'down'],
    ][$s] ?? [$s, ''];
}

/** Состояние платежа: подпись и цвет. Здесь же, где bugState — подписи
 *  должны совпадать везде, где показываются. */
function payState(string $s): array {
    return [
        'pending' => ['не оплачен', 'down'],
        'paid'    => ['ждёт выдачи', ''],
        'granted' => ['выдано',      'up'],
        'canceled'=> ['отменён',     'down'],
        'donated' => ['пожертвование', 'up'],
    ][$s] ?? [$s, ''];
}

/**
 * @param string      $title  заголовок вкладки
 * @param string      $active какой пункт меню подсветить
 * @param string|null $css    дополнительный лист стилей
 *
 *  ДОПОЛНИТЕЛЬНЫЙ ЛИСТ ПОДКЛЮЧАЕТСЯ ЗДЕСЬ, А НЕ НА СТРАНИЦЕ. Памятка
 *  ставила свой <link> прямо в тексте страницы, то есть уже внутри body:
 *  браузер такое принимает, но применяет с опозданием, и страница на
 *  мгновение показывалась голой.
 */
function pageHead(string $title, string $active = '', ?string $css = null): void {
    global $CFG, $pdo;
    /*  ВЕРХ — ТОЛЬКО ТО, ЗАЧЕМ ПРИХОДЯТ. Было семь пунктов вперемешку:
     *  «Правила» и «Реквизиты» стояли рядом с «Новостями», и глазу не за
     *  что зацепиться — всё одного веса, значит, ничего не важно.
     *
     *  Наверху осталось четыре. Служебное ушло в подвал: туда идут, когда
     *  уже знают, что ищут, и лишний раз мимо него ходить не надо. */
    $nav = [
        'start' => ['Начать', '/start/'],
        /*  Лаунчер стоит вторым, сразу за «Начать». Это первое, что человеку
         *  нужно физически: без него на сервер больше не зайти вовсе. */
        'launcher' => ['Лаунчер', '/launcher/'],
        /*  Ключ «news», а не пустой. С пустым ключом подсветка доставалась
         *  ГЛАВНОЙ: она зовёт pageHead без второго довода, то есть с пустой
         *  строкой, и та совпадала с ключом новостей. Человек открывал
         *  сайт и видел, что он якобы в разделе новостей. */
        'news'  => ['Новости', '/news/'],
        'wiki'  => ['Памятка', '/wiki/'],
        'top'   => ['Рейтинг', '/top/'],
        'players' => ['Игроки', '/players/'],
        'chat'  => ['Чат', '/chat/'],
        'shop'  => ['Пополнить', '/shop/'],
    ];

    /*  КАНОНИЧЕСКИЙ АДРЕС. Яндекс показывал главную как «stalmine.ru ›
     *  index.php»: он взял тот адрес, по которому страница ему попалась, а
     *  других указаний не было. Здесь мы прямо говорим, какой адрес
     *  считать настоящим, и «index.php» из выдачи уходит.
     *
     *  Собираем из пути запроса, отрезая имя файла и параметры: параметры
     *  вроде ?s=slug важны для новости, но для главной ?done=1 — мусор,
     *  который поисковик считал бы отдельной страницей. */
    $path = strtok((string)($_SERVER['REQUEST_URI'] ?? '/'), '?');
    $path = preg_replace('~/index\.php$~', '/', (string)$path) ?: '/';
    /*  У новости адрес осмысленный только вместе с ?s=, поэтому её мы
     *  каноним вместе с параметром. Всё остальное — без параметров. */
    if (isset($_GET['s']) && str_starts_with($path, '/news')) {
        $path = '/news/?s=' . rawurlencode((string)$_GET['s']);
    }
    $canon = 'https://stalmine.ru' . $path;

    $desc = setting($pdo, 'meta_desc',
        'Сервер Minecraft про вылазки в зону отчуждения на Урале: наряды, '
      . 'костюм с фильтром, вес, аномалии, мутанты.');
    /*  Картинка предпросмотра. С меткой времени в адресе: соцсети и
     *  поисковики держат её у себя месяцами, и без метки заменить картинку
     *  невозможно — они продолжат показывать старую. */
    $ogv = @filemtime(dirname(__DIR__) . '/assets/og.jpg') ?: 1;
    $og  = 'https://stalmine.ru/assets/og.jpg?v=' . (int)$ogv;
    ?><!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($title) ?> — <?= h($CFG['site_name']) ?></title>
<meta name="description" content="<?= h($desc) ?>">
<link rel="canonical" href="<?= h($canon) ?>">

<?php /*  ТЕМА СТАВИТСЯ ДО ОТРИСОВКИ, И ПОТОМУ СКРИПТ ЗДЕСЬ, А НЕ В КОНЦЕ.
          Если выбрать тему после загрузки страницы, человек с тёмной темой
          сначала увидит вспышку светлой. Это одна строка, она обязана
          выполниться раньше первого пикселя — поэтому и внутри <head>. */ ?>
<script nonce="<?= h(cspNonce()) ?>">try{var t=localStorage.getItem('stalmine-theme');if(t==='light'||t==='dark')document.documentElement.setAttribute('data-theme',t);}catch(e){}</script>

<?php /*  КАРТОЧКА ДЛЯ СОЦСЕТЕЙ И ПОИСКА. Без этих строк Яндекс и телеграм
          берут первую попавшуюся картинку со страницы — а её у нас нет,
          поэтому показывалась чужая, оставшаяся от прежнего сайта. */ ?>
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?= h($CFG['site_name']) ?>">
<meta property="og:locale" content="ru_RU">
<meta property="og:title" content="<?= h($title) ?> — <?= h($CFG['site_name']) ?>">
<meta property="og:description" content="<?= h($desc) ?>">
<meta property="og:url" content="<?= h($canon) ?>">
<meta property="og:image" content="<?= h($og) ?>">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#14150F">

<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml">
<?php /*  МЕТКА ВРЕМЕНИ В АДРЕСЕ СТИЛЕЙ. Без неё браузер держит старый файл,
          и правки оформления не видно вовсе: владелец смотрел страницу со
          стилями недельной давности и справедливо говорил, что некрасиво.
          Меняется файл — меняется адрес — кэш обновляется сам. */
   $cssv = @filemtime(dirname(__DIR__) . '/assets/style.css') ?: time(); ?>
<link rel="stylesheet" href="/assets/style.css?v=<?= (int)$cssv ?>">
<?php /*  ДЕКОРАТИВНЫЙ СЛОЙ ТЕПЕРЬ НА ВСЕХ СТРАНИЦАХ, А НЕ ТОЛЬКО НА ГЛАВНОЙ.
          Сперва он стоял на одной главной — ради заряда телефона. Но сайт от
          этого разваливался надвое: нарядная витрина и голые внутренние
          страницы, будто разные сайты. Холст стоит один кадр отрисовки,
          и это дешевле, чем такое впечатление.
          Движение по-прежнему целиком выключается системной настройкой
          «уменьшить движение». */
   $fxc = @filemtime(dirname(__DIR__) . '/assets/fx.css') ?: 1; ?>
<link rel="stylesheet" href="/assets/fx.css?v=<?= (int)$fxc ?>">
<?php if ($css !== null): ?><link rel="stylesheet" href="<?= h($css) ?>">
<?php endif; ?></head>
<body>
<canvas id="fx-bg" aria-hidden="true"></canvas>
<header class="top">
  <div class="wrap topin">
    <a class="brand" href="/">
      <?= art('mark', 'brand-mark') ?>
      <span class="brand-txt">
        <span class="brand-over">Урал · закрытая территория</span>
        <span class="brand-name"><?= h($CFG['site_name']) ?></span>
      </span>
    </a>
    <nav class="mainnav">
      <?php foreach ($nav as $k => $v): ?>
        <a href="<?= h($v[1]) ?>"<?= $k === $active ? ' class="on"' : '' ?>><?= h($v[0]) ?></a>
      <?php endforeach; ?>
      <?php if (isAdmin()): ?>
        <a href="/admin/"<?= $active === 'admin' ? ' class="on"' : '' ?>>Управление</a>
      <?php endif; ?>
    </nav>
    <div class="acct">
      <?php /*  Переключатель темы. Кнопка, а не ссылка: она ничего не
                открывает, а меняет вид этой же страницы. Обе картинки лежат
                внутри, показывается нужная — так надпись не прыгает при
                переключении. */ ?>
      <button class="themeb" type="button" id="themeb"
              title="Светлая или тёмная" aria-label="Сменить тему">
        <svg class="ic sun" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 17a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-13.2a1 1 0 0 1-1-1V1.4a1 1 0 1 1 2 0v1.4a1 1 0 0 1-1 1zm0 19.8a1 1 0 0 1-1-1v-1.4a1 1 0 1 1 2 0v1.4a1 1 0 0 1-1 1zM3.8 12a1 1 0 0 1-1 1H1.4a1 1 0 1 1 0-2h1.4a1 1 0 0 1 1 1zm19.8 0a1 1 0 0 1-1 1h-1.4a1 1 0 1 1 0-2h1.4a1 1 0 0 1 1 1zM5.6 6.6a1 1 0 0 1-1.4 0l-1-1a1 1 0 0 1 1.4-1.4l1 1a1 1 0 0 1 0 1.4zm14.2 14.2a1 1 0 0 1-1.4 0l-1-1a1 1 0 0 1 1.4-1.4l1 1a1 1 0 0 1 0 1.4zM4.2 20.8a1 1 0 0 1 0-1.4l1-1a1 1 0 0 1 1.4 1.4l-1 1a1 1 0 0 1-1.4 0zM18.4 6.6a1 1 0 0 1 0-1.4l1-1a1 1 0 1 1 1.4 1.4l-1 1a1 1 0 0 1-1.4 0z"/></svg>
        <svg class="ic moon" viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12.9A9 9 0 1 1 11.1 3a7 7 0 0 0 9.9 9.9z"/></svg>
      </button>
      <?php /*  «Поддержать» — для всех, и без входа: помочь проекту можно,
                не заводя аккаунт. Стоит рядом со входом, а не в общем меню:
                это не раздел сайта, а действие. */ ?>
      <a href="/donate/" class="give<?= $active === 'donate' ? ' on' : '' ?>"><svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7.5-4.6-9.6-9.2C.9 8.5 2.7 4.5 6.5 4.5c2.2 0 3.7 1.2 5.5 3.2 1.8-2 3.3-3.2 5.5-3.2 3.8 0 5.6 4 4.1 7.3C19.5 16.4 12 21 12 21z"/></svg>Поддержать</a>
      <?php if ($u = user()): ?>
        <a href="/profile/"<?= $active === 'profile' ? ' class="on"' : '' ?>><?= h($u['login']) ?></a>
        <a href="/logout/?t=<?= h(csrf()) ?>" class="quiet">выйти</a>
      <?php else: ?>
        <a href="/login/">Вход</a>
        <a href="/register/" class="cta">Регистрация</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<main class="wrap">
<?php
    /*  ОБЪЯВЛЕНИЕ. Одна строка на все страницы: «сервер на профилактике»,
     *  «сегодня в 20:00 вылазка». Пока пусто — не показывается вовсе.
     *  Заводится в управлении, потому что нужно оно всегда внезапно и
     *  срочно, а править ради этого файлы некогда. */
    $notice = setting($pdo, 'notice', '');
    if ($notice !== '') {
        printf('<div class="flash notice">%s</div>', h($notice));
    }
    foreach (takeFlash() as $f) {
        printf('<div class="flash %s">%s</div>',
               $f['k'] === 'err' ? 'flash-err' : 'flash-ok', h($f['t']));
    }
}

function pageFoot(): void {
    global $CFG, $pdo;
    /*  Подвальное меню объявлено ЗДЕСЬ, а не в pageHead. Там оно было
     *  локальной переменной функции, и «global» в подвале подхватывал бы
     *  пустоту — ссылки просто не выводились бы, молча. */
    $navFoot = [
        ['Игровые правила',              '/rules/'],
        ['Договор-оферта',               '/legal/offer/'],
        ['Политика конфиденциальности',  '/legal/privacy/'],
        ['Реквизиты',                    '/legal/'],
        ['Сообщить об ошибке',           '/bugs/'],
        ['Поддержать разработку',        '/donate/'],
    ];
    $links = siteLinks($pdo);
    ?>
</main>
<footer class="foot">
  <div class="foot-art"><?= art('ridge') ?></div>
  <div class="wrap">
    <?php /*  СООБЩЕСТВА В ПОДВАЛЕ, А НЕ НА ОТДЕЛЬНОЙ СТРАНИЦЕ. Отдельную
              страницу надо найти, а подвал человек видит на любой из них.
              Список ведётся в разделе управления — чтобы адрес канала
              менялся без правки файлов. */ ?>
    <?php if ($links): ?>
    <nav class="socials" aria-label="Сообщества">
      <?php foreach ($links as $l): ?>
        <a href="<?= h($l['url']) ?>" rel="noopener nofollow" target="_blank">
          <?= linkIcon((string)$l['kind']) ?><span><?= h($l['title']) ?></span>
          <?php if ($l['note']): ?><em><?= h($l['note']) ?></em><?php endif; ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <?php endif; ?>
    <div class="foot-grid">
      <div>
        <div class="foot-brand"><?= art('mark', 'brand-mark') ?><b><?= h($CFG['site_name']) ?></b></div>
        <p>Адрес сервера: <b class="mono"><?= h(mcShow($CFG)) ?></b>, версия 26.1.2.
           На сайте описано то, что работает сейчас; чего в описании нет, того нет
           и в игре.</p>
        <p class="give-line">Проект делается на свои. Если он вам нравится —
           <a href="/donate/">поддержите разработку</a>, аккаунт для этого не нужен.</p>
      </div>
      <nav class="footnav">
        <?php foreach ($navFoot as $v): ?>
          <a href="<?= h($v[1]) ?>"><?= h($v[0]) ?></a>
        <?php endforeach; ?>
      </nav>
    </div>
    <p class="small"><?= h($CFG['seller_name'] ?? '') ?><?php
       if (!empty($CFG['seller_inn'])): ?>, ИНН <?= h($CFG['seller_inn']) ?><?php endif; ?>
       <?php if (!empty($CFG['seller_email'])): ?>· <?= h($CFG['seller_email']) ?><?php endif; ?>
       <?php if (!empty($CFG['seller_phone'])): ?>· <?= h($CFG['seller_phone']) ?><?php endif; ?>
</p>
  </div>
</footer>
<?php /*  Декоративный слой: фон, появление блоков, счётчики, копирование
          адреса. С defer — до появления текста в нём нужды нет. */
   $fxj = @filemtime(dirname(__DIR__) . '/assets/fx.js') ?: 1; ?>
<script src="/assets/fx.js?v=<?= (int)$fxj ?>" defer nonce="<?= h(cspNonce()) ?>"></script>
<?php /*  Переключение темы. Запоминаем выбор, а не только применяем: иначе
          на следующей странице всё вернётся обратно, и кнопка выглядит
          сломанной. Пока выбора не делали, тему задаёт система. */ ?>
<script nonce="<?= h(cspNonce()) ?>">
(function () {
  var b = document.getElementById('themeb'), r = document.documentElement;
  if (!b) { return; }
  function now() {
    var set = r.getAttribute('data-theme');
    if (set) { return set; }
    return matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }
  b.addEventListener('click', function () {
    var next = now() === 'dark' ? 'light' : 'dark';
    r.setAttribute('data-theme', next);
    try { localStorage.setItem('stalmine-theme', next); } catch (e) {}
  });
})();
</script>
</body>
</html>
<?php
}
