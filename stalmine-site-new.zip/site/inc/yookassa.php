<?php
/* ============================================================================
 *  yookassa.php — приём оплаты.
 *
 *  ДВА ПРАВИЛА, НА КОТОРЫХ ЗДЕСЬ ВСЁ ДЕРЖИТСЯ.
 *
 *  1. СУММУ СЧИТАЕТ СЕРВЕР. Из браузера приходит только желаемое число
 *     рублей; бонус, итоговые знаки и цена платежа считаются здесь. Если
 *     доверить это странице, любой откроет консоль и купит миллион знаков
 *     за пятьдесят рублей.
 *
 *  2. ОДИН ПЛАТЁЖ — ОДНО НАЧИСЛЕНИЕ. ЮKassa присылает уведомление об
 *     оплате ПОВТОРНО, пока не получит от нас ответ 200: сеть моргнула —
 *     пришло второе, третье. Защита не в коде обработчика, а в базе:
 *     уникальный ключ на номер платежа. Двойная вставка просто не пройдёт.
 *
 *  Ключи лежат в stalmine-config.php выше корня сайта.
 * ========================================================================= */

declare(strict_types=1);

if (realpath(__FILE__) === realpath($_SERVER['SCRIPT_FILENAME'] ?? '')) {
    http_response_code(404);
    exit;
}

/** Сколько знаков дадим за столько рублей. Единственное место, где это
 *  считается: и страница, и создание платежа зовут одну функцию. */
function ykCoins(int $rub): array {
    $tiers = [[0, 0], [500, 5], [1500, 10], [5000, 15], [15000, 20], [50000, 25]];
    $pct = 0;
    foreach ($tiers as $t) { if ($rub >= $t[0]) { $pct = $t[1]; } }
    return ['pct' => $pct, 'coins' => (int)floor($rub * (100 + $pct) / 100)];
}

/**
 * Создать платёж и вернуть ссылку на оплату.
 *
 * @return array{ok:bool, url?:string, id?:string, error?:string}
 */
function ykCreate(PDO $pdo, array $cfg, array $user, int $rub, string $ip): array {
    if ($rub < 50 || $rub > 100000) {
        return ['ok' => false, 'error' => 'Сумма вне допустимых границ.'];
    }
    if (empty($cfg['yk_shop_id']) || empty($cfg['yk_secret'])) {
        return ['ok' => false, 'error' => 'Приём оплаты ещё не настроен.'];
    }
    if (empty($user['mc_nick'])) {
        return ['ok' => false, 'error' => 'Сначала привяжите игровой ник.'];
    }

    $calc = ykCoins($rub);

    $body = [
        'amount'       => ['value' => number_format($rub, 2, '.', ''), 'currency' => 'RUB'],
        'capture'      => true,
        'confirmation' => [
            'type'       => 'redirect',
            'return_url' => 'https://stalmine.ru/shop/?done=1',
        ],
        'description'  => sprintf('Талоны ✦ для %s — %d шт.', $user['mc_nick'], $calc['coins']),
        'metadata'     => [
            'nick'    => $user['mc_nick'],
            'user_id' => (string)$user['id'],
            'coins'   => (string)$calc['coins'],
        ],
    ];

    $r = ykSend($cfg, $body);
    if (!$r['ok']) {
        return $r;
    }
    $r = $r['payment'];

    /*  Пишем ДО перехода на оплату. Если записать после, платёж, брошенный
     *  на полпути, не оставит следа — и уведомление о нём придёт в пустоту. */
    $st = $pdo->prepare(
        'INSERT INTO payments (yk_id, user_id, mc_nick, amount_rub, bonus_pct, coins, status, ip)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $st->execute([$r['id'], (int)$user['id'], $user['mc_nick'], $rub,
                  $calc['pct'], $calc['coins'], 'pending', $ip]);

    return ['ok' => true, 'url' => $r['confirmation']['confirmation_url'], 'id' => $r['id']];
}


/**
 * Отправить в ЮKassa запрос на создание платежа.
 *
 * Общая часть для пополнения и пожертвования: ключ идемпотентности,
 * разбор ответа, ошибки в лог, а не на страницу.
 *
 * @return array{ok:bool, payment?:array, error?:string}
 */
function ykSend(array $cfg, array $body): array {
    /*  Строка идемпотентности — требование ЮKassa: с одним и тем же
     *  ключом повторный запрос не создаёт второй платёж. */
    $idem = bin2hex(random_bytes(16));

    $ch = curl_init('https://api.yookassa.ru/v3/payments');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($body, JSON_UNESCAPED_UNICODE),
        CURLOPT_USERPWD        => $cfg['yk_shop_id'] . ':' . $cfg['yk_secret'],
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Idempotence-Key: ' . $idem,
        ],
        CURLOPT_TIMEOUT        => 20,
    ]);
    $raw  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($raw === false) {
        error_log('yk create: ' . $err);
        return ['ok' => false, 'error' => 'Платёжный сервис не отвечает. Попробуйте позже.'];
    }
    $r = json_decode((string)$raw, true);
    if ($code >= 300 || !isset($r['id'], $r['confirmation']['confirmation_url'])) {
        /*  Текст ошибки наружу не отдаём: в нём бывает описание нашего
         *  магазина и внутренние коды. В лог — целиком. */
        error_log('yk create HTTP ' . $code . ': ' . substr((string)$raw, 0, 500));
        return ['ok' => false, 'error' => 'Не удалось создать платёж.'];
    }
    return ['ok' => true, 'payment' => $r];
}

const DONATE_MIN = 50;
const DONATE_MAX = 100000;

/**
 * Добровольное пожертвование на разработку.
 *
 * БЕЗ АККАУНТА И БЕЗ НИКА — НАРОЧНО. Человек, которому нравится проект,
 * не обязан в нём регистрироваться, чтобы помочь. Поэтому здесь не
 * спрашиваем ни входа, ни ника, и даже вошедшего НЕ привязываем к платежу:
 * user_id и mc_nick пустые. Ничего не начисляется — ни талонов, ни вещей:
 * это подарок, а не покупка.
 *
 * Мост с игрой берёт только строки с ником, так что пожертвование до игры
 * не доедет и в «ждёт выдачи» не повиснет: уведомление об оплате ставит
 * ему отдельное состояние «donated».
 *
 * @return array{ok:bool, url?:string, id?:string, error?:string}
 */
function ykDonate(PDO $pdo, array $cfg, int $rub, string $ip): array {
    if ($rub < DONATE_MIN || $rub > DONATE_MAX) {
        return ['ok' => false, 'error' => sprintf('Сумма — от %d до %s ₽.',
                DONATE_MIN, number_format(DONATE_MAX, 0, '', ' '))];
    }
    if (empty($cfg['yk_shop_id']) || empty($cfg['yk_secret'])) {
        return ['ok' => false, 'error' => 'Приём оплаты ещё не настроен.'];
    }

    /*  Страница открыта всем, значит, и для ботов. Без потолка можно
     *  забить таблицу брошенными счетами. Десять неоплаченных за час с
     *  одного адреса живому человеку не нужны никогда. */
    $q = $pdo->prepare(
        "SELECT COUNT(*) FROM payments
          WHERE ip = ? AND status = 'pending' AND mc_nick IS NULL
            AND created_at > NOW() - INTERVAL 1 HOUR"
    );
    $q->execute([$ip]);
    if ((int)$q->fetchColumn() >= 10) {
        return ['ok' => false, 'error' => 'Слишком много попыток. Попробуйте через час.'];
    }

    $r = ykSend($cfg, [
        'amount'       => ['value' => number_format($rub, 2, '.', ''), 'currency' => 'RUB'],
        'capture'      => true,
        'confirmation' => [
            'type'       => 'redirect',
            'return_url' => 'https://stalmine.ru/donate/?thanks=1',
        ],
        'description'  => 'Добровольное пожертвование на разработку проекта «Кыштымский Пробой»',
        'metadata'     => ['kind' => 'donation'],
    ]);
    if (!$r['ok']) {
        return $r;
    }
    $p = $r['payment'];

    $st = $pdo->prepare(
        'INSERT INTO payments (yk_id, user_id, mc_nick, amount_rub, bonus_pct, coins, status, ip)
         VALUES (?, NULL, NULL, ?, 0, 0, ?, ?)'
    );
    $st->execute([$p['id'], $rub, 'pending', $ip]);

    return ['ok' => true, 'url' => $p['confirmation']['confirmation_url'], 'id' => $p['id']];
}
